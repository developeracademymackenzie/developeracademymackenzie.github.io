import Foundation

class GameOfLifeBoard: CellViewDelegate{
    
    var cells:[[CellView]] = [[CellView]]()
    var board = [[BackgroundColor]]()
    
    var isGameRunning = false {
        didSet{
            if isGameRunning{
                if timer == nil {
//                    print("criou timer")
                    self.timer =
                        Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { (t) in
//                            print("-------- comeco de uma rodada--------------")
                            self.board = [[BackgroundColor]]()
                            for i in 0..<self.cells.count {
                                self.board.append([])
                                for cell in self.cells[i] {
                                    self.board[i].append(cell.color)
                                }
                            }
                            var liveCells = 0
                            for i in 0..<self.cells.count {
                                for j in 0..<self.cells[i].count {
                                    var neighbours = [CellView]()
                                    for k in -1...1{
                                        for l in -1...1{
//                                            print("k: \(k), l: \(l)")
                                            if k != 0 || l != 0 {
//                                                print("k e j sao diferentes de 0 :D")
                                                if i+k >= 0 && i+k < self.cells.count && j+l >= 0 && j+l < self.cells[i].count{
//                                                    print("acessando o visinho \(k),\(l)")
                                                    neighbours.append(self.cells[i+k][j+l])
                                                }
                                            }
                                        }
                                    }
                                    var liveNeighbours = 0
                                    for neighbour in neighbours {
                                        liveNeighbours += neighbour.color.rawValue
                                    }
                                    switch self.cells[i][j].color{
                                    case .white:
                                        liveCells += 1
//                                        print("Cell in \(i),\(j) is a white cell with \(liveNeighbours)")
                                        if liveNeighbours < 2 || liveNeighbours > 3 {
                                            self.board[i][j] = .black
                                            liveCells -= 1
                                        }
                                    default:
                                        if liveNeighbours > 0 {
//                                        print("Cell in \(i),\(j) is a black cell with \(liveNeighbours)")
                                        }
                                        if liveNeighbours == 3 {
                                            self.board[i][j] = .white
                                            liveCells += 1
                                        }
                                    }
                                }
                            }
                            for i in 0..<self.board.count{
                                for j in 0..<self.board[i].count{
                                    self.cells[i][j].color = self.board[i][j]
                                }
                            }
//                            print("live cells: \(liveCells)")
                            if liveCells == 0 {
                                self.isGameRunning = false
//                                print(self.isGameRunning)
                            }
                        })
                }
                
            } else {
//                print("opa o jogo tem que parar agora")
                if let _ = timer {
//                    print("o timer será invalidado")
                    self.timer!.invalidate()
                    self.timer = nil
                }
        }
    }
}
var timer: Timer?

func userInteractionOcurred(){
    self.isGameRunning = false
    Timer.scheduledTimer(withTimeInterval: 10, repeats: false, block: { (t) in
        self.isGameRunning = true
    })
    
}
}
