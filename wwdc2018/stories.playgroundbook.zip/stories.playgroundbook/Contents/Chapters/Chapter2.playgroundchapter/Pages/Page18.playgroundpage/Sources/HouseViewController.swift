//
//  HouseViewController.swift
//  wwdc18_xcode
//
//  Created by Nicholas Babo on 26/03/18.
//  Copyright © 2018 Nicholas Babo. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit

public enum Page:String{
    case MedicalAid = "medic"
    case Symptoms = "house"
    case Strong = "strong"
    case Insomnia = "insomnia2"
}

public class HouseViewController: UIViewController {
    
    var selectedPage:Page = .Strong
    var sceneView:SCNView = SCNView()
    
    private func addViews() {
        self.sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(self.sceneView)
        self.sceneView.frame = view.bounds
    }

    public override func viewDidLoad() {
        super.viewDidLoad()

        super.viewDidLoad()
        
        // create a new scene
        let scene = SCNScene(named: "models.scnassets/\(self.selectedPage.rawValue).scn")!
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 20, z: 35)
        
        // create and add a light to the scene
              let lightNode = SCNNode()
                lightNode.light = SCNLight()
                lightNode.light!.type = .omni
                lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
                scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        // retrieve the SCNView
        addViews()
        
        // set the scene to the view
        self.sceneView.scene = scene
        
        // allows the user to manipulate the camera
        self.sceneView.allowsCameraControl = true
        
        // show statistics such as fps and timing information
        self.sceneView.showsStatistics = false
        
        // configure the view
        switch self.selectedPage{
        case .MedicalAid:
            self.sceneView.backgroundColor = UIColor.notWeaknessBackground
        case .Strong:
            self.sceneView.backgroundColor = UIColor.notWeaknessBackground
        default:
            self.sceneView.backgroundColor = UIColor.blue
        }
        
        let anchor = scene.rootNode.childNode(withName: "anchor", recursively: true)!
        let rotateAction = SCNAction.rotateBy(x: 0, y: CGFloat.pi*2, z: 0, duration: 10)
        let repeatRotation = SCNAction.repeatForever(rotateAction)
        anchor.runAction(repeatRotation)
    }
    
    
    public override var shouldAutorotate: Bool {
        return true
    }
    
    public override var prefersStatusBarHidden: Bool {
        return true
    }
    
    public override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    public override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
