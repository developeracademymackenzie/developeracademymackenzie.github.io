//
//  SoundEngine.swift
//  SoundDraw
//
//  Created by João Gabriel Borelli Padilha on 20/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import AVFoundation

public class SoundEngine {
    
    // MARK: - Instruments
    public var instrumentOrgan: Instrument
    public var instrumentElectro: Instrument
    public var instrumentStrings: Instrument
    public var instrumentGuitar: Instrument
    public var instrumentBass: Instrument
    
    public init() {
        // Configure
        self.instrumentOrgan = Instrument.init(instrumentName: "Organ")
        self.instrumentElectro = Instrument.init(instrumentName: "Electro")
        self.instrumentStrings = Instrument.init(instrumentName: "Strings")
        self.instrumentGuitar = Instrument.init(instrumentName: "Guitar")
        self.instrumentBass = Instrument.init(instrumentName: "Bass")
    }
    
    public func getIntrument(byName: String) -> Instrument {
        var instrument: Instrument
        switch byName {
        case "Organ":
            instrument = self.instrumentOrgan
        case "Electro":
            instrument = self.instrumentElectro
        case "Strings":
            instrument = self.instrumentStrings
        case "Guitar":
            instrument = self.instrumentGuitar
        case "Bass":
            instrument = self.instrumentBass
        default:
            instrument = self.instrumentStrings
        }
        return instrument
    }
    
}
