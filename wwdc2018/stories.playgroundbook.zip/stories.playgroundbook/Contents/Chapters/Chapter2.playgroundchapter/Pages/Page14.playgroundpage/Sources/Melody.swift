//
//  Melody.swift
//  Dev
//
//  Created by João Gabriel Borelli Padilha on 19/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import Foundation
import SpriteKit

public class Melody: SKNode {
    
    // MARK: - Variables
    public var engine:SoundEngine
    public var notes:[Note]
    public var songNotes:[SongNote]
    
    public init( sound: SoundEngine, notes:[Note] ) {
        self.engine = sound
        self.notes = notes
        self.songNotes = []
        super.init()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func start() {
        var sequence:[SKAction] = []
        
        let before = SKAction.wait(forDuration: 1.0)
        sequence.append(before)
        
        for note in songNotes {
            let add = SKAction.run {
                self.addChild(note)
            }
            let wait = SKAction.wait(forDuration: note.duration)
            let playNote = SKAction.group([add, wait])
            sequence.append(playNote)
            print("c \(note.position.y)")
        }
        
        let music = SKAction.sequence(sequence)
        self.run(music)
    }
    
}
