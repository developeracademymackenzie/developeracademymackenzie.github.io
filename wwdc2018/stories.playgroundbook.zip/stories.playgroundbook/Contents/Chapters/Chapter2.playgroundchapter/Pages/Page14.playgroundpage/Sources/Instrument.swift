//
//  Instrument.swift
//  SoundDraw
//
//  Created by João Gabriel Borelli Padilha on 20/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import AVFoundation

public class Instrument {
    
    // MARK: - Audio
    private var instrument:String
    // MARK: - Audio Source
    private var audioEngine = AVAudioEngine()
    private var audioPlayerNode = AVAudioPlayerNode()
    private var buffer = AVAudioPCMBuffer()
    // MARK: - Audio Effects
    private var auTimePitch = AVAudioUnitTimePitch()
    private var auReverb = AVAudioUnitReverb()
    //private var echo = AVAudioUnitDelay()
    
    public init(instrumentName: String) {
        self.instrument = instrumentName
        // Configure
        self.configure(instrument: instrumentName)
        // Configure Effects
        self.configureEffects(pitch: 50, reverb: 100)
        // Start audio engine
        self.start()
    }
    
    private func configure(instrument: String) {
        let path = Bundle.main.path(forResource: instrument, ofType:"m4a")
        let fileURL = NSURL(fileURLWithPath: path!)
        var file:AVAudioFile
        do {
            try file = AVAudioFile(forReading: fileURL as URL)
            let b = AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: AVAudioFrameCount(file.length))
            self.buffer = b
            try file.read(into: b)
        } catch {
            // Error handling
        }
    }
    
    private func configureEffects(pitch: Float, reverb: Float) {
        // Reverb
        auReverb = AVAudioUnitReverb()
        auReverb.loadFactoryPreset(AVAudioUnitReverbPreset.cathedral)
        auReverb.wetDryMix = reverb
        
        // var distortion = AVAudioUnitDistortion()
        // distortion.loadFactoryPreset(AVAudioUnitDistortionPreset.speechRadioTower)
        // distortion.wetDryMix = 25
        
        // Pitch Effect
        auTimePitch.pitch = pitch*4
        
        // Attach nodes
        audioEngine.attach(audioPlayerNode)
        audioEngine.attach(auReverb)
        audioEngine.attach(auTimePitch)
        // audioEngine.attach(distortion)
        
        // Connect audioPlayerNode to the reverb
        audioEngine.connect(audioPlayerNode, to: auReverb, format: buffer.format) // audioPlayer -> Reverb
        audioEngine.connect(auReverb, to: auTimePitch, format: buffer.format) // reverb -> auTimePitch
        audioEngine.connect(auTimePitch, to: audioEngine.mainMixerNode, format: buffer.format) // auTimePitch -> audioEngine.mainMixerNode
    }
    
    public func start() {
        // Schedule playerA and playerB to play the buffer on a loop
        audioPlayerNode.scheduleBuffer(buffer, at: nil, options: .loops, completionHandler: nil)
        //.scheduleBuffer(buffer, completionHandler: nil)
        //.scheduleBuffer(buffer, at: nil, options: .loops, completionHandler: nil)
        
        // Start the audio engine
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            // Error handling
        }
        
    }
    
    func begin() {
        if audioEngine.isRunning == false {
            // Configure
            self.configure(instrument: self.instrument)
            // Configure Effects
            self.configureEffects(pitch: 50, reverb: 100)
            // Start audio engine
            self.start()
        }
    }
    
    public func stop() {
        audioEngine.stop()
    }
    
    func setupEffects(pitch: Float, reverb: Float) {
        auTimePitch.pitch = pitch*4
        auReverb.wetDryMix = reverb
    }
    
    // MARK: - Play methods
    
    public func play() {
        //audioPlayerNode.volume = 10.0
        //        audioPlayerNode.scheduleBuffer(buffer, completionHandler: nil) /////////////////////
        audioPlayerNode.play()
    }
    
    public func pause() {
        audioPlayerNode.pause()
    }
    
    // MARK: - Volume methods
    
    public func mute() {
        audioPlayerNode.volume = 0.0
    }
    
    public func unMute() {
        audioPlayerNode.volume = 10.0
    }
    
}

