/*: João Gabriel Borelli Padilha
 
 ![João](joao.png)
 
 # João Gabriel Borelli Padilha
 
 - - -
 iPad
 - - -
 
 ### Big Idea
Music
 
 ### Essential Question
 How to develop a new way to play a song using a loop?
 
 ### Challenge
 Develop an interactive playground that can turn a drawing into a song.
 
 - - -
 
 SoundDraw is a playground where you can draw music, each brush has a color and an instrument sound. The top edge of the screen is where we can find the high pitched notes, and at the bottom of the screen is where we can find the low pitched notes. The right and left edges are the ones you can get a reverb effect. Each draw that you make will be repeated every 4 times in the song.
 What really inspired me was the pad midi controller, because I really wanted to connect the different pad notes.
 
 This time I am much more productive because I have more knowledge about development for iOS and I am more focused on an relevant experience, I am much more engaged than before.
 At first I was learning to program in Swift and this helped me a lot this time, because I managed to structure my project better to become more optimized and at the same time achieve what I wanted.
 The only thing I used this year and last time was SpriteKit, but the other thing was totally different, as I developed something different this year.
 */




//#-hidden-code
import PlaygroundSupport
import SpriteKit


 
var bpm = /*#-editable-code*/80.0/*#-end-editable-code*/
var metronome_Beep_Sound = /*#-editable-code*/true/*#-end-editable-code*/
var loop = /*#-editable-code*/true/*#-end-editable-code*/
var playInitialMusic = /*#-editable-code*/true/*#-end-editable-code*/

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 720, height: 480))
if let scene = GameScene(fileNamed: "GameScene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    // Parameters
    scene.metronomeBeep = metronome_Beep_Sound
    scene.bpm = bpm
    scene.loopEnable = loop
    scene.playInitialMusic = playInitialMusic
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code

