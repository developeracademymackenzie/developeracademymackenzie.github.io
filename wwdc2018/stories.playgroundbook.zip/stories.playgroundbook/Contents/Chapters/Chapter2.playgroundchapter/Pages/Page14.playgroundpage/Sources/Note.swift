//
//  Note.swift
//  Dev
//
//  Created by João Gabriel Borelli Padilha on 16/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import SpriteKit

public class Note: SKShapeNode {
    
    // MARK: - Parameters
    var lifeCicle:Double!
    var sound:Instrument!
    //circleNode = SKShapeNode.init(circleOfRadius: w)
    var loop:Bool!
    
    public init(radius: CGFloat, lifeCicle: Double, loop: Bool, color: UIColor, sound: Instrument) {
        
        self.sound = sound
        self.lifeCicle = lifeCicle
        self.loop = loop
        super.init()
        
        let w = 32
        let h = 32
        self.path = UIBezierPath(roundedRect: CGRect(x: -(w/2), y: -(h/2), width: w, height: h), cornerRadius: (CGFloat(w/2)) ).cgPath
        
        self.fillColor = color
        self.strokeColor = color
        self.lineWidth = 2.5
        
        //        self.sound = Sound.init(pitch: Int(position.y), reverb: Int(position.x) )
        
        self.start()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func start() {
        if loop {
            let add = SKAction.run {
                self.alpha = 1.0
                // Sound
                self.sound.setupEffects(pitch: Float(self.position.y), reverb: Float(self.position.x) )
                self.sound.unMute()
                //                self.sound.play()
            }
            let wait = SKAction.wait(forDuration: lifeCicle * 4) // Wait 4 times
            let stop = SKAction.run {
                // Sound
                self.sound.mute()
                //                self.sound.pause()
            }
            let remove = SKAction.sequence([ .fadeOut(withDuration: 0.5), stop ])
            let go = SKAction.group([remove, wait])
            
            let sequence = SKAction.sequence([add, go])
            let loop = SKAction.repeatForever(sequence)
            
            self.run(loop)
        }else{
            let add = SKAction.run {
                self.alpha = 1.0
                // Sound
                self.sound.setupEffects(pitch: Float(self.position.y), reverb: Float(self.position.x) )
                self.sound.unMute()
            }
            let stop = SKAction.run {
                // Sound
                self.sound.mute()
                self.removeFromParent()
            }
            let remove = SKAction.sequence([add, .fadeOut(withDuration: 0.5), stop])
            self.run(remove)
        }
    }
    
}
