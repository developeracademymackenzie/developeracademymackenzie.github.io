/*: Guilherme Chevis Meira
 
 ![Chevis](chevis.png)
 
 # Guilherme Chevis Meira
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Travel
 
 ### Essential Question
 How to represent all “Travel” that happened in human history?
 
 ### Challenge
 Develop an Swift playground that represents all “Travel" in human history.
 
 - - -
 
 My playground represents some of the most important travels that happened through human history. Each scene represent a travel, the user can interact with the ""traveler"" and help to get him to its destination, while doing that, a phrase about that context is revealed somewhere in the scene.
 
 My main inspiration was the trip that I am going to make with some friends to the US later this year. I am really excited, this is going to be the first time I leave South America.
 
 Last year I did't know almost anything about Swift, the WWDC Playground was my first experience with it, this time, I have a whole year of experience, so I can make better decisions. One really important decision that came out from a early guiding question was witch library to use, SpriteKit or UIKit, something that last year would have helped me a lot.
 
 */


//#-hidden-code
import PlaygroundSupport
import SpriteKit
import UIKit
import GameplayKit

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = ThirdPageScene(fileNamed: "ThirdPage") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFit
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView


//#-end-hidden-code



