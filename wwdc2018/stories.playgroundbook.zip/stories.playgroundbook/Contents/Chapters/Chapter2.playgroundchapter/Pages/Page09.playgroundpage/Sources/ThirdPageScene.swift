//
//  PageScene.swift
//  PlaygroundWWDC
//
//  Created by Guilherme Chevis Meira on 26/03/2018.
//  Copyright © 2018 Guilherme Chevis Meira. All rights reserved.
//

import UIKit
import SpriteKit

public class ThirdPageScene: SKScene {
    
    var nuvem3Node = SKSpriteNode()
    var nuvem3Origin = CGFloat()
    var nuvem3Destination = CGFloat()
    var nuvem2Node = SKSpriteNode()
    var nuvem2Origin = CGFloat()
    var nuvem2Destination = CGFloat()
    var nuvem1Node = SKSpriteNode()
    var nuvem1Origin = CGFloat()
    var nuvem1Destination = CGFloat()
    
    var dragableNode = SKSpriteNode()
    var originPoint = CGPoint()
    var selectedNode: Bool = false
    var destinationPoint = CGPoint()
    
    var initialDistance = CGFloat()
    var currentDistance = CGFloat()
    
    
    override public func sceneDidLoad() {
        
        
        self.nuvem3Node = self.childNode(withName: "nuvem3")! as! SKSpriteNode
        self.nuvem2Node = self.childNode(withName: "nuvem2")! as! SKSpriteNode
        self.nuvem1Node = self.childNode(withName: "nuvem1")! as! SKSpriteNode
        
        self.dragableNode = self.childNode(withName: "people")! as! SKSpriteNode
        self.originPoint = dragableNode.position
        self.destinationPoint = CGPoint(x: 410, y: -215.0)
        self.initialDistance = distance(originPoint, destinationPoint)
        
        
        nuvem3Destination = 400
        nuvem3Origin = nuvem3Node.position.x
        nuvem2Destination = 400
        nuvem2Origin = nuvem2Node.position.x
        nuvem1Destination = 400
        nuvem1Origin = nuvem1Node.position.x
    }
    
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let location = touch?.location(in: self)
        
        
        selectedNode = nodes(at: location!).contains(dragableNode)
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let position = touches.first!.location(in: self)
        if selectedNode && position.x < destinationPoint.x{
            
            dragableNode.position.x = position.x
        }
    }
    
    func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let xDist = a.x - b.x
        let yDist = a.y - b.y
        return CGFloat(sqrt((xDist * xDist) + (yDist * yDist)))
    }
    
    func percentage(total: CGFloat, current: CGFloat) -> CGFloat{
        return 100 - (current * 100)/total
    }
    
    func movePercentage(percentage: CGFloat,  total: CGFloat) -> CGFloat{
        return (percentage*total)/100
    }
    
    
    
    override public func update(_ currentTime: TimeInterval) {
        currentDistance = distance(dragableNode.position, destinationPoint)

        
        if dragableNode.position.x > originPoint.x && dragableNode.position.x < destinationPoint.x{
        nuvem3Node.position.x = nuvem3Origin + movePercentage(percentage: percentage(total: initialDistance, current: currentDistance), total: nuvem3Destination-nuvem3Origin)
        nuvem2Node.position.x = nuvem2Origin + movePercentage(percentage: percentage(total: initialDistance, current: currentDistance), total: nuvem3Destination-nuvem2Origin)
        nuvem1Node.position.x = nuvem1Origin + movePercentage(percentage: percentage(total: initialDistance, current: currentDistance), total: nuvem3Destination-nuvem1Origin)
        
        nuvem3Node.alpha = 1 - movePercentage(percentage: percentage(total: initialDistance, current: currentDistance), total: 1)
        nuvem2Node.alpha = 1 - movePercentage(percentage: percentage(total: initialDistance, current: currentDistance), total: 1)
        nuvem1Node.alpha = 1 - movePercentage(percentage: percentage(total: initialDistance, current: currentDistance), total: 1)
        }
    }
    
    
    
}


