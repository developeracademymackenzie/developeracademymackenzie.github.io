import Foundation
import UIKit

class CardView: UIImageView {
    
    var numberLabel: StrokedLabel!
    
    init(frame: CGRect, number: Int) {
        super.init(frame: frame)
        self.image = UIImage(named: "Game/Cellbg")
        self.addNumber(number)
    }
    
    func addNumber(_ number: Int) {
        let labelView = StrokedLabel(frame: self.frame)
        self.addSubview(labelView)
        labelView.setConstraints()
        labelView.setText(text: number.description, align: .center, size: 32)
        self.numberLabel = labelView
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
