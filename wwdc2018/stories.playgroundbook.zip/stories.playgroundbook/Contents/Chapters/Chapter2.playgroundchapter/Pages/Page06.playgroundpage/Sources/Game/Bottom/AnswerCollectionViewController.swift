import UIKit

class AnswerCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    var progression: Progression = GameHelper.main.currentProgression
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MainCell", for: indexPath) as! AnswersCell
        cell.backgroundView = UIImageView(image: UIImage(named: "Game/Cellbg"))
        cell.configurate(number: progression.results[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width / 4 - 20
        let height = collectionView.bounds.height / 2 - 25
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsetsMake(0, 20, 0, 20)
    }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! AnswersCell
        if GameHelper.main.isAnimating { return }
        if GameHelper.main.gameHasEnded { return }
        if cell.isDisabled { return }
        
        let mainRect = cell.convert(cell.bounds, to: GameHelper.main.controller!.view)
        let card = CardView(frame: mainRect, number: cell.number)
        var callback: () -> Void
        cell.backgroundView = UIView()
        cell.label!.setText(text: "", align: .center, size: 28)
        cell.label!.isAccessibilityElement = false
        cell.isDisabled = true
        
        if progression.validateNext(number: cell.number) {
            let isComplete = progression.validateCompletion()
            if isComplete {
                callback = {
                    GameHelper.main.gameHasEnded = true
                    GameHelper.main.controller!.updateCentralView()
                    GameHelper.main.controller!.updateFullScreen()
                    card.removeFromSuperview()
                }
            } else {
                callback = {
                    GameHelper.main.controller!.updateCentralView()
                    card.removeFromSuperview()
                }
            }
            
        } else {
            progression.pointer += 1
            callback = {
                UIView.animate(withDuration: 0.5, animations: {
                    GameHelper.main.controller!.playSound("incorrect")
                    card.frame.origin = mainRect.origin
                    card.frame.size = cell.frame.size
                    let label = card.numberLabel!
                    label.setText(text: label.text!, align: .center, size: 32)
                }, completion: {
                    (success) in
                    self.progression.pointer -= 1
                    cell.backgroundView = UIImageView(image: UIImage(named: "Game/Cellbg"))
                    cell.configurate(number: cell.number)
                    cell.label!.isAccessibilityElement = true
                    cell.isDisabled = false
                    card.removeFromSuperview()
                })
            }
        }
        
        GameHelper.main.controller!.startAnimation(card: card, cellRect: cell.frame, callback: callback)
    }

}
