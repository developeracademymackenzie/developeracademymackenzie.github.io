import SpriteKit
import GameplayKit

class AnimationScene: SKScene {
    
    var leftCloud: Cloud! {
        didSet {
            self.addChild(leftCloud)
        }
    }
    var rightCloud: Cloud! {
        didSet {
            self.addChild(rightCloud)
        }
    }
    
    var girl: Girl! {
        didSet {
            self.addChild(girl)
        }
    }
    var quote: QuoteLabel! {
        didSet {
            self.addChild(quote)
        }
    }
    
    var background = SKSpriteNode(imageNamed: "Animation/Background.jpg")
    
    override func didMove(to view: SKView) {
        print("Animation Started Scene")
        self.background.size = CGSize(width: frame.size.width, height: frame.size.height)
        self.background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        self.addChild(background)
        // Added girl to the scene
        let textureGirl = SKTexture(imageNamed: "Animation/Girl/AnimateLook_13")
        let girl = Girl(texture: textureGirl, color: .clear, size: CGSize(width: Screen.main.width * 0.35, height: Screen.main.width * 0.26))
        self.girl = girl
        
        girl.position = CGPoint(x: Screen.main.width / 2, y: girl.size.height / 2)
        
        // Added SKLabel to the scene
        let label = QuoteLabel()
        label.horizontalAlignmentMode = .left
        label.fontName = "Helvetica"
        self.quote = label
        label.position = CGPoint(x: Screen.main.width * 0.25 , y: Screen.main.height * 0.6)

        // Add Clouds to the scene
        let textureCloud = SKTexture(imageNamed: "Animation/HappyCloud")
        let leftCloud = Cloud(texture: textureCloud, color: .clear, size: CGSize(width: Screen.main.width * 0.25, height: Screen.main.width * 0.17))
        self.leftCloud = leftCloud
        
        leftCloud.position = CGPoint(x: Screen.main.width * 1.6 / 10, y: Screen.main.height + leftCloud.size.height / 2 + 20)
        
        let rightCloud = Cloud(texture: textureCloud, color: .clear, size: CGSize(width: Screen.main.width * 0.25, height: Screen.main.width * 0.17))
        self.rightCloud = rightCloud
        
        rightCloud.position = CGPoint(x: Screen.main.width * 8.5 / 10, y: Screen.main.height + rightCloud.size.height / 2 + 40)
        
        animationLoop()
    }
    
    func animationLoop() {
        let warmUp = SKAction.wait(forDuration: 1.0)
        let girlFade = SKAction.run(self.girl.fadeInAnimation)
        let cloudEntrance = SKAction.wait(forDuration: 2.5)
        let leftCloudEntrance = SKAction.run(self.leftCloud.moveDownAnimation)
        let rightCloudEntrance = SKAction.run(self.rightCloud.moveDownAnimation)
        let cloudBounce = SKAction.wait(forDuration: 2.0)
        let leftCloudBounce = SKAction.run(self.leftCloud.bounce)
        let rightCloudBounce = SKAction.run(self.rightCloud.bounce)
        let waitGirlUp = SKAction.wait(forDuration: 2.6)
        let stopleftCloudBounce = SKAction.run(self.leftCloud.removeAllActions)
        let stoprightCloudBounce = SKAction.run(self.rightCloud.removeAllActions)
        let preapareGirl = SKAction.run(self.girl.prepareForReading)
        let waitPrepareGirl = SKAction.wait(forDuration: 0.9)
        let startTextAnimation = SKAction.run(self.quote.startAnimation)
        let startEyesFollow = SKAction.run(self.girl.eyesAnimation)
        let waitFadeOut = SKAction.wait(forDuration: 5)
        let girlFadeOut = SKAction.run(self.girl.moveAway)
        let leftCloudFade = SKAction.run(self.leftCloud.moveAway)
        let rightCloudFade = SKAction.run(self.rightCloud.moveAway)
        let textPos = SKAction.run(self.quote.finalPosition)
        let waitAccessibility = SKAction.wait(forDuration: 1)
        let showAccessibility = SKAction.run {
            let label = SKLabelNode(text: "Accessibility")
            label.horizontalAlignmentMode = .center
            label.fontName = "Helvetica"
            label.fontSize = 60
            label.alpha = 0
            label.position = CGPoint(x: Screen.main.width / 2, y: Screen.main.height / 1.6)
            self.addChild(label)
            label.run(SKAction.fadeIn(withDuration: 1))
        }
        let finalWait = SKAction.wait(forDuration: 2)
        let finalQuote = SKAction.run(self.quote.endAnimation)
        
        let sequence = SKAction.sequence([warmUp, girlFade, cloudEntrance, leftCloudEntrance, rightCloudEntrance, cloudBounce, leftCloudBounce, rightCloudBounce, waitGirlUp, stopleftCloudBounce, stoprightCloudBounce, preapareGirl, waitPrepareGirl, startTextAnimation, startEyesFollow, waitFadeOut, girlFadeOut, leftCloudFade, rightCloudFade, textPos, waitAccessibility, showAccessibility, finalWait, finalQuote])
        self.run(sequence)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    override func update(_ currentTime: TimeInterval) {
    }
}
