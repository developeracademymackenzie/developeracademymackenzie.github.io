import Foundation
import UIKit

public class Screen {
    
    public static var main = Screen()
    
    private init() {}
    
    public var height: CGFloat {
        get {
            if let controller = GameHelper.main.controller {
                return controller.view.bounds.height
            } else {
                return UIScreen.main.bounds.height // 512
            }
        }
    }
    
    public var width: CGFloat {
        get {
            if let controller = GameHelper.main.controller {
                return controller.view.bounds.width
            } else {
                return UIScreen.main.bounds.width // 768
            }
        }
    }
}

