import Foundation
import UIKit
import AVFoundation

public class GameViewController: UIViewController {

    let centralView = CentralView()
    let bottomView = BottomView()
    
    public var player: AVAudioPlayer!

    override public func loadView() {
        self.view = UIView(frame: CGRect(x: 0, y: 0, width: Screen.main.width, height: Screen.main.height))
        self.view.backgroundColor = UIColor(r: 180, g: 180, b: 180)
        self.view.addSubview(centralView)
        self.view.addSubview(bottomView)
        
        GameHelper.main.controller = self
    }

    public override var prefersStatusBarHidden: Bool {
        return true
    }

    func updateCentralView() {
        centralView.collection.reloadData()
        centralView.reloadAccessiblity()
        self.playSound("correct")
    }

    func updateFullScreen() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: {
            
        })
    }

    func startAnimation(card: CardView, cellRect: CGRect, callback: @escaping () -> Void) {

        let pointer = GameHelper.main.currentProgression.pointer
        let finalPos = self.centralView.collection.controller!.getFrameOfCell(at: pointer)
        guard let label = card.numberLabel else { return }
        GameHelper.main.isAnimating = true
        self.view.addSubview(card)

        UIView.animate(withDuration: 1, animations: {
            card.frame.origin = finalPos.bounds.origin
            card.frame.size = finalPos.frame.size
            label.frame.size = cellRect.size
            label.setText(text: label.text!, align: .center, size: 38)
        }, completion: {
            (success) in
            callback()
            GameHelper.main.isAnimating = false
        })
    }

    func playSound(_ name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)

            player = try AVAudioPlayer(contentsOf: url)

            guard let player = player else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                player.play()
                if GameHelper.Progression_isAccessibilityElement == true {
                    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification,  self.centralView.titleLabel);
                }

            })

        } catch let error {
            print(error.localizedDescription)
        }
    }


}

