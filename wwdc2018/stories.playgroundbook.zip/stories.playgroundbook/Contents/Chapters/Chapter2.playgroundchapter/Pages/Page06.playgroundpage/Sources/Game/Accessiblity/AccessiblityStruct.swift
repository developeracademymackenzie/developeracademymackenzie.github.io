import Foundation

public struct AccessibilityStruct {

    public var label: String
    public var hint: String
    
    public init(_ label: String, _ hint: String) {
        self.label = label
        self.hint = hint
    }
}
