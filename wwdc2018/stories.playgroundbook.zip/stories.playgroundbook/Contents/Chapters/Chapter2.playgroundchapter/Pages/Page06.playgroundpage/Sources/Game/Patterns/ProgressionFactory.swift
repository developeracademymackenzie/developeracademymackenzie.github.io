import Foundation

class ProgressionFactory {
    
    static var shared = ProgressionFactory()
    
    private init() {}
    
    func generateLevel() -> Progression {
        
        var progression: Progression
        
        let numbers = GameHelper.numbers
        
        let first = Int.randomInt(min: 0, max: 10)
        var diff = Int.randomInt(min: -5, max: 5)
        diff = diff == 0 ? 1 : diff
        progression = Progression(numbers: numbers, first: first, diff: diff)
        
        return progression
    }
}
