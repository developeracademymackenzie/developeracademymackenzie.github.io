import SpriteKit
import Foundation

class Cloud: SKSpriteNode {
    
    var currentFace = 0
    
    override init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: .red, size: size)
    }
    
    func moveDownAnimation() {
        let movement = SKAction.moveBy(x: 0, y: -(self.size.height * 2.9), duration: 1.0)
        movement.timingMode = .easeOut
        self.run(movement)
    }
    
    func bounce() {
        let moveUp = SKAction.moveBy(x: 0, y: self.size.height * 0.75, duration: 0.5)
        moveUp.timingMode = .easeOut
        
        let moveDown = SKAction.moveBy(x: 0, y: -(self.size.height * 0.75), duration: 0.5)
        moveDown.timingMode = .easeOut
        
        let changeFace = SKAction.animate(with: getRandomFace(), timePerFrame: 1)
        
        let sequence = SKAction.sequence([moveUp, moveDown, changeFace])
        self.run(SKAction.repeatForever(sequence))
    }
    
    func getRandomFace() -> [SKTexture] {
        let happy = SKTexture(imageNamed: "Animation/HappyCloud")
        let otherFace: SKTexture!
        let random = self.currentFace
        switch random {
        case 0:
            otherFace = SKTexture(imageNamed: "Animation/SleepCloud")
            break
        case 1:
            otherFace = SKTexture(imageNamed: "Animation/SleepCloud")
            break
        default:
            otherFace = SKTexture(imageNamed: "Animation/FunnyCloud")
        }
        self.currentFace += 1
        
        return [otherFace, happy]
    }
    
    func moveAway() {
        let movement = SKAction.moveBy(x: 0, y: -(self.size.height * 2.5), duration: 1.0)
        movement.timingMode = .easeIn
        self.run(movement)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
