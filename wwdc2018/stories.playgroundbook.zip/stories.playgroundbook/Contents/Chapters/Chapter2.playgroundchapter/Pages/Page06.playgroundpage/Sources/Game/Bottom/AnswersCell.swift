import UIKit

class AnswersCell: UICollectionViewCell {
    
    var number: Int = 0
    var isDisabled: Bool = false
    var label: StrokedLabel!
    
    func configurate(number: Int) {
        
        self.number = number
        if label == nil {
            let label = StrokedLabel(frame: CGRect(x: 0, y: 0, width: bounds.size.width, height: bounds.size.height))
            label.setText(text: number.description, align: .center, size: 28)
            self.label = label
            self.addSubview(label)
            label.setConstraints()
            label.isAccessibilityElement = true
            
        } else {
            self.label!.setText(text: number.description, align: .center, size: 28)
        }
        
    }
}
