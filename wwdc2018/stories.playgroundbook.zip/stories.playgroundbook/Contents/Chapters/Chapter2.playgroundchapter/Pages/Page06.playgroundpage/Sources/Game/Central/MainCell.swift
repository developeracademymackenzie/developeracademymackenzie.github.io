import UIKit
import AVFoundation

class MainCell: UICollectionViewCell {
    
    var number: Int = 0
    var label: StrokedLabel?
    
    func configurate(number: Int) {
        
        self.number = number
        if label == nil {
            let label = StrokedLabel(frame: CGRect(x: 0, y: 0, width: bounds.size.width, height: bounds.size.height))
            label.setText(text: number.description, align: .center, size: 38)
            self.label = label
            self.addSubview(label)
            label.setConstraints()
            label.isAccessibilityElement = GameHelper.SingleLabel_isAccessibilityElement
            
        } else {
            self.label!.setText(text: number.description, align: .center, size: 38)
        }
    }
    
    func disableConfiguration() {
        let view = UIView()
        view.backgroundColor = .clear
        self.backgroundView = view
        self.subviews.map({
            (view) in
            view.removeFromSuperview()
        })
        label = nil
    }
}
