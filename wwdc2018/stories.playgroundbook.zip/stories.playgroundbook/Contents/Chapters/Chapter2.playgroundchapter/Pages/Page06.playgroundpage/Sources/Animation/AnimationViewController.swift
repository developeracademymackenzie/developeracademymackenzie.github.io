import UIKit
import SpriteKit
import GameplayKit

public class AnimationViewController: UIViewController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        self.view = SKView(frame: self.view.frame)
        if let skview = self.view as? SKView {
            let scene = AnimationScene(size: self.view.frame.size)
            skview.presentScene(scene)
        }
    }
}
