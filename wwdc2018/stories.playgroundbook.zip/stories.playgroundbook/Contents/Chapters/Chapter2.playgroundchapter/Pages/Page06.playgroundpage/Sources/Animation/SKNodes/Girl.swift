import SpriteKit
import Foundation

class Girl: SKSpriteNode {
    
    override init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
        self.alpha = 0
    }
    
    func fadeInAnimation() {
        let fadeIn = SKAction.fadeIn(withDuration: 2.0)
        fadeIn.timingMode = .easeOut
        self.run(fadeIn)
    }
    
    func eyesAnimation() {
        var textures = [SKTexture]()
        
        for i in 1...27 {
            textures.append(SKTexture(image: UIImage(named: "Animation/Girl/AnimateLook_\(i)")!))
        }
        
        let animate = SKAction.animate(with: textures, timePerFrame: 0.18)
        self.run(animate)
    }
    
    func prepareForReading() {
        var textures = [SKTexture]()
        
        for i in 1...13 {
            textures.append(SKTexture(image: UIImage(named: "Animation/Girl/AnimateLook_\(14-i)")!))
        }
        
        let animate = SKAction.animate(with: textures, timePerFrame: 0.08)
        self.run(animate)
    }
    
    func moveAway() {
        let movement = SKAction.moveBy(x: 0, y: -(self.size.height * 2.5), duration: 1.0)
        movement.timingMode = .easeIn
        self.run(movement)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
