import Foundation

public class Progression {
    
    public var numbers: [Int]
    public var results: [Int] = [Int]()
    public var pointer: Int
    public var difference: Int
    
    public var numberCount: Int {
        get {
            return numbers.count
        }
    }
    
    
    public init(numbers count: Int, first value: Int, diff difference: Int) {
        self.numbers = Array(repeating: 0, count: count)
        self.numbers[0] = value
        self.numbers[1] = value + difference
        self.pointer = 1
        self.difference = difference
        self.results = self.calculateAllNumbers()
        
        for _ in self.results.count..<8 {
            let random = Int.randomInt(min: -8, max: 8)
            self.results.append(random)
        }
        
        self.results.shuffle()
        
    }
    
    public func validateNext(number: Int) -> Bool {
        if number - self.numbers[pointer] == difference {
            self.pointer += 1
            self.numbers[pointer] = number
            return true
        } else {
            return false
        }
    }
    
    public func validateCompletion() -> Bool {
        if self.pointer == numbers.count - 1 {
            return true
        }
        return false
    }
    
    public func calculateAllNumbers() -> [Int] {
        
        var numbers = [Int]()
        var current = self.numbers[1] + difference
        for _ in 2..<self.numbers.count {
            numbers.append(current)
            current += difference
        }
        return numbers
    }
    
    public func createAccessibility() -> AccessibilityStruct {
        if (pointer + 1 != numbers.count) {
            var text = "\(GameHelper.Progression_readMessage) "
            for i in 0..<pointer+1 {
                text += "\(Ordinal(rawValue: i)!) number: \(numbers[i]), "
            }
            
            var hint = "\(GameHelper.Progression_askMessage)"
            
            return AccessibilityStruct(text, hint)
        } else {
            
            var text = "Arithmetic Progression Complete, Good Job"
            return AccessibilityStruct(text, "Wait next progression")
        }
    }
    
}
