//
//  SecondViewController.swift
//  MyStoryboard
//
//  Created by Heitor Ishihara on 14/04/17.
//  Copyright © 2017 Heitor Ishihara. All rights reserved.
//

import Foundation
import SpriteKit

public class COSCurveSK {
    
    let graphWidth: CGFloat = 1
    let amplitude: CGFloat = 0.18
    
    var mainScene: SKScene = SKScene()
    
    var curvePath: [CGPoint] = []
    var currentPath: [CGPoint] = []
    
    var beginIndex = 0
    var endIndex = 3
    var maxIndex = 0

    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public init() {
        
    }
    
    public init(mainScene: SKScene) {
        self.mainScene = mainScene
    }
    
    public func getPath() {
        //Create the COS Curve path
        let width =  mainScene.size.width
        let height = mainScene.size.height
        
        let origin = CGPoint(x: 0, y: height / 2)
        for angle in stride(from: 0, through: 720.0, by: 0.1) {
            let x = origin.x + CGFloat(angle/720) * width * graphWidth
            let y = origin.y - CGFloat(cos(angle/180.0 * Double.pi)) * height * amplitude
            self.curvePath.append(CGPoint(x: x, y: y))
        }
        
        self.maxIndex = curvePath.count - 1
    }
    
    public func createCurveNode(points: [CGPoint]) -> SKShapeNode {
        
        var p = points
        
        let curvePathNode = SKShapeNode(splinePoints: &p, count: p.count)
        curvePathNode.fillColor = .clear
        curvePathNode.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        curvePathNode.lineWidth = 2
        curvePathNode.position = CGPoint(x: 0, y: 0) 
        
        return curvePathNode
    }
    
    public func getNextNodePoints() -> [CGPoint] {
        let newPath = Array(curvePath[self.beginIndex...endIndex])
        self.beginIndex = self.endIndex
        self.endIndex += 3
        
        self.currentPath = newPath
        return newPath
    }
    
    
}

