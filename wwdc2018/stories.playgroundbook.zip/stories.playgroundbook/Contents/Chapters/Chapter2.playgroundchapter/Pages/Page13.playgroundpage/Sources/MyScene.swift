import Foundation
import SpriteKit
import PlaygroundSupport

public class MyScene: SKScene {
    
    let sceneWidth: Double = 640
    let sceneHeight: Double = 480
    let sceneCenterX: Double = 640 / 2
    let sceneCenterY: Double = 480 / 2
    
    let auxNode = SKNode()
    
    var jumpsCount = 0
    var waitTime = 1.65
    
    var shouldPlayFirstViolin = false
    var cosCurve = COSCurveSK()
    var violinNodes: [SKShapeNode] = []
    
    var shouldPlaySecondViolin = false
    var cosCurve2 = COSCurveSK()
    var violinNodes2: [SKShapeNode] = []
    
    public func setup() {
        self.cosCurve = COSCurveSK(mainScene: self)
        cosCurve.getPath()
        
        self.cosCurve2 = COSCurveSK(mainScene: self)
        cosCurve2.getPath()
    }
    
    // -- First ACT --
    public func start() {
        
        //-- First Act --
        //-- Add Elements --
        //Add Big Center Point
        let centerPoint = SKShapeNode(path: CGPath(roundedRect: CGRect(x:0 , y: 0, width: self.size.width * 0.1, height: self.size.width * 0.1), cornerWidth: self.size.width * 0.1 / 4, cornerHeight: self.size.width * 0.1 / 4, transform: nil), centered: true)
        centerPoint.zRotation = .pi / 4
        centerPoint.position = CGPoint(x: sceneCenterX, y: sceneCenterY * 1.1)
        centerPoint.alpha = 0
        centerPoint.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        centerPoint.fillColor = .clear
        centerPoint.lineWidth = 1.5
        self.addChild(centerPoint)
        
        //Add Big Left Point
        let leftPoint = SKShapeNode(path: CGPath(roundedRect: CGRect(x:0 , y: 0, width: self.size.width * 0.1, height: self.size.width * 0.1), cornerWidth: self.size.width * 0.1 / 4, cornerHeight: self.size.width * 0.1 / 4, transform: nil), centered: true)
        leftPoint.zRotation = .pi / 4
        leftPoint.position = CGPoint(x: Double(centerPoint.position.x * 0.5), y: sceneCenterY * 0.8)
        leftPoint.alpha = 0
        leftPoint.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        leftPoint.fillColor = .clear
        leftPoint.lineWidth = 1.5
        self.addChild(leftPoint)
        
        
        //Add Big Right Point
        let rightPoint = SKShapeNode(path: CGPath(roundedRect: CGRect(x:0 , y: 0, width: self.size.width * 0.1, height: self.size.width * 0.1), cornerWidth: self.size.width * 0.1 / 4, cornerHeight: self.size.width * 0.1 / 4, transform: nil), centered: true)
        rightPoint.zRotation = .pi / 4
        rightPoint.position = CGPoint(x: Double(centerPoint.position.x * 1.5), y: sceneCenterY * 0.8)
        rightPoint.alpha = 0
        rightPoint.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        rightPoint.fillColor = .clear
        rightPoint.lineWidth = 1.5
        self.addChild(rightPoint)
        
        //Add Jumping Points
        let jumpingPointsWidth: Double = 10
        let jumpingPointsHeight: Double = 10
        let jumpingPointsCornerRadius: CGFloat = CGFloat(jumpingPointsWidth) / 4
        
        let jumpingPoint1 = SKShapeNode(path: CGPath(roundedRect: CGRect(x:0 , y: 0, width: jumpingPointsWidth, height: jumpingPointsHeight), cornerWidth: jumpingPointsCornerRadius, cornerHeight: jumpingPointsCornerRadius, transform: nil), centered: true)
        jumpingPoint1.zRotation = .pi / 4
        jumpingPoint1.position = CGPoint(x: sceneWidth / 4, y: -jumpingPointsWidth / 2 - 5)
        jumpingPoint1.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        jumpingPoint1.fillColor = .clear
        jumpingPoint1.lineWidth = 1.5
        self.addChild(jumpingPoint1)
        
        let jumpingPoint2 = SKShapeNode(path: CGPath(roundedRect: CGRect(x:0 , y: 0, width: jumpingPointsWidth, height: jumpingPointsHeight), cornerWidth: jumpingPointsCornerRadius, cornerHeight: jumpingPointsCornerRadius, transform: nil), centered: true)
        jumpingPoint2.zRotation = .pi / 4
        jumpingPoint2.position = CGPoint(x: sceneWidth / 4 * 2, y: -jumpingPointsWidth / 2 - 5)
        jumpingPoint2.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        jumpingPoint2.fillColor = .clear
        jumpingPoint2.lineWidth = 1.5
        self.addChild(jumpingPoint2)
        
        let jumpingPoint3 = SKShapeNode(path: CGPath(roundedRect: CGRect(x:0 , y: 0, width: jumpingPointsWidth, height: jumpingPointsHeight), cornerWidth: jumpingPointsCornerRadius, cornerHeight: jumpingPointsCornerRadius, transform: nil), centered: true)
        jumpingPoint3.zRotation = .pi / 4
        jumpingPoint3.position = CGPoint(x: sceneWidth / 4 * 3, y: -jumpingPointsWidth / 2 - 5)
        jumpingPoint3.strokeColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        jumpingPoint3.fillColor = .clear
        jumpingPoint3.lineWidth = 1.5
        self.addChild(jumpingPoint3)
        
        //-- Add Animations --
        let tempo = 0.31
        
        let jumpDuration: Double = tempo / 2
        let jumpHeight: CGFloat = CGFloat(jumpingPointsWidth * 10)
        
        //Big Center Point
        let fadeBigPointDuration = 1.0
        let fadeInBigPoint = SKAction.fadeIn(withDuration: fadeBigPointDuration)
        let fadeOutBigPoint = SKAction.fadeOut(withDuration: fadeBigPointDuration)
        let moveRigth1 = SKAction.moveBy(x: 2, y: 0, duration: tempo / 3.5)
        let moveRigth2 = SKAction.moveBy(x: 4, y: 0, duration: tempo / 3.5)
        let moveLeft1 = SKAction.moveBy(x: -2, y: 0, duration: tempo / 3.5)
        let moveLeft2 = SKAction.moveBy(x: -4, y: 0, duration: tempo / 3.5)
        centerPoint.run(SKAction.sequence([
            fadeInBigPoint,
            
            SKAction.repeat((SKAction.sequence([moveRigth1, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft1, SKAction.wait(forDuration: 0.45)])), count: 8),
            
            SKAction.wait(forDuration: jumpDuration * 2),
            
            SKAction.repeat((SKAction.sequence([moveRigth1, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft1, SKAction.wait(forDuration: 0.45)])), count: 8),
            
            fadeOutBigPoint
            ]))
        
        //Big Left Point
        leftPoint.run(SKAction.sequence([
            SKAction.wait(forDuration: tempo / 3.5 * 14 + 0.45),
            
            fadeInBigPoint,
            
            SKAction.repeat((SKAction.sequence([moveRigth1, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft1, SKAction.wait(forDuration: 0.45)])), count: 7),
            
            SKAction.wait(forDuration: jumpDuration * 2),
            
            SKAction.repeat((SKAction.sequence([moveRigth1, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft1, SKAction.wait(forDuration: 0.45)])), count: 7),
            
            fadeOutBigPoint
            ]))
        
        //Big Right Point
        rightPoint.run(SKAction.sequence([
            SKAction.wait(forDuration: tempo / 3.5 * 28 + 0.45 * 2),
            
            fadeInBigPoint,
            
            SKAction.repeat((SKAction.sequence([moveRigth1, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft1, SKAction.wait(forDuration: 0.45)])), count: 6),
            
            SKAction.wait(forDuration: jumpDuration * 2),
            
            SKAction.repeat((SKAction.sequence([moveRigth1, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft2, moveRigth2, moveLeft1, SKAction.wait(forDuration: 0.45)])), count: 7),
            
            fadeOutBigPoint
            ]))
        
        
        //Jumpings Points
        func jump(node: SKNode, jumpHeight: CGFloat, delay: Double) {
            let jump = SKAction.moveBy(x: 0, y: jumpHeight, duration: jumpDuration)
            jump.timingMode = .easeInEaseOut
            node.run(SKAction.sequence([SKAction.wait(forDuration: delay), jump, jump.reversed()]))
        }
        
        centerPoint.run(SKAction.sequence([
            SKAction.repeat(SKAction.group([
                SKAction.run({ jump(node: jumpingPoint1, jumpHeight: jumpHeight, delay: fadeBigPointDuration + 1 * tempo) }),
                SKAction.run({ jump(node: jumpingPoint2, jumpHeight: jumpHeight, delay: fadeBigPointDuration + 1 * tempo + jumpDuration * 2) }),
                SKAction.run({ jump(node: jumpingPoint3, jumpHeight: jumpHeight, delay: fadeBigPointDuration + 1 * tempo + jumpDuration * 4) }),
                
                SKAction.wait(forDuration: 1 + jumpDuration * 4.5)
                ]), count: 8),
            
            SKAction.wait(forDuration: jumpDuration / 2),
            
            SKAction.repeat(SKAction.group([
                SKAction.run({ jump(node: jumpingPoint1, jumpHeight: jumpHeight, delay: fadeBigPointDuration + 1 * tempo) }),
                SKAction.run({ jump(node: jumpingPoint2, jumpHeight: jumpHeight, delay: fadeBigPointDuration + 1 * tempo + jumpDuration * 2) }),
                SKAction.run({ jump(node: jumpingPoint3, jumpHeight: jumpHeight, delay: fadeBigPointDuration + 1 * tempo + jumpDuration * 4) }),
                SKAction.wait(forDuration: 1 + jumpDuration * 4.5)
                ]), count: 88),
            
            ]))
        
    }
    
    
    // -- Second ACT --
    var getFirstsCurvePart = false
    var n = 0
    
    var getFirstsCurvePart2 = false
    var n2 = 0
    
    public func playViolin() {
        self.run(SKAction.sequence([
            SKAction.wait(forDuration: 14.64),
            
            SKAction.run {
                self.shouldPlayFirstViolin = true
            },
            
            SKAction.wait(forDuration: 6.82),
            
            SKAction.run {
                self.shouldPlaySecondViolin = true
            }
            ]))
    }
    
    public func violinStart() {
        if n < 599 {
            if !getFirstsCurvePart {
                for _ in 0...3 {
                    let violinNode = self.cosCurve.createCurveNode(points: self.cosCurve.getNextNodePoints())
                    
                    self.violinNodes.append(violinNode)
                    self.addChild(violinNode)
                }
                
                getFirstsCurvePart = true
//                initialTime = currentTime
            } else {
                if cosCurve.endIndex < cosCurve.maxIndex {
                    let newViolinNode1 = self.cosCurve.createCurveNode(points: self.cosCurve.getNextNodePoints())
                    let newViolinNode2 = self.cosCurve.createCurveNode(points: self.cosCurve.getNextNodePoints())
                    let newViolinNode3 = self.cosCurve.createCurveNode(points: self.cosCurve.getNextNodePoints())
                    let newViolinNode4 = self.cosCurve.createCurveNode(points: self.cosCurve.getNextNodePoints())
                    let newViolinNode5 = self.cosCurve.createCurveNode(points: self.cosCurve.getNextNodePoints())
                    
                    self.addChild(newViolinNode1)
                    self.violinNodes.append(newViolinNode1)
                    self.addChild(newViolinNode2)
                    self.violinNodes.append(newViolinNode2)
                    self.addChild(newViolinNode3)
                    self.violinNodes.append(newViolinNode3)
                    self.addChild(newViolinNode4)
                    self.violinNodes.append(newViolinNode4)
                    self.addChild(newViolinNode5)
                    self.violinNodes.append(newViolinNode5)
                }
                
                guard let first1 = violinNodes.first else { return }
                first1.removeFromParent()
                self.violinNodes.removeFirst()
                guard let first2 = violinNodes.first else { return }
                first2.removeFromParent()
                self.violinNodes.removeFirst()
                guard let first3 = violinNodes.first else { return }
                first3.removeFromParent()
                self.violinNodes.removeFirst()
                guard let first4 = violinNodes.first else { return }
                first4.removeFromParent()
                self.violinNodes.removeFirst()
                n += 1
            }
        }
//        else {
//            self.run(SKAction.sequence([
//                SKAction.wait(forDuration: 1.5),
//
//                SKAction.run {
//                    self.n = 0
//                    self.getFirstsCurvePart = false
//                    self.violinNodes.removeAll()
//                    self.cosCurve = COSCurveSK(mainScene: self)
//                    self.cosCurve.getPath()
//                }
//                ]))
//        }
    }
    
    public func violinStart2() {
        if n2 < 599 {
            if !getFirstsCurvePart2 {
                for _ in 0...3 {
                    let violinNode = self.cosCurve2.createCurveNode(points: self.cosCurve2.getNextNodePoints())
                    self.violinNodes2.append(violinNode)
                    self.addChild(violinNode)
                }
                getFirstsCurvePart2 = true
            } else {
                if cosCurve2.endIndex < cosCurve2.maxIndex {
                    let newViolinNode1 = self.cosCurve2.createCurveNode(points: self.cosCurve2.getNextNodePoints())
                    let newViolinNode2 = self.cosCurve2.createCurveNode(points: self.cosCurve2.getNextNodePoints())
                    let newViolinNode3 = self.cosCurve2.createCurveNode(points: self.cosCurve2.getNextNodePoints())
                    let newViolinNode4 = self.cosCurve2.createCurveNode(points: self.cosCurve2.getNextNodePoints())
                    let newViolinNode5 = self.cosCurve2.createCurveNode(points: self.cosCurve2.getNextNodePoints())
                    
                    self.addChild(newViolinNode1)
                    self.violinNodes2.append(newViolinNode1)
                    self.addChild(newViolinNode2)
                    self.violinNodes2.append(newViolinNode2)
                    self.addChild(newViolinNode3)
                    self.violinNodes2.append(newViolinNode3)
                    self.addChild(newViolinNode4)
                    self.violinNodes2.append(newViolinNode4)
                    self.addChild(newViolinNode5)
                    self.violinNodes2.append(newViolinNode5)
                }
                
                guard let first1 = violinNodes2.first else { return }
                first1.removeFromParent()
                self.violinNodes2.removeFirst()
                guard let first2 = violinNodes2.first else { return }
                first2.removeFromParent()
                self.violinNodes2.removeFirst()
                guard let first3 = violinNodes2.first else { return }
                first3.removeFromParent()
                self.violinNodes2.removeFirst()
                guard let first4 = violinNodes2.first else { return }
                first4.removeFromParent()
                self.violinNodes2.removeFirst()
                n2 += 1
            }
        }
//        else {
//            self.run(SKAction.sequence([
//                SKAction.wait(forDuration: 1.5),
//
//                SKAction.run {
//                    self.n2 = 0
//                    self.getFirstsCurvePart2 = false
//                    self.violinNodes2.removeAll()
//                    self.cosCurve2 = COSCurveSK(mainScene: self)
//                    self.cosCurve2.getPath()
//                }
//                                        ]))
//        }
    }
    
    // -- Third ACT --
    
    public func guitarStart() {
        self.run(SKAction.sequence([
            SKAction.wait(forDuration: 28),
            
            SKAction.run {
                self.addGuitar()
            }
            
            ]))
        
    }
    
    public func addGuitar() {
        //Add Strings
        let stringWidth = sceneWidth * 0.55
        let stringHeight = 1.0
        let xPosition = sceneCenterX - stringWidth / 2
        let stringSpacement = 20.0
        
        var strings: [SKShapeNode] = []
        
        strings.append(SKShapeNode(ellipseIn: CGRect(x: xPosition, y: sceneCenterY - 3 * stringSpacement, width: stringWidth, height: stringHeight)))
        strings[0].strokeColor = .red
        strings[0].fillColor = .red
        
        strings.append(SKShapeNode(ellipseIn: CGRect(x: xPosition, y: sceneCenterY - 2 * stringSpacement, width: stringWidth, height: stringHeight)))
        strings[1].strokeColor = .red
        strings[1].fillColor = .red
        
        strings.append(SKShapeNode(ellipseIn: CGRect(x: xPosition, y: sceneCenterY - 1 * stringSpacement, width: stringWidth, height: stringHeight)))
        strings[2].strokeColor = .red
        strings[2].fillColor = .red
        
        strings.append(SKShapeNode(ellipseIn: CGRect(x: xPosition, y: sceneCenterY - 0 * stringSpacement, width: stringWidth, height: stringHeight)))
        strings[3].strokeColor = .red
        strings[3].fillColor = .red
        
        strings.append(SKShapeNode(ellipseIn: CGRect(x: xPosition, y: sceneCenterY + 1 * stringSpacement, width: stringWidth, height: stringHeight)))
        strings[4].strokeColor = .red
        strings[4].fillColor = .red
        
        strings.append(SKShapeNode(ellipseIn: CGRect(x: xPosition, y: sceneCenterY + 2 * stringSpacement, width: stringWidth, height: stringHeight)))
        strings[5].strokeColor = .red
        strings[5].fillColor = .red
        
        for string in strings {
            string.alpha = 0
            self.addChild(string)
            string.fadeIn()
        }
        
        //Add Circle
        let circle = SKShapeNode(circleOfRadius: 80)
        circle.position = CGPoint(x: sceneCenterX, y: sceneCenterY - stringSpacement / 2)
        circle.lineWidth = 2
        circle.alpha = 0
        circle.strokeColor = .red
        circle.fillColor = .clear
        
        self.addChild(circle)
        circle.fadeIn()
        
        //Add Second Circle
        let circle2 = SKShapeNode(circleOfRadius: 68)
        circle2.position = CGPoint(x: sceneCenterX, y: sceneCenterY - stringSpacement / 2)
        circle2.lineWidth = 2
        circle2.alpha = 0
        circle2.strokeColor = .red
        circle2.fillColor = .clear
        
        self.addChild(circle2)
        circle2.fadeIn()
        
    }
    
    override public func update(_ currentTime: TimeInterval) {
        if shouldPlayFirstViolin {
            self.violinStart()
        }
        
        if shouldPlaySecondViolin {
            self.violinStart2()
        }
    }
}

public extension SKShapeNode {
    public func vibe() {
        self.run(SKAction.sequence([
            SKAction.moveBy(x: 0, y: 2, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 4, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 4, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 4, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 4, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 4, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 4, duration: 0.1),
            SKAction.moveBy(x: 0, y: -4, duration: 0.1),
            SKAction.moveBy(x: 0, y: 2, duration: 0.1),
            ]))
    }
    
    public func fadeIn() {
        self.run(SKAction.fadeIn(withDuration: 1.3))
    }
}
