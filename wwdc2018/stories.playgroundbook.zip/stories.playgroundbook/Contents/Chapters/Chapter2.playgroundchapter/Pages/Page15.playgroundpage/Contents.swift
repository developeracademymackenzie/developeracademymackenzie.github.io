/*: Julio Brazil Bellucci Lopes
 
 ![Julio](julio.png)
 
 # Julio Brazil Bellucci Lopes
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Climate Change
 
 ### Essential Question
 How to make a engaging playground about climate change?
 
 ### Challenge
 Make a logic game with the subtle message about climate change.
 
 - - -
 
 My playground idea came up after several discussions, I wanted to make a logic game, but also touch on a meaningful topic, like bullying or climate change, after several iterations of the idea, I decided to make a "river crossing" style of game with polar animals.
 
 I learned so much in the past year, the problems I had to figure out where mere playground quirks, not learning a whole new programming language along a complete and complex environment.
 
 what I learnt with every single challenge is: preparation matters, the best way to approach stuff is with caution, it is better to flash out the idea before you touch any code.
 
 Last year's playground has been sitting on the same folder untouched since submission, the code was poorly written and the idea was lacklustre, I have evolved  great deal since then and plan to revisit that idea sometime in the future.
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))

if let scene = GameScene(fileNamed: "GameScene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFit
    
    var boatSize = -1
    var animals: [AnimalType] = []
    //#-end-hidden-code
    boatSize = /*#-editable-code Number of animals that the boat can carry*/2/*#-end-editable-code*/
    animals = /*#-editable-code Animals in the game*/[.bear, .walrus, .fish, .penguin, .seal]/*#-end-editable-code*/
    
    //#-hidden-code
    if boatSize < 1 {
        boatSize = 1
    } else if boatSize > animals.count {
        boatSize = animals.count
    }
    if animals == [] {
        animals = [.bear, .walrus, .fish]
    }
    
    scene.boatSize = boatSize
    scene.animals = animals
    
    if let endScene = SKScene(fileNamed: "EndScene") {
        endScene.scaleMode = .aspectFit
        
        scene.nextScene = endScene
    }
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code









