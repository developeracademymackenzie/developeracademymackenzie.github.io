import Foundation

public enum BoatState {
    case onTheLeft
    case travelling
    case onTheRight
}
