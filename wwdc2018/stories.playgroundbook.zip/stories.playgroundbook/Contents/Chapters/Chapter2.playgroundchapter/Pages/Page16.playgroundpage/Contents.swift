/*: Kaique Magno dos Santos
 
 ![Kaique](kaique.png)
 
 # Kaique Magno dos Santos
 
 - - -
 XCode
 - - -
 
 ### Big Idea
 Education
 
 ### Essential Question
 How teach physics?
 
 ### Challenge
 Create a playground to teach about force in objects.
 
 - - -
 
 My playground is a game which the player must put the ball inside the cup. My inspiration came through my difficulties to learn physics when I was a kid.
 
 My idea was the same then last year but this time I tried to make it better at least the code but unhappily I could not achieve that. I used the same idea than last year because I could find another one so fast after I burn two ideas already because technical limitations and knowledge limitations. In the end I just realize than I am no the creative kind of person, I am better just executing. After realize that I lost all hope to win because in my vision the Scholarship is for creative people who have great ideas even when the coding is not the best. So I just lost all the energy and fun which I was applying to my Playground and because of that sorry for my result.
 
  ![Screen](screen.png)
 */














