import Foundation

public class Math {
    // this functions returns a random number bettween 0 and 2, different from the passed argument
    public static func random(max: UInt32, differentOf number: Int?) -> Int {
        var random: Int = Int(arc4random_uniform(max))
        if number != nil { while random == number { random = Int(arc4random_uniform(max)) } }
        return random
    }
}
