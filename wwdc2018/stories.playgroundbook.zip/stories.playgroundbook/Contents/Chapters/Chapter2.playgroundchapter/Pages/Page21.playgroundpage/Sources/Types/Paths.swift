import Foundation

public struct Paths {
    public static let square: String = "./shapes/square"
    public static let triangle: String = "./shapes/triangle"
    public static let star: String = "./shapes/star"
    
    public static let squareWhite: String = "./shapes/square_white"
    public static let triangleWhite: String = "./shapes/triangle_white"
    public static let starWhite: String = "./shapes/star_white"
    
    public static let squareCard: String = "./shapes/square_card"
    public static let triangleCard: String = "./shapes/triangle_card"
    public static let starCard: String = "./shapes/star_card"
    
    public static let orange: String = "./colors/orange"
    public static let green: String = "./colors/green"
    public static let blue: String = "./colors/blue"
}
