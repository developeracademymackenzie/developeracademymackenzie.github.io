import Foundation

public enum Scene: String {
    case Start = "StartScene"
    case Game = "GameScene"
}
