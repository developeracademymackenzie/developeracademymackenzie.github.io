import UIKit

struct Point {
    let location: CGPoint
    
    init(location: CGPoint) {
        self.location = location
    }
}

