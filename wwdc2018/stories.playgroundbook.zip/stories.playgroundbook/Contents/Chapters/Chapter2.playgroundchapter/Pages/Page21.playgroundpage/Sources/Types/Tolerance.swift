import UIKit

enum Tolerance: CGFloat {
    case High = 15.0
    case Medium = 7.0
    case Low = 3.0
    case None = 0.0
}

