import SpriteKit

protocol SceneProtocol {
    var scene: SKScene? { get }
    init(scene: SKScene)
    func fadeIn(completion: (() -> Void)?)
    func fadeOut(completion: (() -> Void)?)
    func didTap(at location: CGPoint)
}

