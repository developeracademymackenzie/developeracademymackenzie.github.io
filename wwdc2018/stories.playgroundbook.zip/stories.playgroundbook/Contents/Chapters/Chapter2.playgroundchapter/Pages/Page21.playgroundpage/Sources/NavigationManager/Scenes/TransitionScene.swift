import Foundation

import SpriteKit

class TransitionScene: SceneProtocol {
    //MARK: - Properties
    var scene: SKScene?
    
    private var lineNodes: [SKSpriteNode] = []
    
    private var lineWidth: CGFloat?
    private var lineHeight: CGFloat?
    private var initialRightX: CGFloat!
    private var initialLeftX: CGFloat!
    
    private let animationDuration: TimeInterval = 1
    
    //MARK: - Initializers
    required init(scene: SKScene) {
        self.scene = scene
        self.lineWidth = self.scene?.view?.width
        self.lineHeight = (self.scene?.view?.height)! / 10
        self.setUpLines()
    }
    
    //MARK: - Scene protocol functions
    func fadeIn(completion: (() -> Void)?) {
        let fadeIn = SKAction.fadeIn(withDuration: self.animationDuration)
        let fadeOut = SKAction.run { self.fadeOut(completion: completion) }
        
        let moveLeft = SKAction.moveTo(x: 0, duration: self.animationDuration)
        let moveLeftGroup = SKAction.group([fadeIn, moveLeft])
        
        let moveRight = SKAction.moveTo(x: 0, duration: self.animationDuration)
        let moveRightGroup = SKAction.group([fadeIn, moveRight])
        
        var right: Bool = true
        for i in 0..<self.lineNodes.count-1 {
            let lineNode = self.lineNodes[i]
            lineNode.run(right ? moveLeftGroup : moveRightGroup)
            right = !right
        }
        if let lastLineNode = self.lineNodes.last {
            lastLineNode.run(right ? SKAction.sequence([moveLeftGroup, fadeOut]) : SKAction.sequence([moveRightGroup, fadeOut]))
        }
    }
    
    func fadeOut(completion: (() -> Void)?) {
        if let position = self.scene?.view?.width(divededBy: 4) {
            let fadeOut = SKAction.fadeOut(withDuration: self.animationDuration)
            let completion = SKAction.run { if let c = completion { c() } }
            
            let moveLeft = SKAction.moveTo(x: -position, duration: self.animationDuration)
            let moveLeftGroup = SKAction.group([fadeOut, moveLeft])
            
            let moveRight = SKAction.moveTo(x: position, duration: self.animationDuration)
            let moveRightGroup = SKAction.group([fadeOut, moveRight])
            
            var right: Bool = true
            for i in 0..<self.lineNodes.count-1 {
                let lineNode = self.lineNodes[i]
                let initialX = right ? self.initialRightX : self.initialLeftX
                let returnToInitialPosition = SKAction.run { lineNode.position.x = initialX! }
                let move = right ? moveLeftGroup : moveRightGroup
                let sequence = SKAction.sequence([move, returnToInitialPosition])
                lineNode.run(sequence)
                right = !right
            }
            if let lastLineNode = self.lineNodes.last {
                let initialX = right ? self.initialRightX : self.initialLeftX
                let returnToInitialPosition = SKAction.run { lastLineNode.position.x = initialX! }
                let move = right ? moveLeftGroup : moveRightGroup
                let sequence = SKAction.sequence([move, completion, returnToInitialPosition])
                lastLineNode.run(sequence)
            }
        }
    }
    
    func didTap(at location: CGPoint) {
}
    
    //MARK: - SetUp functions
    private func setUpLines() {
        
        if let viewHeight = self.scene?.view?.height, var lw = self.lineWidth, let lh = self.lineHeight {
            lw *= 2
            let lines = viewHeight / lh
            self.initialRightX = self.lineWidth!/4
            self.initialLeftX = -self.initialRightX
            var right: Bool = true
            
            for i in 0...Int(lines) {
                let lineColor = UIColor.clear
                let lineSize = CGSize(width: lw, height: self.lineHeight!)
                let lineNode = SKSpriteNode(color: lineColor, size: lineSize)
                let x = right ? self.initialRightX : self.initialLeftX
                let y = (CGFloat(i) * lh) - (viewHeight / 2)
                lineNode.position = CGPoint(x: x!, y: y)
                self.lineNodes.append(lineNode)
                right = !right
                let boxes = lw / lh
                let boxSize = CGSize(width: lh, height: lh)
                let shapes = [Paths.squareWhite, Paths.triangleWhite, Paths.starWhite]
                let colors = [Paths.orange, Paths.green, Paths.blue]
                var lastShape: Int = 1;
                for j in 0...Int(boxes) {
                    lastShape = Math.random(max: 3, differentOf: lastShape)
                    let x = (CGFloat(j) * lh) - (lw / 2)
                    
                    let shapeNode = SKSpriteNode(imageNamed: shapes[lastShape])
                    shapeNode.size = CGSize(width: lh * 0.5, height: lh * 0.5)
                    shapeNode.position = CGPoint.zero
                    
                    let boxNode = SKSpriteNode(imageNamed: colors[lastShape])
                    boxNode.size = boxSize
                    boxNode.position = CGPoint(x: x, y: 0)
                    boxNode.addChild(shapeNode)
                    
                    lineNode.addChild(boxNode)
                }
                print(lineNode.position)
                lineNode.alpha = 0
                self.scene?.addChild(lineNode)
            }
        }
    }
    
}
