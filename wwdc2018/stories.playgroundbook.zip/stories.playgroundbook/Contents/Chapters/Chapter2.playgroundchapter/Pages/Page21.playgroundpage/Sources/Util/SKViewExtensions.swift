import SpriteKit

extension SKView {
    var width: CGFloat { return self.frame.width }
    var height: CGFloat { return self.frame.height }
    func width(divededBy num: Int) -> CGFloat { return self.width/CGFloat(num) }
    func height(divededBy num: Int) -> CGFloat { return self.height/CGFloat(num) }
}

