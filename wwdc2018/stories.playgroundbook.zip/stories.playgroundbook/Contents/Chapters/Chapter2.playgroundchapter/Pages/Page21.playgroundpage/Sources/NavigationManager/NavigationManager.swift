import SpriteKit

public class NavigationManager {
    
    //MARK: - Properties
    private var scene: SKScene
    private var currentScene: Scene?
    private var scenes: [Scene:SceneProtocol] = [Scene:SceneProtocol]()
    private var transition: SceneProtocol?
    
    //MARK: - Initializers
    public init(scene: SKScene) {
        self.scene = scene
        self.scenes[Scene.Start] = StartScene(scene: self.scene)
        self.transition = TransitionScene(scene: self.scene)
    }
    
    //MARK: - Navigation functions
    public func goTo(scene: Scene, withTranstion: Bool, completion: (()->Void)?) {
        if let currentScene = self.currentScene, let currentSceneInstance = self.scenes[currentScene], let newScene = self.scenes[scene] {
            self.currentScene = scene
            if withTranstion {
                currentSceneInstance.fadeOut(completion: {
                    self.transition?.fadeIn(completion: {
                        newScene.fadeIn(completion: completion)
                    })
                })
            } else {
                currentSceneInstance.fadeOut(completion: {
                    newScene.fadeIn(completion: completion)
                })
            }
        }
    }
    
    public func showStart(completion: (()->Void)?) {
        self.currentScene = .Start
        self.scenes[.Start]?.fadeIn(completion: nil)
    }
    
}

