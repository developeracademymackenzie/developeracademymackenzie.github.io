//
//  BoxLayer.swift
//  MentalCalculation
//
//  Created by Gustavo Rodrigues on 20/03/18.
//  Copyright © 2018 Gustavo Rodrigues. All rights reserved.
//

import UIKit
public class BoxLayer: CAShapeLayer{
    public override init() {
        super.init()
        fillColor = Colors.clear.cgColor
        lineWidth = 5.0
        path = rectanglePathFull.cgPath
    }
    
    public required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var rectanglePathFull: UIBezierPath {
        let rectanglePath = UIBezierPath()
        rectanglePath.move(to: CGPoint(x: 0.0, y: 273.0))
        rectanglePath.addLine(to: CGPoint(x: 0.0, y: 0.0))
        rectanglePath.addLine(to: CGPoint(x: 273.0, y: 0.0))
        rectanglePath.addLine(to: CGPoint(x: 273.0, y: 273.0))
        rectanglePath.addLine(to: CGPoint(x: -lineWidth / 2, y: 273.0))
        rectanglePath.close()
        return rectanglePath
    }
    
    func animateStrokeWithColor(color: UIColor) {
        strokeColor = color.cgColor
        let strokeAnimation: CABasicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        strokeAnimation.fromValue = 0.0
        strokeAnimation.toValue = 1.0
        strokeAnimation.duration = 0.9
        add(strokeAnimation, forKey: nil)
    }
    
}
