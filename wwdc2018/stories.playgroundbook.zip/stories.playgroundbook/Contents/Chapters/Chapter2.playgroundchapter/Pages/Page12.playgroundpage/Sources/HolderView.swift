//
//  HolderView.swift
//  MentalCalculation
//
//  Created by Gustavo Rodrigues on 20/03/18.
//  Copyright © 2018 Gustavo Rodrigues. All rights reserved.
//

import UIKit
import SpriteKit

protocol HolderViewDelegate:class {
    func animateLabel()
}

public class HolderView:  UIView {
    
    let redRectangleLayer = BoxLayer()
    let blueRectangleLayer = BoxLayer()
    let cyanRectangleLayer = BoxLayer()
    
    var parentFrame :CGRect = CGRect.zero
    weak var delegate:HolderViewDelegate?
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = Colors.clear
        center = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2)
    }
    
    public required init(coder: NSCoder) {
        super.init(coder: coder)!
    }
    func drawAnimatedRectangle() {
        Timer.scheduledTimer(timeInterval:0.0, target: self,
                             selector: #selector(self.drawRedAnimatedRectangle),
                                               userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:0.3, target: self,
                             selector: #selector(self.drawCyanAnimatedRectangle),
                                               userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:0.6, target: self,
                             selector: #selector(self.drawBlueAnimatedRectangle),
                                                userInfo: nil, repeats: false)
    }
    @objc func drawRedAnimatedRectangle() {
        layer.addSublayer(redRectangleLayer)
        redRectangleLayer.animateStrokeWithColor(color: Colors.red)
    }
    
    @objc func drawCyanAnimatedRectangle() {
        layer.addSublayer(cyanRectangleLayer)
        cyanRectangleLayer.animateStrokeWithColor(color: Colors.cyan)
    }
    
    @objc func drawBlueAnimatedRectangle() {
        layer.addSublayer(blueRectangleLayer)
        blueRectangleLayer.animateStrokeWithColor(color: Colors.blue)
        Timer.scheduledTimer(timeInterval: 0.90, target: self, selector: #selector(self.fill),
                                                                            userInfo: nil, repeats: false)
    }
    
    @objc func fill() {
        UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseInOut, animations: {
            self.backgroundColor = Colors.blue
            }, completion: nil)
        Timer.scheduledTimer(timeInterval: 0.0, target: self, selector: #selector(self.flip),
                                               userInfo: nil, repeats: false)
    }
    @objc func flip(){
        UIView.transition(with: self, duration: 0.8, options: .transitionFlipFromBottom, animations: nil, completion: nil)
        Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.addLabel),
                             userInfo: nil, repeats: false)
    }

    @objc func addLabel() {
        delegate?.animateLabel()
    }
    
}
