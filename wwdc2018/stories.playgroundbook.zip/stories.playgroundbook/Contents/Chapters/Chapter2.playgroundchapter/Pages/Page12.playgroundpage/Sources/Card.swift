//
//  Card.swift
//  MentalCalculation
//
//  Created by Gustavo Rodrigues on 22/03/18.
//  Copyright © 2018 Gustavo Rodrigues. All rights reserved.
//

import UIKit

public class Card : UIView {
    
    var number : Int
    
    public override init(frame: CGRect) {
        self.number = 0
        super.init(frame: frame)
    }
    
    public func addLabel(){
        let label: UILabel = UILabel(frame: self.frame)
        label.textColor = Colors.beige
        label.center = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2)
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 90.0)
        label.textAlignment = .center
        label.text = "\(number)"
        self.addSubview(label)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
