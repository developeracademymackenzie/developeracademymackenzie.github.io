//
//  CardResult.swift
//  MentalCalculation
//
//  Created by Gustavo Rodrigues on 22/03/18.
//  Copyright © 2018 Gustavo Rodrigues. All rights reserved.
//

import UIKit

public class CardResult : UIView{
    
    var options : [UIButton] = [UIButton()]
    let sharedData = SharedData.data
    var callback : (()->())?
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = Colors.clear
        showOptions()
        
    }
    func random (lower: Int , upper: Int) -> Int {
        return lower + Int(arc4random_uniform(UInt32(upper - lower + 1)))
    }
    func addNumberSquare(_ b: UIButton, _ number: Int){
        
        let label: UILabel = UILabel(frame: b.frame)
        
        label.center = CGPoint(x: b.frame.width / 2, y: b.frame.height / 2)
        if b.frame == CGRect(x: frame.midX+91, y: frame.midY+91, width: 91.0, height: 91.0){
            label.textColor = Colors.red
        } else {
           label.textColor = Colors.beige
        }
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 30.0)
        label.textAlignment = .center
        label.text = "\(number)"
        b.tag = number
        b.addSubview(label)
        b.addTarget(self, action: #selector(CardResult.buttonAction(_:)), for: .touchUpInside)
    }
    
    @objc func buttonAction(_ sender:UIButton!){
        print(sender.tag)
        if sharedData.sum == sender.tag {
            sharedData.right += 1
            sharedData.isRight = true
            print("ACERTOU")
        }else{
            sharedData.wrong += 1
            sharedData.isRight = false
            print("ERROU")
        }
        sharedData.sum = 0
        callback?()
    }
    
    @objc func showOptions(){
        
        let view0 = UIButton(frame: CGRect(x: self.frame.midX, y: self.frame.midY+182, width: 91.0, height: 91.0))
        view0.backgroundColor = Colors.cyan
        options.append(view0)
        let view1 = UIButton(frame: CGRect(x: self.frame.midX+91, y: self.frame.midY+182, width: 91.0, height: 91.0))
        view1.backgroundColor = Colors.red
        options.append(view1)
        let view2 = UIButton(frame: CGRect(x: frame.midX+182, y: frame.midY+182, width: 91.0, height: 91.0))
        view2.backgroundColor = Colors.cyan
        options.append(view2)
        let view3 = UIButton(frame: CGRect(x: frame.midX, y: frame.midY+91, width: 91.0, height: 91.0))
        view3.backgroundColor = Colors.blue
        options.append(view3)
        let view4 = UIButton(frame: CGRect(x: frame.midX+91, y: frame.midY+91, width: 91.0, height: 91.0))
        view4.backgroundColor = Colors.beige
        options.append(view4)
        let view5 = UIButton(frame: CGRect(x: frame.midX+182, y: frame.midY+91, width: 91.0, height: 91.0))
        view5.backgroundColor = Colors.blue
        options.append(view5)
        let view6 = UIButton(frame: CGRect(x: frame.midX, y: frame.midY, width: 91.0, height: 91.0))
        view6.backgroundColor = Colors.cyan
        options.append(view6)
        let view7 = UIButton(frame: CGRect(x: frame.midX+91, y: frame.midY, width: 91.0, height: 91.0))
        view7.backgroundColor = Colors.red
        options.append(view7)
        let view8 = UIButton(frame: CGRect(x: frame.midX+182, y: frame.midY, width: 91.0, height: 91.0))
        view8.backgroundColor = Colors.cyan
        options.append(view8)
        
        
        let randomIndex = random(lower: 0, upper: 9)
        addNumberSquare(options[randomIndex], sharedData.sum)
        self.addSubview(options[randomIndex])
        var numbersArray : [Int] = []
        numbersArray.append(sharedData.sum)
        for i in 0...9{
            var number: Int!
            if i != randomIndex{
                repeat{
                    number = random(lower: -30, upper: 30)
                    
                }while numbersArray.contains(number)
                numbersArray.append(number)
                addNumberSquare(options[i], number)
                self.addSubview(options[i])
            }
        }
    }
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
