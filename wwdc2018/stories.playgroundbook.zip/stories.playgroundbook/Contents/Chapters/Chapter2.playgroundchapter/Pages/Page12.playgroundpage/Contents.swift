/*: Gustavo Soares Mascarenhas Rodrigues
 
 ![Gustavo](gustavo.png)
 
 # Gustavo Soares Mascarenhas Rodrigues
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Game
 
 ### Essential Question
 How to know if a user is good at solving mental calculations?
 
 ### Challenge
 Game that tests how many mathematical exercises the user can do
 
 - - -
 
 In this Playground the user has to solve mathematical calculations as the numbers go on the screen and then give the result. At the end, the user will know the total number of resolved accounts, the number of correct and incorrect calculations and the percentage of correct answers. What inspired me was an idea I had from the problem I had in solving mathematical calculations quickly in everyday life.
 
 This year I had a lot more experience with the tool and the programming language, and I already have an idea in mind from the beginning and I was able to finish according to what I had planned. Last year I learned how the playground worked and its weaknesses and it helped me decide what could be done. I did not use what I did last year because the idea I had this year was quite different.
 */




//#-hidden-code
import PlaygroundSupport
import UIKit

let controller = ViewController()

PlaygroundPage.current.liveView = controller
//#-end-hidden-code






