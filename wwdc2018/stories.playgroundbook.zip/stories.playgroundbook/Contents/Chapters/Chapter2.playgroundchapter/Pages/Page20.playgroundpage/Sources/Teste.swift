//
//  teste.swift
//  ColaParaWWDC
//
//  Created by Pedro Del Rio Ortiz on 28/03/2018.
//  Copyright © 2018 Pedro Del Rio Ortiz. All rights reserved.
//

import Foundation
import SpriteKit

class Teste: SKShapeNode {
    
    override init() {
        super.init()
        self.strokeColor = SKColor.green
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("KKKfgdgdfgLLA")
    }
}
