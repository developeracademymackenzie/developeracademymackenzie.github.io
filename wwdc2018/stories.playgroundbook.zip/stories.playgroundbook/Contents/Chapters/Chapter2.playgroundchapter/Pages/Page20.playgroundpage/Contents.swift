/*: Pedro Del Rio Ortiz
 
 ![Pedro](pedro.png)
 
 # Pedro Del Rio Ortiz
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Interactive Animation
 
 ### Essential Question
How to make an interactive animation to be approved by WWDC?
 
 ### Challenge
 Interactive playground showing and teaching about Earth's geological ages.
 
 - - -
 
 It shows interactive information about features and being from different geological eras. What inspired me was my passion for the history of the land and the animals that inhabited it.
 
 I learned so much things, how to code better and many techniques that allow me to have a better code and a better idea, in this year I though what I really need to do if I want to pass in the WWDC scholarship.
 
 */

//#-hidden-code
import UIKit
import SpriteKit
import PlaygroundSupport


let rect = CGRect(x: 0, y: 0, width: 720, height: 480)
let view = SKView(frame: rect)
view.backgroundColor = UIColor.blue
let scene = MainScene(size: rect.size)

scene.backgroundColor = SKColor.red
scene.scaleMode = .aspectFit

view.presentScene(scene)
PlaygroundPage.current.liveView = view
//#-end-hidden-code
