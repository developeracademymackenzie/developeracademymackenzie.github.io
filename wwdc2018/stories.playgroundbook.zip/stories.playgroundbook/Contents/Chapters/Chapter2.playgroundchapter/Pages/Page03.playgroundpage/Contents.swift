/*: Ane Caroline Santos Gomes
 
 ![Ane](ane.png)
 
 # Ane Caroline Santos Gomes
 
 - - -
 XCode
 - - -
 
 ### Big Idea
 Entertainment / Education
 
 ### Essential Question
 How to help children with autism spectrum disorder?
 
 ### Challenge
 Offer an interactive tool which helps to join the words while helps in the process of memorizing
 
 - - -
 
 The main objective is joining the corresponding parts of the syllables of a specific word. Then, by union of the correct syllables, the word is formed and consequently its figure is shown.
 
 First, the code has been improved. In addition, changes were made to the dynamics of the game, as well as new animations and sounds were added.

 ![Ane](playground_ane.png)
*/




//#-hidden-code

//#-end-hidden-code
