/*: Ricardo Daniel Nogueira de Sousa
 
 ![Ricardo](ricardo.png)
 
 # Ricardo Daniel Nogueira de Sousa
 */

//#-hidden-code

//#-end-hidden-code


