import Foundation
import SpriteKit



public class Scene: SKScene {
    
    var viewSize = CGRect(x: 0, y: 0, width: 666.99, height: 359.73)
    var midPoint = CGPoint(x: 0, y: 0)
    
    var ideaTip = TipNode.init(nodeName: "ideaTip", initialImage: UIImage.init(named: "ideaTip.png")!)
    var swiftTip = TipNode.init(nodeName: "swiftTip", initialImage: UIImage.init(named: "swiftTip.png")!)
    var musicTip = TipNode.init(nodeName: "musicTip", initialImage: UIImage.init(named: "musicTip.png")!)
    var appleTip = TipNode.init(nodeName: "appleTip", initialImage: UIImage.init(named: "appleTip.png")!)
    var swiftIcon = AnimatedNode.init(nodeName: "swiftIcon", initialImage: UIImage(named: "swiftIcon.png")!)
    var birds = AnimatedNode.init(nodeName: "birds", initialImage: UIImage(named: "birdsInitial.png")!)
    var tree = AnimatedNode.init(nodeName: "tree", initialImage: UIImage(named: "treeInitial.png")!)
    var peopleTalking = AnimatedNode.init(nodeName: "peopleTalking", initialImage: UIImage(named: "talkingInitial.png")!)
    var jumpingRope = AnimatedNode.init(nodeName: "jumpingRope", initialImage: UIImage(named: "jumpingRopeInitial.png")!)
    var walkingMusic = AnimatedNode.init(nodeName: "walkingMusic", initialImage: UIImage(named: "walkingMusicInitial.png")!)
    var scenarioNode = SKSpriteNode(texture: SKTexture(image: UIImage(named: "scenarioo.jpg")!))
    var introView = SKSpriteNode(imageNamed: "introView.jpg")
    var passIntroButton = ButtonNode.init(nodeName: "playButton", initialImage: UIImage(named: "playButton.jpg")!)
    
    override public init(){
        super.init(size:viewSize.size)
    }
    
    required public init(coder aDecoder: NSCoder) {
        fatalError("error")
    }
    
    override public func sceneDidLoad(){
        self.setup()
    }
    
    override public func update(_ currentTime: TimeInterval){
        
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        print("touchesBegan")
        self.run(SKAction.playSoundFileNamed("touch.m4a", waitForCompletion: true))
        for touch in touches{
            for node in self.children{
                if let n = node as? AnimatedNode{
                    if self.nodes(at: touch.location(in: self)).contains(n){
                        n.removeAllActions()
                        n.playAnimation()
                        print(n.nodeName)
                        if n.nodeName == "birds" || n.nodeName == "tree"{
                            n.willAnimateForever = true
                        }
                    }
                }else{
                    if let n = node as? ButtonNode{
                        if self.nodes(at: touch.location(in: self)).contains(n){
                            self.removeChildren(in: [introView,passIntroButton])
                        }
                    }
                    if let n = node as? TipNode{
                        if self.nodes(at: touch.location(in: self)).contains(n){
                            n.playAnimation()
                        }
                    }
                }
            }
        }
    }
    func setup(){
        
        self.midPoint = CGPoint(x: viewSize.size.width/2, y: viewSize.size.height/2)
        
        // tips node
        ideaTip.position = CGPoint(x: 639.0, y: 185.0)
        swiftTip.position = CGPoint(x: ideaTip.position.x, y: 135.0)
        swiftTip.size = CGSize(width: 20.0, height: 20.0)
        swiftTip.tipView.position = CGPoint(x:ideaTip.tipView.position.x , y: swiftTip.position.y)
        appleTip.position = CGPoint(x: ideaTip.position.x, y: 85.0)
        appleTip.size = CGSize(width: 20.0, height: 18.0)
        appleTip.tipView.position = CGPoint(x: ideaTip.tipView.position.x, y: appleTip.position.y)
        musicTip.size = CGSize(width: 20.0, height: 20.0)
        musicTip.position = CGPoint(x: ideaTip.position.x, y: 35.0)
        musicTip.tipView.position = CGPoint(x: ideaTip.tipView.position.x, y: musicTip.position.y)
        
        // animated nodes
        swiftIcon.position = CGPoint(x: 436.0, y: 330.0)
        birds.position = CGPoint(x: 500.0, y: 310.0)
        tree.position = CGPoint(x: 35.0, y: 173.0)
        peopleTalking.position = CGPoint(x: 375.0, y: 136.0)
        walkingMusic.position = CGPoint(x: 120.0, y: 150.0)
        jumpingRope.position = CGPoint(x: 390.0, y: 70.0)
        introView.position = midPoint
        introView.size = viewSize.size
        introView.alpha = 0.97
        passIntroButton.position = CGPoint(x: viewSize.size.width/2.0, y: viewSize.size.height*0.18)
        scenarioNode.position = midPoint
        scenarioNode.size = viewSize.size
        
        birds.size = CGSize(width: 150.0, height: 60.0)
        peopleTalking.size = CGSize(width: 47.0, height: 35.0*1.80)
        walkingMusic.size = CGSize(width: 42.0, height: 35.0*1.79)
        tree.size = CGSize(width: 34.0, height: 35.0*1.80)
        swiftIcon.size = CGSize(width: 20.0, height: 20.0)
        
        
        birds.concluded.position = CGPoint(x: 653.0, y: 147.0)
        peopleTalking.concluded.position = CGPoint(x: birds.concluded.position.x, y: 197.0)
        tree.concluded.position = CGPoint(x: birds.concluded.position.x, y: 97.0)
        walkingMusic.concluded.position = CGPoint(x: birds.concluded.position.x, y: 47.0)
        
        self.addChild(scenarioNode)
        self.addChild(musicTip)
        self.addChild(musicTip.tipView)
        self.addChild(appleTip)
        self.addChild(appleTip.tipView)
        self.addChild(swiftTip)
        self.addChild(swiftTip.tipView)
        self.addChild(ideaTip)
        self.addChild(ideaTip.tipView)
        self.addChild(swiftIcon)
        self.addChild(birds.concluded)
        self.addChild(birds)
        self.addChild(tree)
        self.addChild(tree.concluded)
        self.addChild(peopleTalking)
        self.addChild(peopleTalking.concluded)
        self.addChild(jumpingRope)
        self.addChild(walkingMusic)
        self.addChild(walkingMusic.concluded)
        self.addChild(introView)
        self.addChild(passIntroButton)
        
    }
}


