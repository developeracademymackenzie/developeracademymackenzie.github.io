import Foundation
import SpriteKit



public class TipNode:SKSpriteNode{
    public var nodeName: String!
    var initialImage: UIImage!
    var showingTip: Bool!
    public var tipView = SKSpriteNode()
    public init (nodeName: String, initialImage: UIImage){
        super.init(texture: SKTexture(image: initialImage), color: UIColor.clear, size: CGSize(width: 18.0, height: 18.0*1.25))
        self.nodeName = nodeName
        self.initialImage = initialImage
        self.showingTip = false
        self.tipView = SKSpriteNode(imageNamed: nodeName + "Text.png")
        self.tipView.size = CGSize(width: 160.0, height: 40.0)
        self.tipView.position = CGPoint(x: 545.0, y: 185.0)
        self.tipView.isHidden = true
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func playAnimation(){
        if showingTip{
            self.tipView.isHidden = true
            self.showingTip = !showingTip
        }else if !showingTip{
            self.tipView.isHidden = false
            self.showingTip = !showingTip
        }
        
    }
}
