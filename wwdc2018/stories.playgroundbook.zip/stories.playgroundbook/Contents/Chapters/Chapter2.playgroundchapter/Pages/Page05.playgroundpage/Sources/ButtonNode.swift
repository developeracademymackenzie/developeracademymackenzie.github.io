import Foundation
import SpriteKit


public class ButtonNode:SKSpriteNode{
    var nodeName: String!
    var initialImage: UIImage!
    public init (nodeName: String, initialImage: UIImage){
        super.init(texture: SKTexture(image: initialImage), color: UIColor.clear, size: CGSize(width: 70.0, height: 40.0))
        self.nodeName = nodeName
        self.initialImage = initialImage
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
