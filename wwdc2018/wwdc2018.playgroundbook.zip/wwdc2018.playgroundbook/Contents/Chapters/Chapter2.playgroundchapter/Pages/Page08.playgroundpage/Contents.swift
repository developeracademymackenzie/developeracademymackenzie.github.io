/*: Giovanni Luigi Bruno
 
 ![Giovanni](giovanni.png)
 
 # Giovanni Luigi Bruno
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Environment
 
 ### Essential Question
 How can we make young people aware of the importance of having a sustainable lifestyle?
 
 ### Challenge
 Create an interactive playground that shows some of the bad effects of environmental problems.
 
 - - -
 
 My playground re-read the famous Dots and Boxes that I played as a child. I wanted to do something that talked about the problems of the environment and I found a way to fit these two things, talk about something relevant and at the same time in an way that is interactive and fun.
 
 Compared to last year I focused more on creating a better experience rather than simply finding a technical problem that I would like to solve. I have learned that user experience is the most important.
 
 ![Giovanni](IMG_0003.png)
 */


