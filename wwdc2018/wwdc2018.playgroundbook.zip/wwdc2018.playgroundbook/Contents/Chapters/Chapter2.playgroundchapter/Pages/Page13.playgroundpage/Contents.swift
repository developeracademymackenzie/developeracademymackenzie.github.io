/*: Heitor Kenji Takeo Ishihara
 
 ![Heitor](heitor.png)
 
 # Heitor Kenji Takeo Ishihara
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Music
 
 ### Essential Question
 How to make people get interested in classical music?
 
 ### Challenge
 Develop a Playground with a modern look to try to get people into classical music.
 
 - - -
 
 My Playground is about geometry shapes performing a choreography with classical music.
 
 I wanted to do that because i wanted to develop an "animation" using only code, without any drawing or modeling. Besides, I really like classical music and nowaday people are not really interested in it so i want to try to get them involved with it.
 
 Last year I was basically learning Swift. I used Sprite Kit as my main framework to build last years playground and I'm using it this year too so having already used Spritekit makes the process much more easier than last year. Also, knowing the Playground peculiarities helps a lot.
 */


//#-hidden-code
// Heitor Kenji Takeo Ishihara
// 頑張れ

import PlaygroundSupport
import UIKit
import SpriteKit
import AVFoundation
import Foundation

/*----------------View Configuration---------------*/
//Create View
var sceneWidth: Double = 640
var sceneHeight: Double = 480
let sceneCenterX: Double = sceneWidth / 2
let sceneCenterY: Double = sceneHeight / 2

var mainView = SKView(frame: CGRect(x: 0, y: 0, width: sceneWidth, height: sceneHeight))
//mainView.autoresizingMask = [.flexibleLeftMargin, .flexibleTopMargin, .flexibleTopMargin, .flexibleBottomMargin]

//Create Scene
let mainScene: MyScene = MyScene(size: mainView.frame.size)
mainScene.setup()
print("chegou")
mainScene.scaleMode = .aspectFill

//Camera Scene Settings
let cameraNode = SKCameraNode()
cameraNode.position = CGPoint(x: mainScene.size.width / 2, y: mainScene.size.height / 2)
mainScene.addChild(cameraNode)
mainScene.camera = cameraNode

//Show View
mainView.presentScene(mainScene)
PlaygroundPage.current.liveView = mainView

UIView.animate(withDuration: 0.01, delay: 0.01, options: UIViewAnimationOptions(), animations: {
    cameraNode.alpha = 0
}) { (bool) in
    sceneWidth = Double(mainView.frame.width)
    sceneHeight = Double(mainView.frame.height)
}


//Play Music
let musicPath = Bundle.main.path(forResource: "canon.m4a", ofType: nil)
let url = URL(fileURLWithPath: musicPath!)
var music: AVAudioPlayer = AVAudioPlayer()

do {
    music = try AVAudioPlayer(contentsOf: url)
    music.numberOfLoops = 1
    music.prepareToPlay()
    music.play()
} catch {
    print("Error while loading song!")
}

/*---------------- START ---------------*/

//-- First ACT --
mainScene.start()

//-- Second ACT --
//-- Violin Start --
mainScene.playViolin()

//-- Thid ACT --
//-- Guitar Start --
mainScene.guitarStart()


//#-end-hidden-code







