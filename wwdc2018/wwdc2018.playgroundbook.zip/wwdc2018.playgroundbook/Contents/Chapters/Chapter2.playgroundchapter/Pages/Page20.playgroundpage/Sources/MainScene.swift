//
//  MainScene.swift
//  
//
//  Created by Pedro Del Rio Ortiz on 20/03/2018.
//

import Foundation
import SpriteKit
import PlaygroundSupport

public class MainScene: SKScene {
    
    let periodManager = PeriodManager()
    var backgroundNode: SKSpriteNode!
    var backgroundsNames = ["PaleozoicBG","MesozoicBG","CenozoicBG"]
    var bgIndex = 0
    
    override public func didMove(to view: SKView) {
       setupBackground()
    }
    
    override open func update(_ currentTime: TimeInterval) {
        
    }
    
    func setupBackground() {
        self.backgroundNode = SKSpriteNode(imageNamed: self.backgroundsNames[self.bgIndex])
        self.backgroundNode.position = CGPoint(x: (self.view?.scene?.frame.width)! * 0.5, y: (self.view?.scene?.frame.height)! * 0.5)
        self.addChild(self.backgroundNode)
        
        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(self.toRight(recognizer:)))
        swipeleft.direction = .left
        self.view?.addGestureRecognizer(swipeleft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.toLeft(recognizer:)))
        swipeRight.direction = .right
        self.view?.addGestureRecognizer(swipeRight)
        
        
        setupAnimationsObjects()
    }
    
    func setupAnimationsObjects() {
        
        if bgIndex == 0 {
            self.backgroundNode.setScale(0.47)
            self.periodManager.backgroundNode = self.backgroundNode
            self.periodManager.playgroundView = self.view
            self.periodManager.setPaleozoic()
            
        } else if bgIndex == 1 {
            self.backgroundNode.setScale(0.50)
            self.periodManager.backgroundNode = self.backgroundNode
            self.periodManager.playgroundView = self.view
            self.periodManager.setMesozoic()
        } else {
            self.backgroundNode.setScale(0.50)
            self.periodManager.backgroundNode = self.backgroundNode
            self.periodManager.playgroundView = self.view
            self.periodManager.setCenozoic()
        }
        
    }
    
    @objc func toRight(recognizer: UISwipeGestureRecognizer) {
        print("Left Swipe")
        if self.bgIndex < 2 {
            self.backgroundNode.removeFromParent()
            self.bgIndex += 1
            self.setupBackground()
        }
    }
    
    @objc func toLeft(recognizer: UISwipeGestureRecognizer) {
        print("Right Swipe")
        if self.bgIndex > 0 {
            self.backgroundNode.removeFromParent()
            self.bgIndex -= 1
            self.setupBackground()
        }
    }
    
    
    
}



