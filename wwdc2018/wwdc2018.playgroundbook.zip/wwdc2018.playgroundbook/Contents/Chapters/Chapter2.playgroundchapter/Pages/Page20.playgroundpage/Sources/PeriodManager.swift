import Foundation
import SpriteKit

public class PeriodManager : SKNode {
    
    var backgroundNode: SKSpriteNode?
    var playgroundView: SKView?
    var nodes:[SKNode] = []
    
    func setPaleozoic() {
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.click(recognizer:)))
        self.playgroundView?.addGestureRecognizer(tap)
        
        //Fish
        let fish = SKSpriteNode(imageNamed: "fish1")
        fish.position = CGPoint(x: (self.backgroundNode?.frame.width)! * -0.5 , y: (self.backgroundNode?.frame.height)! * -0.05)
        self.backgroundNode?.addChild(fish)
        var texturesFish: [SKTexture] = []
        for i in 1...2 {
            var name = "fish\(i).png"
            texturesFish.append(SKTexture(imageNamed: name))
        }
        
        fish.run(SKAction.repeatForever(SKAction.animate(with: texturesFish, timePerFrame: 2, resize: true, restore: true)))
        
        let act1 = SKAction.moveTo(x: (self.backgroundNode?.frame.width)! * 1.1 , duration: 14)
        let act2 =  SKAction.scaleX(to: -1.0, duration: 0.3)
        let act3 = SKAction.moveTo(x: (self.backgroundNode?.frame.width)! * -1.1 , duration: 14)
        let act4 =  SKAction.scaleX(to: 1.0, duration: 0.1)
        
        var actions: [SKAction]? = []
        
        actions?.append(act1)
        actions?.append(act2)
        actions?.append(act3)
        actions?.append(act4)
        
        fish.run(SKAction.repeatForever(SKAction.sequence(actions!)))
        
        self.nodes.append(fish)
        
        //Sea Star
        let seastar = SKSpriteNode(imageNamed: "seastar")
        seastar.position  = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.23 , y: (self.backgroundNode?.frame.height)! * -0.82 )
        self.backgroundNode?.addChild(seastar)
        
        let act5 = SKAction.rotate(byAngle: 0.2, duration: 0.8)
        let act6 = SKAction.rotate(byAngle: -0.2, duration: 0.8)
        
        var actions2: [SKAction]? = []
        
        actions2?.append(act5)
        actions2?.append(act6)

        seastar.run(SKAction.repeatForever(SKAction.sequence(actions2!)))
        
        self.nodes.append(seastar)
        
        //Trilobite
        let trilobite = SKSpriteNode(imageNamed: "trilobite")
        trilobite.position  = CGPoint(x: (self.backgroundNode?.frame.width)! * -0.30 , y: (self.backgroundNode?.frame.height)! * -0.80 )
        self.backgroundNode?.addChild(trilobite)
        
        let act7 = SKAction.rotate(byAngle: 0.1, duration: 0.1)
        let act8 = SKAction.rotate(byAngle: -0.1, duration: 0.1)
        
        var actions3: [SKAction]? = []
        
        actions3?.append(act7)
        actions3?.append(act8)
        
        trilobite.run(SKAction.repeatForever(SKAction.sequence(actions3!)))
        
        //Mollusk
        let mollusk = SKSpriteNode(imageNamed: "mollusk")
        mollusk.setScale(1.3)
        mollusk.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.6 , y: (self.backgroundNode?.frame.height)! * -0.77 )
        self.backgroundNode?.addChild(mollusk)
        
        let act10 = SKAction.scaleY(to: 1.4, duration: 2)
        let act11 = SKAction.scaleY(to: 1.3, duration: 2)
        
        var actions4: [SKAction]? = []
        
        actions4?.append(act10)
        actions4?.append(act11)
        
        mollusk.run(SKAction.repeatForever(SKAction.sequence(actions4!)))
        
        //Amphibian
        let amphibian = SKSpriteNode(imageNamed: "amphibian")
        amphibian.position =  CGPoint(x: (self.backgroundNode?.frame.width)! * -0.6 , y: (self.backgroundNode?.frame.height)! * 0.85 )
        amphibian.anchorPoint = CGPoint(x: 0, y: 2)
        self.backgroundNode?.addChild(amphibian)
        
        let act12 = SKAction.rotate(byAngle: -10, duration: 11)
        
        var actions5: [SKAction]? = []
        
        actions5?.append(act12)
        
        amphibian.run(SKAction.repeatForever(SKAction.sequence(actions5!)))
        
        //Bubble
        let bubble = SKShapeNode(circleOfRadius: 25)
        bubble.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.6 , y: (self.backgroundNode?.frame.height)! * -0.55 )
        bubble.fillColor = UIColor(red:0.99, green:0.99, blue:0.99, alpha:1.0)
        self.backgroundNode?.addChild(bubble)
        
        let act13 = SKAction.moveTo(x: (self.backgroundNode?.frame.width)! * 0.62 , duration: 0.5)
        let act14 = SKAction.moveTo(x: (self.backgroundNode?.frame.width)! * 0.58 , duration: 0.5)
        
        let act15 = SKAction.fadeAlpha(to: 0.7, duration: 0.1)
        let act16 = SKAction.moveTo(y: (self.backgroundNode?.frame.width)! * 0.8, duration: 8)
        let act17 = SKAction.fadeAlpha(to: 0, duration: 0.1)
        let act18 = SKAction.moveTo(y: (self.backgroundNode?.frame.width)! * -0.55, duration: 0.5)
        
        var actions6: [SKAction]? = []
        
        actions6?.append(act13)
        actions6?.append(act14)
        
        var actions7: [SKAction]? = []
        
        actions7?.append(act15)
        actions7?.append(act16)
        actions7?.append(act17)
        actions7?.append(act18)
        
        bubble.run(SKAction.repeatForever(SKAction.sequence(actions6!)))
        bubble.run(SKAction.repeatForever(SKAction.sequence(actions7!)))

    }
    
    func setMesozoic() {
        
        //Brachiossaur
        let brachiossaur = SKSpriteNode(imageNamed: "brachiossaur")
        brachiossaur.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.10 , y: (self.backgroundNode?.frame.height)! * -0.20 )
        self.backgroundNode?.addChild(brachiossaur)
        
        let act23 = SKAction.rotate(byAngle: 0.5, duration: 1)
        let act24 = SKAction.wait(forDuration: 1)
        let act25 = SKAction.rotate(byAngle: -0.5, duration: 1.3)
        let act26 = SKAction.wait(forDuration: 1.3)
        
        var actions10: [SKAction]? = []
        
        actions10?.append(act23)
        actions10?.append(act24)
        actions10?.append(act25)
        actions10?.append(act26)
        
        brachiossaur.run(SKAction.repeatForever(SKAction.sequence(actions10!)))
        
        
       //T-Rex
       let trex = SKSpriteNode(imageNamed: "trex")
       trex.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.50 , y: (self.backgroundNode?.frame.height)! * -0.25 )
       self.backgroundNode?.addChild(trex)
        
        let act19 = SKAction.scaleX(to: 1.04, duration: 0.7)
        let act20 = SKAction.scaleX(to: 1.0, duration: 0.7)
        
        var actions8: [SKAction]? = []
        
        actions8?.append(act19)
        actions8?.append(act20)
        
        trex.run(SKAction.repeatForever(SKAction.sequence(actions8!)))
        
        //Stegossaur
        let stegossaur = SKSpriteNode(imageNamed: "stegossaur")
        stegossaur.position = CGPoint(x: (self.backgroundNode?.frame.width)! * -0.45 , y: (self.backgroundNode?.frame.height)! * -0.45 )
        self.backgroundNode?.addChild(stegossaur)
        
        let act21 = SKAction.scaleY(to: 1.05, duration: 1)
        let act22 = SKAction.scaleY(to: 1.0, duration: 1)
        
        var actions9: [SKAction]? = []
        
        actions9?.append(act21)
        actions9?.append(act22)
        
        stegossaur.run(SKAction.repeatForever(SKAction.sequence(actions9!)))
        
        //Pterossaur
        let ptero = SKSpriteNode(imageNamed: "ptero")
        ptero.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.55 , y: (self.backgroundNode?.frame.height)! * 0.5 )
        self.backgroundNode?.addChild(ptero)
        
        let act27 = SKAction.rotate(byAngle: 0.3, duration: 1)
        let act28 = SKAction.rotate(byAngle: -0.3, duration: 1.3)
        
        var actions11: [SKAction]? = []
        
        actions11?.append(act27)
        actions11?.append(act28)
        
        ptero.run(SKAction.repeatForever(SKAction.sequence(actions11!)))
        
       
    }
    
    func setCenozoic() {
        
        //Mammoth
        let mammoth = SKSpriteNode(imageNamed: "mammoth")
        mammoth.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.83 , y: (self.backgroundNode?.frame.height)! * 0 )
        self.backgroundNode?.addChild(mammoth)
        
        let act29 = SKAction.scaleY(to: 1.03, duration: 1)
        let act30 = SKAction.scaleY(to: 1.0, duration: 1)
        
        var actions12: [SKAction]? = []
        
        actions12?.append(act29)
        actions12?.append(act30)
        
        mammoth.run(SKAction.repeatForever(SKAction.sequence(actions12!)))
        
        
        //Mammoth Son
        let mammothSON = SKSpriteNode(imageNamed: "mammothSON")
        mammothSON.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.8 , y: (self.backgroundNode?.frame.height)! * -0.42 )
        self.backgroundNode?.addChild(mammothSON)
        
        let act31 = SKAction.scaleY(to: 1.03, duration: 0.6)
        let act32 = SKAction.scaleY(to: 1.0, duration: 0.6)
        
        var actions13: [SKAction]? = []
        
        actions13?.append(act31)
        actions13?.append(act32)
        
        mammothSON.run(SKAction.repeatForever(SKAction.sequence(actions13!)))
        
        //Tiger
        let tiger = SKSpriteNode(imageNamed: "tiger")
        tiger.position = CGPoint(x: (self.backgroundNode?.frame.width)! * -0.6 , y: (self.backgroundNode?.frame.height)! * -0.1 )
        self.backgroundNode?.addChild(tiger)
        
        tiger.run(SKAction.repeatForever(SKAction.sequence(actions12!)))
        
        //Man
        let man = SKSpriteNode(imageNamed: "man1")
        man.position = CGPoint(x: (self.backgroundNode?.frame.width)! * 0.05 , y: (self.backgroundNode?.frame.height)! * -0.50 )
        self.backgroundNode?.addChild(man)
        var texturesMan: [SKTexture] = []
        for i in 1...7 {
            var name = "man\(i).png"
            texturesMan.append(SKTexture(imageNamed: name))
        }
        
        texturesMan.append(SKTexture(imageNamed: "man6"))
        texturesMan.append(SKTexture(imageNamed: "man5"))
        texturesMan.append(SKTexture(imageNamed: "man4"))
        texturesMan.append(SKTexture(imageNamed: "man3"))
        texturesMan.append(SKTexture(imageNamed: "man2"))
        
        man.run(SKAction.repeatForever(SKAction.animate(with: texturesMan, timePerFrame: 0.05, resize: true, restore: true)))
        
    }
    
    @objc func click(recognizer: UITapGestureRecognizer) {
        for node in self.nodes {
            if node.contains(recognizer.location(in: self.playgroundView)) {
                print("clicou em node")
            }
        }
        print("clicou")
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("MACACP")
    }
    
}

