/*: Renan Soares Germano
 
 ![Renan](renan.png)
 
 # Renan Soares Germano
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Personalized gestures
 
 ### Essential Question
 How to teach the process of creating a personalized gesture in a interactive way?
 
 ### Challenge
 Create a playground to teaches personalized gesture recognizer by using a game and a simple technique.
 
 - - -
 
 It teaches the user the logic of a personalized gesture recognizer to recognize simple shapes. To make this, it uses a memory game with personalized gestures containing three basic shapes. And, after understanding it,   the user can interact with the code to test and learn the used gesture coding logic. What inspired me is the fact that personalized gesture makes the applications more fun, and makes me happy when I use it. I also already have worked with personalized gesture, and when I did it I had difficulty. Because of that I would like to create a simple way of using it.
 In my case, I did not do the last year playground. But in this one I learned a lot of technical skills. And beyond this, I learned how to work with playground, as well as to thing in the way the content is presented to the user - it has to be interactive.
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit

class GameScene: SKScene {
    //MARK: - Properties
    var navigationManager: NavigationManager?
    var memoryGameManager: MemoryGameManager?
    
    //MARK: - Life cicle functions
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        
        self.navigationManager = NavigationManager(scene: self)
        self.memoryGameManager = MemoryGameManager(scene: self)
        
        self.navigationManager?.showStart(completion: nil)
    }
    
    //MARK: - Tap handler
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let location = touches.first?.location(in: self.view) else { return }
        self.navigationManager?.goTo(scene: .Start, withTranstion: true, completion: nil)
        //        self.memoryGameManager?.showCurrentSequence()
    }
    
}

//MARK: - GameScene
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "GameScene") {
    scene.scaleMode = .aspectFit
    scene.backgroundColor = UIColor.white
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code

