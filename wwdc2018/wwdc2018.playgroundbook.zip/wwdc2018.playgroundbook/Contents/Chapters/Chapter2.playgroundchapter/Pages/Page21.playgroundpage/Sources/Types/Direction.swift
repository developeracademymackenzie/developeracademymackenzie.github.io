import Foundation

enum Direction {
    case Left
    case LeftUp
    case Up
    case RightUp
    case Right
    case RightDown
    case Down
    case LeftDown
    
    func reverse() -> Direction {
        switch self {
        case .Left:
            return .Right
        case .LeftUp:
            return .RightDown
        case .Up:
            return .Down
        case .RightUp:
            return .LeftDown
        case .Right:
            return .Left
        case .RightDown:
            return .LeftUp
        case .Down:
            return .Up
        case .LeftDown:
            return .RightUp
        }
    }
    
    func related() -> [Direction] {
        switch self {
        case .LeftUp:
            return [Direction.LeftUp, Direction.Left, Direction.Up]
        case .RightUp:
            return [Direction.RightUp, Direction.Right, Direction.Up]
        case .RightDown:
            return [Direction.RightDown, Direction.Right, Direction.Down]
        case .LeftDown:
            return [Direction.LeftDown, Direction.Left, Direction.Down]
        default:
            return [self]
        }
    }
    
    func contains(_ directions: [Direction]) -> Bool {
        let related = self.related()
        for direction in directions { if !related.contains(direction) { return false } }
        return true
    }
    
    func isDiagonal() -> Bool { return [Direction.LeftUp, Direction.RightUp, Direction.RightDown, Direction.LeftDown].contains(self) }
}
