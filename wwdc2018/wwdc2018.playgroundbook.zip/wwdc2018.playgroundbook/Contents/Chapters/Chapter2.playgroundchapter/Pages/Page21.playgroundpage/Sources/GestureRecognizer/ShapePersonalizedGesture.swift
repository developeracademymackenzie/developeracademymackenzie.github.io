import UIKit.UIGestureRecognizerSubclass
import UIKit.UIResponder

class ShapePersonalizedGestureRecognizer: UIGestureRecognizer, NSCoding {
    
    //MARK: - Properties
    private var initialTouch: UITouch?
    var points: [Point] = [Point]()
    var directions: [Direction]?
    var shapeDirections: [Direction]?
    
    //MARK: - NSCoding
    required init?(coder aDecoder: NSCoder) {
        super.init(target: nil, action: nil)
        self.points = [Point]()
    }
    
    init(shapeDirections: [Direction], target: Any?, action: Selector?) {
        super.init(target: target, action: action)
        self.shapeDirections = shapeDirections
    }
    
    func encode(with aCoder: NSCoder) { }
    
    //MARK: - Touch handlers
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        if touches.count != 1 {
            self.state = .failed
        }
        
        // Capture the first touch and store some information about it.
        if self.initialTouch == nil {
            if let firstTouch = touches.first {
                self.initialTouch = firstTouch
                self.addPoint(for: firstTouch)
                state = .began
            }
        } else {
            // Ignore all but the first touch.
            for touch in touches {
                if touch != self.initialTouch {
                    self.ignore(touch, for: event)
                }
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.addPoint(for: touches.first!)
        state = .changed
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.addPoint(for: touches.first!)
        state = .ended
        self.initDirections()
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.points.removeAll()
        state = .cancelled
    }
    
    override func reset() {
        self.points.removeAll()
        self.initialTouch = nil
    }
    
    //MARK: - Aux funcs
    private func addPoint(for touch: UITouch) {
        let newPoint = Point(location: touch.location(in: self.view))
        self.points.append(newPoint)
    }
    
    //MARK: - Public interface
    final func isValid() -> Bool { return validateInNormalDirection() || validateInReversedDirection() }
    
    func initDirections() {  }
    
    func validate(directions: [Direction]) -> Bool { return false }
    
    func validateInNormalDirection() -> Bool {
        guard let directions = self.directions else { return false }
        return validate(directions: directions)
    }
    
    func validateInReversedDirection() -> Bool {
        guard let directions = self.directions?.getReversed() else { return false }
        return validate(directions: directions)
    }
    
    func isValid(previous: Direction? , current: Direction, next: Direction?, nextShapeDirections: [Direction]) -> Bool {
        if let previous = previous { // some direction was alredy detected
            if current != previous { // current direction is differente from last one
                if !current.related().contains(previous), !previous.related().contains(current) { // current direction is not contained in last one, and last one is not contained in current
                    if let next = next, current != next, !current.related().contains(next), !next.related().contains(current) { // current direction is not compatible with the next one
                        for nextShapeDirection in nextShapeDirections {
                            if !nextShapeDirections.contains(next) { return false }
                        }
                    }
                }
            }
        }
        return true
    }
    
}

