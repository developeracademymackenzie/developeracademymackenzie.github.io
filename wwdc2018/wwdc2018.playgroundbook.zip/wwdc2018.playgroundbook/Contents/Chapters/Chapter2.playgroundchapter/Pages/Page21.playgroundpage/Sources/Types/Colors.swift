import UIKit

public struct Colors {
    public static var orange: UIColor {
//        guard let orangeImage = Images.orange else { UIImage.yellow }
        guard let orangeImage = Images.orange else { return UIColor.yellow }
        return UIColor(patternImage: orangeImage)
    }
}

