import Foundation

public enum Shape {
    case Square
    case Triangle
    case Star
}
