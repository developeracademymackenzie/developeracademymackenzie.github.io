import UIKit

public struct Images {
    public static var orange: UIImage? = UIImage(named: "./colors/orange")
}
