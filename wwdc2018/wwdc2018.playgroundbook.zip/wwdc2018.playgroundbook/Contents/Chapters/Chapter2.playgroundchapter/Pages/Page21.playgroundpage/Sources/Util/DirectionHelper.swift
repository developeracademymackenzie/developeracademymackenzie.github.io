import UIKit

class DirectionHelper {
    
    //MARK: - Properties
    private typealias ToleranceRange = (min: CGPoint, max: CGPoint)
    
    //MARK: - Public interface
    static func pointsToDirectionSequence(_ points: [Point], withTolerance tolerance: Tolerance) -> [Direction] {
        var directionSequence: [Direction] = [Direction]()
        var direction: Direction!
        
        for i in 1..<points.count {
            let first = points[i-1].location
            let second = points[i].location
            let firstX = first.x
            let firstY = first.y
            let secondX = second.x
            let secondY = second.y
            let toleranceRange: ToleranceRange = (CGPoint(x: firstX-tolerance.rawValue, y: firstY-tolerance.rawValue), CGPoint(x: firstX+tolerance.rawValue, y: firstY+tolerance.rawValue))
            if isPointInsideToleranceRange(second, toleranceRange) { continue }
            
            if secondX > toleranceRange.max.x { // Right
                if secondY > toleranceRange.max.y { // Up
                    direction = .RightDown
                } else if secondY < toleranceRange.min.y { // Down
                    direction = .RightUp
                } else {
                    direction = .Right
                }
            } else if secondX < toleranceRange.min.x { // Left
                if secondY > toleranceRange.max.y { // Up
                    direction = .LeftDown
                } else if secondY < toleranceRange.min.y { // Down
                    direction = .LeftUp
                } else {
                    direction = .Left
                }
            } else { // Up || Down
                if secondY > toleranceRange.max.y { // Up
                    direction = .Down
                } else { // Down
                    direction = .Up
                }
            }
            
            if let d = direction, (directionSequence.isEmpty || (directionSequence.last! != d)) {
                //                print("\(d) made from: \(points[i-1].location) and \(points[i].location)")
                directionSequence.append(d)
            }
        }
        
        return directionSequence
    }
    
    //MARK: - Aux functions
    private static func isPointInsideToleranceRange(_ point: CGPoint, _ toleranceRange: ToleranceRange) -> Bool {
        let isXInseideToleranceRange: Bool = point.x >= toleranceRange.min.x && point.x <= toleranceRange.max.x
        let isYInseideToleranceRange: Bool = point.y >= toleranceRange.min.y && point.y <= toleranceRange.max.y
        return isXInseideToleranceRange && isYInseideToleranceRange
    }
    
}

