import SpriteKit

public class MemoryGameManager {
    
    // MARK: - Properties
    private var scene: SKScene?
    
    private var current: MemoryGame = MemoryGame()
    private var duration: TimeInterval = 0.5
    private var shapes: [Shape:SKSpriteNode] = [Shape:SKSpriteNode]()
    
    public init(scene: SKScene) {
        self.scene = scene
    
        let squareCard: SKSpriteNode = SKSpriteNode(texture: SKTexture(imageNamed: Paths.squareCard))
        let triangleCard: SKSpriteNode = SKSpriteNode(texture: SKTexture(imageNamed: Paths.triangleCard))
        let starCard: SKSpriteNode = SKSpriteNode(texture: SKTexture(imageNamed: Paths.starCard))
        
        self.shapes[.Square] = squareCard
        self.shapes[.Triangle] = triangleCard
        self.shapes[.Star] = starCard
    }
    
    public func newGame() {
        self.shapes[.Square] = SKSpriteNode(imageNamed: Paths.square)
        self.shapes[.Triangle] = SKSpriteNode(imageNamed: Paths.triangle)
        self.shapes[.Star] = SKSpriteNode(imageNamed: Paths.star)
        self.current = MemoryGame()
    }
    
    public func showCurrentSequence() {
        print("Showing current sequence!")
    }
    
    public func didRecognize(shape: Shape) {
        if self.current.check(shape: shape) { // Valid shape recognized.
            if self.current.isLast() { // Current level ended.
                print("Current level ended! Congratulation!")
                self.current.goToNextLevel()
                // New level animation
                self.showCurrentSequence()
            } else { // Only more one shape of the current level.
                print("Right recognized shape! Now, go to the next one. ;)")
                self.current.goToNextShape()
            }
        } else { // Invalid shape recognizer
            // End of game or minus one chance
        }
    }
    
    private func fadeIn(node: SKSpriteNode, completion: (()->Void)?, fadeOutAutomaticaly: Bool) {
        let fadeIn = SKAction.fadeIn(withDuration: self.duration)
        let resize = SKAction.resize(toWidth: node.size.height, duration: self.duration)
        let group = SKAction.group([fadeIn, resize])
        let wait = SKAction.wait(forDuration: self.duration)
        let completion = SKAction.run {
            if fadeOutAutomaticaly {
                self.fadeOut(node: node, completion: completion)
            } else if let c = completion { c() }
        }
        let sequence = SKAction.sequence([group, wait, completion])
        node.run(sequence)
    }
    
    private func fadeOut(node: SKSpriteNode, completion: (()-> Void)?) {
        let fadeOut = SKAction.fadeOut(withDuration: self.duration)
        let resize = SKAction.resize(toWidth: 0, duration: self.duration)
        let group = SKAction.group([fadeOut, resize])
        let completion = SKAction.run { if let c = completion { c() } }
        let sequence = SKAction.sequence([group, completion])
        node.run(sequence)
    }
    
    
}
