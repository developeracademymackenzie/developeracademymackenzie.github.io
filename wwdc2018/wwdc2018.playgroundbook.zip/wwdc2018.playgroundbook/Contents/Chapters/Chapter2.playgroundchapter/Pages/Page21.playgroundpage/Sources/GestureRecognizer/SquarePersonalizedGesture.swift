import UIKit

class SquarePersonalizedGesture: ShapePersonalizedGestureRecognizer {
    
    //MARK: - ShapePersonalizedGestureRecognizer functions
    override func initDirections() { self.directions = DirectionHelper.pointsToDirectionSequence(self.points, withTolerance: .Medium) }
    
    override func validate(directions: [Direction]) -> Bool {
        if !directions.isEmpty, var current = directions.first, let shapeDirectionSequence = self.shapeDirections, shapeDirectionSequence.contains(current) {
            var sides: [Direction: Bool] = [Direction: Bool]()
            for direction in shapeDirectionSequence { sides[direction] = false }
            sides[current] = true
            for i in 1..<directions.count {
                let next = directions[i]
                switch current {
                case .Up:
                    if ![Direction.Up, Direction.Right].contains(next) { return false } else { sides[next] = true }
                case .Right:
                    if ![Direction.Right, Direction.Down].contains(next) { return false } else { sides[next] = true }
                case .Down:
                    if ![Direction.Down, Direction.Left].contains(next) { return false } else { sides[next] = true }
                case .Left:
                    if ![Direction.Left, Direction.Up].contains(next) { return false } else { sides[next] = true }
                default:
                    return false
                }
                current = next
            }
            for (_,visited) in sides { if !visited { return false } }
            return true
        }
        return false
    }
    
}
