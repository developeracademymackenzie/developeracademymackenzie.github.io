import Foundation

extension Array where Element == Direction {
    
    func getReversed() -> [Direction] {
        var reversed: [Direction] = []
        self.forEach { reversed.append($0.reverse()) }
        return reversed.reversed()
    }
    
    func subSequence(from start: Int, to end: Int) -> [Direction] {
        var directions: [Direction] = []
        let sequenceSize = self.count
        if start < sequenceSize && end < sequenceSize && start < end {
            for i in start...end {
                directions.append(self[i])
            }
        } else if start < sequenceSize && end < sequenceSize && start == end {
            directions.append(self[start])
        }
        return directions
    }
    
    func reduced() -> [Direction] {
        var directions: [Direction] = []
        var i: Int = 0
        var currentDiagonal: Direction?
        for j in 0..<self.count {
            let direction = self[j]
            if let cd = currentDiagonal {
                if !cd.related().contains(direction) {
                    currentDiagonal = nil
                    if direction.isDiagonal() {
                        currentDiagonal = direction
                    } else {
                        i = j
                    }
                }
            } else if direction.isDiagonal() {
                currentDiagonal = direction
                var isContainedInDiagonal: Bool = true
                let beforeDiagonalSequence = self.subSequence(from: i, to: j-1)
                beforeDiagonalSequence.forEach {
                    if isContainedInDiagonal {
                        if !direction.related().contains($0) {
                            directions.append($0)
                            isContainedInDiagonal = false
                        }
                    } else { directions.append($0) }
                }
                directions.append(direction)
                i = j + 1
            }
            
        }
        return directions
    }
    
    func indexesOf(direction: Direction) -> [Int] {
        var indexes: [Int] = [Int]()
        for i in 0..<self.count { if self[i] == direction { indexes.append(i) } }
        return indexes
    }
    
    //    func nextValidDiagonalFrom(index: Int) -> (direction: Direction, index: Int)? {
    //        if index < self.count {
    //            for i in index..<self.count {
    //                if self[i].isDiagonal() { return (self[i], i) }
    //            }
    //        }
    //        return nil
    //    }
    
    func string() -> String {
        var string: String = ""
        string += "["
        for i in 0..<self.count { string += " \(self[i])" }
        string += " ]"
        return string
    }
    
}

