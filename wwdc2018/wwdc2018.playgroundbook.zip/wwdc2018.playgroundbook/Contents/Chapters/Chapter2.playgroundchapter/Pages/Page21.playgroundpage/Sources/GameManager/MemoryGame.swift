import Foundation

public class MemoryGame {
    
    // MARK: - Properties
    private let shapes: [Shape] = [.Square, .Triangle, .Star]
    private var lastRandomNumber: Int?
    private var next: Int = 0 // This variable defines the current shape that must be drawn by the user
    
    public var sequence: [Shape] = [Shape]()
    public var currentShape: Shape { return self.sequence[self.next] }
    public var level: Int = 0
    
    
    // MARK: - Initializers
    public init() {
        self.addNewShape()
        self.level += 1
    }
    
    // MARK: - Public interface
    
    // Used to check if a shape is equals the current one.
    public func check(shape: Shape) -> Bool {
        return shape == currentShape
    }
    
    // Used to go to next level. This function must be called after the user finished the game.
    public func goToNextLevel() {
        self.addNewShape()
        self.level += 1 // Increments the level
        self.next = 0 // Returns the counter to zero
    }
    
    // Used to get shape by shape of the current shape sequence.
    public func goToNextShape() {
        self.next += 1 // Increments the counter
    }
    
    // Used to verify if the last direction was the last sequence one.
    public func isLast() -> Bool {
        return self.next == self.sequence.count
    }
    
    // MARK: - Aux functions
    private func addNewShape() {
        let random = Math.random(max: 3, differentOf: self.lastRandomNumber)
        self.sequence.append(shapes[random])
        self.lastRandomNumber = random
    }
    
}
