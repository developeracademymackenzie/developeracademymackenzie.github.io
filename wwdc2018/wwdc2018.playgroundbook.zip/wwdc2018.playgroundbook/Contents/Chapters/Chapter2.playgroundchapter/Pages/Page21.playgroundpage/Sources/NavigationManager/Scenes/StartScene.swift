import SpriteKit
import UIKit

class StartScene: SceneProtocol {
    
    //MARK: - Properties
    var scene: SKScene?
    
    private var leftPane: SKSpriteNode?
    private var centerPane: SKSpriteNode?
    private var rightPane: SKSpriteNode?
    
    private var paneWidth: CGFloat?
    private var paneHeight: CGFloat?
    
    private let animationDuration: TimeInterval = 1
    
    private var playLabel: UILabel?
    
    //MARK: - Initializers
    required init(scene: SKScene) {
        self.scene = scene
        self.paneWidth = self.scene?.view?.width(divededBy: 3)
        self.paneHeight = self.scene?.view?.height
        self.setUpPanels()
        self.setUpLabel()
    }
    
    //MARK: - Scene protocol functions
    func fadeIn(completion: (() -> Void)?) {
        self.setUpPanelsPosition()
        let fi = SKAction.fadeIn(withDuration: self.animationDuration)
        let move = SKAction.moveTo(y: 0, duration: self.animationDuration)
        let group = SKAction.group([fi, move])
        let completion = SKAction.run { if let c = completion { c() } }
        let completionSequence = SKAction.sequence([group, completion])
        self.leftPane?.run(group)
        self.centerPane?.run(group)
        self.rightPane?.run(completionSequence)
    }
    
    func fadeOut(completion: (() -> Void)?) {
        if let pw = self.paneWidth, let ph = self.paneHeight {
            let fo = SKAction.fadeOut(withDuration: self.animationDuration)
            let completion = SKAction.run { if let c = completion { c() } }
            
            let moveUp = SKAction.moveTo(y: ph, duration: self.animationDuration)
            let moveUpGroup = SKAction.group([fo, moveUp])
            
            let moveDown = SKAction.moveTo(y: -ph, duration: self.animationDuration)
            let moveDownGroup = SKAction.group([fo, moveDown])
            let moveDownWithCompletionSequence = SKAction.sequence([moveDownGroup, completion])
            
            self.leftPane?.run(moveDownGroup)
            self.centerPane?.run(moveUpGroup)
            self.rightPane?.run(moveDownWithCompletionSequence)
        }
    }
    
    func didTap(at location: CGPoint) {  }
    
    //MARK: - SetUp functions
    private func setUpPanels() {
        self.createPanels()
        self.setUpPanelsPosition()
    }
    
    private func createPanels() {
        if let pw = self.paneWidth, let ph = self.paneHeight {
            self.leftPane = SKSpriteNode(imageNamed: Paths.orange)
            self.leftPane?.size = CGSize(width: pw, height: ph)
            self.leftPane?.name = "leftPane"
            let squareNode = SKSpriteNode(imageNamed: Paths.squareWhite)
            squareNode.size = CGSize(width: pw*0.7, height: pw*0.7)
            squareNode.position = CGPoint.zero
            leftPane?.addChild(squareNode)
            self.scene?.addChild(leftPane!)
            
            self.centerPane = SKSpriteNode(imageNamed: Paths.green)
            self.centerPane?.size = CGSize(width: pw, height: ph)
            self.centerPane?.name = "centerPane"
            let triangleNode = SKSpriteNode(imageNamed: Paths.triangleWhite)
            triangleNode.size = CGSize(width: pw*0.7, height: pw*0.7)
            triangleNode.position = CGPoint.zero
            centerPane?.addChild(triangleNode)
            self.scene?.addChild(centerPane!)
            
            self.rightPane = SKSpriteNode(imageNamed: Paths.blue)
            self.rightPane?.size = CGSize(width: pw, height: ph)
            self.rightPane?.name = "rightPane"
            let starNode = SKSpriteNode(imageNamed: Paths.starWhite)
            starNode.size = CGSize(width: pw*0.7, height: pw*0.7)
            starNode.position = CGPoint.zero
            rightPane?.addChild(starNode)
            self.scene?.addChild(rightPane!)
            
        }
    }
    
    private func setUpPanelsPosition() {
        guard let pw = self.paneWidth, let ph = self.paneHeight, let lp = self.leftPane, let cp = self.centerPane, let rp = self.rightPane else { return }
        lp.alpha = 0
        cp.alpha = 0
        rp.alpha = 0
        lp.position = CGPoint(x: -pw, y: ph)
        cp.position = CGPoint(x: 0, y: -ph)
        rp.position = CGPoint(x: pw, y: ph)
    }
    
    private func addPanelsToScene() {
        guard let lp = self.leftPane, let cp = self.centerPane, let rp = self.rightPane else { return }
        self.scene?.addChild(lp)
        self.scene?.addChild(cp)
        self.scene?.addChild(rp)
    }
    
    private func setUpLabel() {
        guard let ph = self.paneHeight, let view = self.scene?.view as? UIView else { return }
        let x: CGFloat = 0.0;
        let y: CGFloat = ph - (ph * 0.1)
        let width = view.frame.width
        let rect = CGRect(x: x, y: y, width: width, height: ph * 0.1)
        self.playLabel = UILabel(frame: rect)
        self.playLabel?.backgroundColor = UIColor.lightGray
        self.playLabel?.text = "Press to Play"
        self.playLabel?.textAlignment = .center
        self.playLabel?.font.withSize(40)
        self.playLabel?.alpha = 0
        view.addSubview(self.playLabel!)
    }
    
}
