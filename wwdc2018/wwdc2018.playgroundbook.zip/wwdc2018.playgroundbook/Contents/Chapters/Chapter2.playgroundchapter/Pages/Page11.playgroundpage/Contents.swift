/*: Guilherme Horcaio Paciulli
 
 ![Paciulli](paciulli.png)
 
 # Guilherme Horcaio Paciulli
 
 - - -
 XCode
 - - -
 
 ### Big Idea
 Learning
 
 ### Essential Question
 How does A* algorithm search works?
 
 ### Challenge
 To build an application that uses A* algorithm.
 
 - - -
 
 I have made a simple application of the A* algorithm: a cat needs to go to a banana, the player can set both cat's and banana's location and then put obstacles in the way. Once the button Go is pressed the cat finds it's way to the banana. I created this playground because I have always wanted to understand and use the A* algorithm, I always found the problem of shortest path from graph theory interesting and very complex to be solved and I always searched a lot about it, but never was able to implement it.
 
 The main things that changed was how fast I could implement my idea, how complex it was and how closer to what I wanted to do since the last year. In the first year I learned a lot about how SpriteKit architecture works, that helped me a lot throughout the process, from adding a Node to building an action to follow a path, everything became much more easier and I understood everything I needed to know to built my playground. From last year's playground I used some tricks and tips that helped to build a playground app, since it is a much more light and limited development ambient when you compare it to the robust and complete Xcode's default project.
 
  ![Paciulli](screen.png)
 */









