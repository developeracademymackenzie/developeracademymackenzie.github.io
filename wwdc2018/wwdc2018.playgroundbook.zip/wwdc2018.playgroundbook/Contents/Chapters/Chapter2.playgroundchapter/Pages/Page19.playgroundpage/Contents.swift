/*: Osniel Lopes Teixeira
 
 ![Osniel](osniel.png)
 
 # Osniel Lopes Teixeira
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Education
 
 ### Essential Question
 How to teach the concept of cellular automata?
 
 ### Challenge
 Create an interactive playground where the user can learn about two-dimensional cellular automata in a fun way.
 
 - - -
 
 In my playground the user will be able to play with a game of the life of two-dimensional cellular automata. The results of the iterations of each generation will be used to create notes that together, will form a "melody". My ispiration arose from the desire to teach something I enjoy, sharing my enthusiasm for cellular automata and all of its potential.
 
 Thinking in retrospect, the current challenge is presented in a much simpler way. I can better visualize my goals once I understand the difficulty of working with the playground. Other than that, it is also valid to say that my experience as a programmer has evolved, which also helps a lot.
 
 I did not use anything from last year's playground because I was working on a very different proposal.
 */

//#-hidden-code
import UIKit
import PlaygroundSupport

class MyView: UIView {
    
    var colview:CollectionView!
    
    private func setup() {
        self.backgroundColor = UIColor.darkGray
        let margin = min(self.frame.size.width, self.frame.size.height)*0.05
        let frame = CGRect(x: margin, y: margin,
                           width: self.frame.size.width - 2*margin,
                           height: self.frame.size.height - 2*margin)
        colview = CollectionView(frame: frame)
        self.addSubview(colview)
        
        
    }
    
    func resize(){
        self.colview.removeFromSuperview()
        let margin = min(self.frame.size.width, self.frame.size.height)*0.05
        let frame = CGRect(x: margin, y: margin,
                           width: self.frame.size.width - 2*margin,
                           height: self.frame.size.height - 2*margin)
        colview = CollectionView(frame: frame)
        self.addSubview(colview)
        self.setNeedsDisplay()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class MyViewController : UIViewController {
    override func viewDidLoad() {
        
        let v = MyView(frame:CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        v.resize()
        
        self.view = v
    }
    
    override func viewDidLayoutSubviews() {
        (self.view as! MyView).resize()
    }
}


PlaygroundPage.current.liveView = MyViewController()

//#-end-hidden-code
