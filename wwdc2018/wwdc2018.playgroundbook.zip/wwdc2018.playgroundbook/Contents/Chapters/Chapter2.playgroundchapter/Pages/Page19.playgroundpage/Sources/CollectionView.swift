import UIKit
public class CollectionView: UIView{
    
    let numberOfRows = 60
    let numberOfColumns = 30
    var board = GameOfLifeBoard()
    let insets = UIEdgeInsets(top: 2.0, left: 2.0, bottom: 2.0, right: 2.0)
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.createTheMatrix()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func createTheMatrix(){
        let avaiableWidth = self.bounds.size.width - insets.left * CGFloat(numberOfColumns + 1)
        let avaiableHeight = self.bounds.size.height - insets.bottom * CGFloat(numberOfRows + 1)
        let cellSize = CGSize(width: avaiableWidth/CGFloat(numberOfColumns), height: avaiableHeight/CGFloat(numberOfRows))
        for i in 0..<numberOfRows {
            board.cells.append([])
            for j in 0..<numberOfColumns {
                let rect = CGRect(x: insets.left * CGFloat(1 + j) + CGFloat(j)*cellSize.width,
                                  y: insets.bottom * CGFloat(1 + i) + CGFloat(i)*cellSize.height,
                                  width: cellSize.width,
                                  height: cellSize.height)
                let cellView = CellView(frame: rect)
                cellView.delegate = board
                board.cells[i].append(cellView)
                self.addSubview(cellView)
            }
        }
    }

}
