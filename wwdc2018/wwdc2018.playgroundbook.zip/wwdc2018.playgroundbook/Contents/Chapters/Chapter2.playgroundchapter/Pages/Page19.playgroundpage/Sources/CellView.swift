import UIKit

protocol CellViewDelegate {
    func userInteractionOcurred()
}

public enum BackgroundColor: Int {
    case black = 0, white
}
public class CellView: UIView {
    
    var color: BackgroundColor = .black {
        didSet{
            switch color {
            case .white:
                self.backgroundColor = UIColor.white
            default:
                self.backgroundColor = UIColor.black
            }
        }
    }
    
    var delegate: CellViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.black
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.backgroundColor = UIColor.black
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        self.color = self.color == .white ? .black : .white
        if let d = delegate {
            d.userInteractionOcurred()
        }
    }
}
