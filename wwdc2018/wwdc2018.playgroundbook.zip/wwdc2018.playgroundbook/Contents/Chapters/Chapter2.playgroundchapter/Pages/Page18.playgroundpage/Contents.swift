/*: Nicholas Ribeiro Babo
 
 ![Babo](babo.png)
 
 # Nicholas Ribeiro Babo
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Health
 
 ### Essential Question
 How to raise awareness about depression and help those who are suffering from this disease?
 
 ### Challenge
 To create an interactive experience that can explain how does depression works and how we can help people who suffer from this within three minutes.
 
 - - -
 
 My playground is a journey through the life of a depressed person, going from the bottom of the pit to getting better and finally to full recovery. I was inspired by many friends I had throughout my life that suffered from depression and often came to me looking for help.
 
 This year I had a deeper idea for a subject and creative ways to show what I wished to present to the user, besides being a much more skilled, experienced developer compared to last year.
 */

//#-hidden-code
import UIKit
import PlaygroundSupport

let vc = HouseViewController()
PlaygroundPage.current.liveView = vc
//#-end-hidden-code
