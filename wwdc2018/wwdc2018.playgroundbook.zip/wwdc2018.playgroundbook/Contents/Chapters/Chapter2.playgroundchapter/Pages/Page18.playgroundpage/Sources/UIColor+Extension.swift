//
//  UIColor+Extension.swift
//  Figurinhas
//
//  Created by Nicholas Babo on 17/03/18.
//  Copyright © 2018 Nicholas Babo. All rights reserved.
//

import Foundation
import UIKit

extension UIColor{
    
    public convenience init(red: Int, green: Int, blue: Int, alpha:Double, l:Bool) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: CGFloat(alpha))
    }
    
    public static let TenisBackground = UIColor(red: 184, green: 233, blue: 134, alpha: 1.0, l: true)
    
//    static let ArtBackground = UIColor(red: 255, green: 122, blue: 1, alpha: 0.71)
    
    public static let ArtBackground = UIColor(red: 255, green: 161, blue: 76, alpha: 1.0, l: true)
    
    public static let SpeakBackground = UIColor(red: 248, green: 255, blue: 148, alpha: 1.0, l: true)
    
    public static let notWeaknessBackground = UIColor(red: 172, green: 255, blue: 240, alpha: 1.0, l: true)
    
}
