/*: Guilherme Gatto Gonçalves da Silva
 
 ![Gatto](gatto.png)
 
 # Guilherme Gatto Gonçalves da Silva
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Entertainment
 
 ### Essential Question
 How to help people train some skills through a game?
 
 ### Challenge
 Develop a game in which your challenges are directly linked to the training of some specific skills.
 
 - - -
 
 A game that submits the player to 3 different experiences. In the first one, the ability to focus is measured, in the second, the ability of mental agility is measured, as in the third and last, the ability to memorize is measured. At the end, a chart is presented in which it compares the obtained results of the player, with a pre-defined general average.
 
 This year, unlike 2017, I was able to use skills gained over the past year to develop something better formulated.
 One topic that was not to my knowledge and what I learned last year that I am using in my playground is SpriteKit.
 I did not use the one from last year because he had already been one of the chosen ones for the WWDC.
 
 */





