
import SpriteKit

public class GameScene: SKScene {
    
    // MARK: - Labels
    var titleLabel : SKLabelNode!
    var instructionLabel : SKLabelNode!
    var bpmLabel : SKLabelNode!
    
    // MARK: - Metronome
    var metronome : Metronome!
    public var metronomeBeep: Bool!
    
    // MARK: - Musical parameters
    public var bpm : Double!
    public var loopEnable: Bool!
    
    // MARK: - Variables
    var elementSize:Double!
    
    // MARK: - Sound
    var engine: SoundEngine!
    var melodys:[Melody] = []
    var instrument = "Strings"
    var instrumentSelector: Selectora!
    
    public var playInitialMusic: Bool!
    
    override public func didMove(to view: SKView) {
        
        // Element size
        elementSize = Double( (size.width + size.height) * 0.02 )
        
        // Load visual element
        self.loadLabels()
        self.loadMetronome()
        self.loadEngine()
        self.loadMelody()
        self.loadSelector()
        
        self.loadMusic()
    }
    
    // MARK: - Build elements
    
    func loadLabels() {
        // Get label nodes from scene and store it for use later
        titleLabel = childNode(withName: "//helloLabel") as? SKLabelNode
        titleLabel.alpha = 0.0
        
        bpmLabel = childNode(withName: "//bpm") as? SKLabelNode
        bpmLabel.alpha = 0.0
        bpmLabel.text = "BPM: \(String(bpm))"
        
        instructionLabel = childNode(withName: "//instruction") as? SKLabelNode
        instructionLabel.alpha = 0.0
        
        // Fade In Title and Instructions
        let fadeIn = SKAction.fadeIn(withDuration: 3.0)
        titleLabel.run(fadeIn)
        instructionLabel.run(fadeIn)
    }
    
    func loadMetronome() {
        // Create visual metronome
        metronome = Metronome.init(bpm: self.bpm, beep: self.metronomeBeep)
        let h = self.frame.height/2
        metronome.position = CGPoint.init(x: 0, y: -h+(h/8) )
        addChild(metronome)
    }
    
    func loadEngine() {
        self.engine = SoundEngine.init()
    }
    
    func loadMelody() {
        // Initial melody sound
        let melody = Melody.init(sound: engine, notes: [])
        melodys.append( melody )
        melody.engine.getIntrument(byName: self.instrument).play()
        melody.engine.getIntrument(byName: self.instrument).mute()
    }
    
    func loadSelector() {
        // Selector
        instrumentSelector = Selectora.init(size: CGFloat(elementSize) )
        instrumentSelector.position = metronome.position
        instrumentSelector.position.y += CGFloat(elementSize*4)
        self.addChild(instrumentSelector)
    }
    
    // MARK: - Play Music
    
    func loadMusic() {
        let m = Melody.init(sound: self.engine, notes: [])
        // octave = 300
        //        let tone = CGFloat(50)
        
        let notesPitch = [ CGFloat(0.0), CGFloat(200/4), CGFloat(400/4), CGFloat(500/4),  CGFloat(700/4), CGFloat(900/4), CGFloat(1100/4), CGFloat(1200/4) ]
        //let notesPitch = [ CGFloat(0.0), CGFloat(50.0), CGFloat(100.0), CGFloat(125.0),  CGFloat(175.0), CGFloat(225.0), CGFloat(275.0), CGFloat(300.0) ]
        // 0.0 200/4 400/4 500/4 700/4 900/4 1100/4 1200/4
        let notes = [
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[3], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[4], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[4], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[3], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[0], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[0], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.6, pitch: 0.0, space: true),
            
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[3], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[4], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[4], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[3], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[0], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[0], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[2], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[1], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[0], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: 0.0, space: true),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.2, pitch: notesPitch[0], space: false),
            SongNote.init(radius: CGFloat(self.elementSize), lifeCicle: self.metronome.time, loop: false, color: UIColor.red, sound: self.engine.instrumentStrings, duration: 0.6, pitch: 0.0, space: true)
            
        ]
        m.songNotes = notes
        self.addChild(m)
        if playInitialMusic {
            m.start()
        }
    }
    
    // MARK: - Handle touchs
    
    func touchDown(atPoint pos : CGPoint) {
        // Add Note
        let color = self.instrumentSelector.instrumentsColor[self.instrumentSelector.selected - 1]
        addNote(color: color, pos: pos)
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        // Add Note
        let color = self.instrumentSelector.instrumentsColor[self.instrumentSelector.selected - 1]
        addNote(color: color, pos: pos)
    }
    
    func touchUp(atPoint pos : CGPoint) {
        // Add Note
        let color = self.instrumentSelector.instrumentsColor[self.instrumentSelector.selected - 1]
        addNote(color: color, pos: pos)
        // Starts a new melody
        let melody = Melody.init(sound: engine, notes: [])
        melodys.append( melody )
        melody.engine.getIntrument(byName: self.instrument).play()
        melody.engine.getIntrument(byName: self.instrument).mute()
    }
    
    // MARK: - Selector Actions
    
    func selectorButton(pos: CGPoint) -> Bool {
        var situation = false
        // Nodes
        let elements = nodes(at: pos)
        for element in elements {
            print(" -> \(String(describing: element.name))")
            if element.name != nil {
                if (element.name?.hasPrefix("Instrument"))! {
                    let instrumentNumber = element.name?.split(separator: " ").last
                    print("Instrument: \(String(describing: instrumentNumber))")
                    
                    instrumentSelector.selectInstrument(withNumber: Int(instrumentNumber!)! )
                    
                    // Starts a new melody
                    self.instrument = self.instrumentSelector.instruments[self.instrumentSelector.selected - 1]
                    let melody = Melody.init(sound: engine, notes: [])
                    melodys.append( melody )
                    melody.engine.getIntrument(byName: self.instrument).play()
                    melody.engine.getIntrument(byName: self.instrument).mute()
                    
                    situation = true
                }
            }
            
        }
        return situation
    }
    
    // MARK: - Add Note
    
    func addNote(color: UIColor, pos: CGPoint) {
        let note = Note.init(radius: CGFloat(elementSize), lifeCicle: metronome.time, loop: loopEnable, color: color, sound: engine.getIntrument(byName: self.instrument) )
        melodys.last?.notes.append(note)
        note.position = pos
        self.addChild(note)
    }
    
    // MARK: - Managing labels
    
    func showBPM() {
        // If label is not on the screen
        if (titleLabel.alpha == 0.0) && (bpmLabel.alpha != 1) {
            // Fade In BPM Label
            let fadeIn = SKAction.fadeIn(withDuration: 1.0)
            bpmLabel.run(fadeIn)
        }
    }
    
    func removeLabels() {
        // Fade In BPM
        let addBPM = SKAction.run {
            // Show BPM on the screen
            self.showBPM()
        }
        // Fade Out Title and Instructions
        let remove = SKAction.sequence([.fadeOut(withDuration: 1.0),
                                        .removeFromParent(),
                                        addBPM])
        // Running actions
        titleLabel.run(remove)
        instructionLabel.run(remove)
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // Remove intructions and title labels
        if bpmLabel.alpha < 1 {
            removeLabels()
        }
        // Shows the metronome
        self.metronome.run( SKAction.fadeIn(withDuration: 1.0) )
        for t in touches {
            if self.selectorButton(pos: t.location(in: self) ) == false {
                touchDown(atPoint: t.location(in: self))
            }
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if self.selectorButton(pos: t.location(in: self) ) == false {
                touchMoved(toPoint: t.location(in: self))
            }
        }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if self.selectorButton(pos: t.location(in: self) ) == false {
                
                touchUp(atPoint: t.location(in: self))
            }
        }
    }
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        print("----------< Situation >----------")
        print("Number of melodys: \(melodys.count)")
        print("---------------------------------\n")
    }
}
