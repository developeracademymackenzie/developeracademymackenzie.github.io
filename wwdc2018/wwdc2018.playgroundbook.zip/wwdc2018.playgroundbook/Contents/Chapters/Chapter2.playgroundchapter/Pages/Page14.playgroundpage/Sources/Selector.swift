//
//  Selector.swift
//  Dev
//
//  Created by João Gabriel Borelli Padilha on 19/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import SpriteKit

public class Selectora: SKNode {
    
    // MARK: - Parameters
    public var instruments = ["Organ", "Strings", "Electro", "Guitar",  "Bass"]
    public var instrumentsColor = [UIColor.brown, UIColor.gray, UIColor.blue, UIColor.red, UIColor.green]
    public var visualSelectors:[SKShapeNode] = []
    
    public var selectedInstrument: SKShapeNode
    public var size: CGFloat
    public var selected = 2
    
    public init(size: CGFloat) {
        
        self.size = size
        selectedInstrument = SKShapeNode.init(circleOfRadius: self.size*1.5)
        selectedInstrument.fillColor = .orange
        selectedInstrument.zPosition = -1
        
        super.init()
        
        let first = self.generateVisualInstrument(color: .brown)
        visualSelectors.append(first)
        first.name = "Instrument 1"
        self.addChild(first)
        let icon_1 = SKLabelNode.init()
        icon_1.text = "🎹"
        icon_1.verticalAlignmentMode = .center
        icon_1.fontSize = size*1.2
        first.addChild(icon_1)
        
        let second = generateVisualInstrument(color: .lightGray)
        visualSelectors.append(second)
        second.name = "Instrument 2"
        second.position.x += size*3
        self.addChild(second)
        let icon_2 = SKLabelNode.init()
        icon_2.text = "🎻"
        icon_2.verticalAlignmentMode = .center
        icon_2.fontSize = size*1.2
        second.addChild(icon_2)
        
        let third = generateVisualInstrument(color: .blue)
        visualSelectors.append(third)
        third.name = "Instrument 3"
        third.position.x -= size*3
        self.addChild(third)
        let icon_3 = SKLabelNode.init()
        icon_3.text = "🎛"
        icon_3.verticalAlignmentMode = .center
        icon_3.fontSize = size*1.2
        third.addChild(icon_3)
        
        let fourth = generateVisualInstrument(color: .red)
        visualSelectors.append(fourth)
        fourth.name = "Instrument 4"
        fourth.position.x -= size*6
        self.addChild(fourth)
        let icon_4 = SKLabelNode.init()
        icon_4.text = "🎸"
        icon_4.verticalAlignmentMode = .center
        icon_4.fontSize = size*1.2
        fourth.addChild(icon_4)
        
        let fifth = generateVisualInstrument(color: .green)
        visualSelectors.append(fifth)
        fifth.name = "Instrument 5"
        fifth.position.x += size*6
        self.addChild(fifth)
        let icon_5 = SKLabelNode.init()
        icon_5.text = "📣"
        icon_5.verticalAlignmentMode = .center
        icon_5.fontSize = size*1.2
        fifth.addChild(icon_5)
        
        self.selectInstrument(withNumber: selected)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func generateVisualInstrument(color: UIColor) -> SKShapeNode {
        let shape = SKShapeNode.init(circleOfRadius: self.size)
        shape.fillColor = color
        return shape
    }
    
    public func selectInstrument(withNumber: Int) {
        self.selected = withNumber
        selectedInstrument.removeFromParent()
        visualSelectors[withNumber - 1].addChild(selectedInstrument)
    }
    
}
