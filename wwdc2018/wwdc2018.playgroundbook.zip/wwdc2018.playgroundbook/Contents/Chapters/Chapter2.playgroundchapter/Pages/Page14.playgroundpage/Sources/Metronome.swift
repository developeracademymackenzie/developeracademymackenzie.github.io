//
//  Metronome.swift
//  Dev
//
//  Created by João Gabriel Borelli Padilha on 16/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import SpriteKit

public class Metronome: SKNode {
    
    // MARK: - Visual Elements
    private var countLabel : SKLabelNode!
    
    // MARK: - Parameters
    var tocar = SKAction.playSoundFileNamed("Metronome.m4a", waitForCompletion: false)
    
    // MARK: - Musical Parameters
    var bpm: Double = 80.0
    var count = 1
    public var time: Double = 0.0
    public var beep: Bool = false
    
    public init(bpm: Double, beep: Bool) {
        super.init()
        
        self.countLabel = SKLabelNode.init(fontNamed: "Futura")
        self.countLabel.fontSize = 80.0
        self.countLabel.fontColor = UIColor.black
        self.addChild(self.countLabel)
        
        self.bpm = bpm
        self.beep = beep
        self.time = Double(60) / bpm
        
        self.countLabel.text = String(self.count)
        print("TEMPO: \( self.time )")
        
        self.start()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func start() {
        let wait = SKAction.wait(forDuration: time)
        let show = SKAction.run {
            self.increaseCount()
            print("Count: \(self.count)")
            print("-> Time: \(self.time)\n")
        }
        let tocando = SKAction.run {
            if self.beep {
                self.run(self.tocar)
            }
        }
        let sequence = SKAction.sequence([wait, show, tocando])
        let loop = SKAction.repeatForever(sequence)
        self.run(loop)
    }
    
    func increaseCount() {
        if self.count == 4 {
            self.count = 1
        }else{
            self.count += 1
        }
        self.countLabel.text = String(self.count)
    }
    
}

