//
//  MusicNote.swift
//  Dev
//
//  Created by João Gabriel Borelli Padilha on 20/03/2018.
//  Copyright © 2018 João Gabriel Borelli Padilha. All rights reserved.
//

import Foundation
import SpriteKit

public class SongNote: Note {
    
    public var duration: TimeInterval
    private var space: Bool // pause
    
    public init(radius: CGFloat, lifeCicle: Double, loop: Bool, color: UIColor, sound: Instrument, duration: TimeInterval, pitch: CGFloat, space:Bool) {
        self.space = space
        self.duration = duration
        super.init(radius: radius, lifeCicle: lifeCicle, loop: loop, color: color, sound: sound)
        
        if !space {
            self.position.y = pitch
        }else{
            self.alpha = 0.0
        }
        start()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func start() {
        let add = SKAction.run {
            self.alpha = 1.0
            // Sound
            self.sound.setupEffects(pitch: Float(self.position.y), reverb: Float(self.position.x) )
            self.sound.unMute()
            self.sound.play()
        }
        let wait = SKAction.wait(forDuration: duration)
        let stop = SKAction.run {
            // Sound
            self.sound.mute()
            self.sound.pause()
        }
        let disappear = SKAction.run {
            self.removeFromParent()
        }
        let remove = SKAction.group([ .fadeOut(withDuration: 0.5), stop, disappear])
        
        let sequence = SKAction.sequence([add, wait, remove])
        
        if !space {
            self.run(sequence)
        }else{
            self.run(wait)
        }
        
    }
    
}

