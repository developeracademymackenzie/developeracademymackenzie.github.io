/*: Davi Duarte Gomes
 
 ![Davi](davi.png)
 
 # Davi Duarte Gomes
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Accessibility
 
 ### Essential Question
 How to show the importance of Accessibility in Educational Games?
 
 ### Challenge
 Create a swift playground that shows the importance of accessibility in a demonstration game.
 
 - - -
 
 The structure of my playground is in book format, so I will describe the playground as one first and then give a little summary about which page individually.
 
 My Swift Playground is about Accessibility in Educational Games, especially for those who have compromised vision or are legally blind. In this playground I propose a real experience for the developers who are using it or even those who are learning to code and don't know about the difficulties and the problems that a blind person has when using an app that does not have any personal implementation of accessibility features.
 
 I have talked with many developers while developing to iOS platforms and it cuts deep in my heart to see that just one or two really cared about implementing Voice Over or any kind of accessibility features to help those people who cannot interact or even use your app if they are blind.
 
 This playground attempts to show how easy it's to make a big difference with a small personal implementation of Voice Over. Also, for a more personal appeal, the dynamic of the playground suggests for people to try using the app, that has no Voice Over implementation, with their eyes close or visor off. This will, in my opinion, make them think about how difficult it's to use the app if their were blind, and make they understand the meaning of what they are doing.
 
 The first page of the playground introduces its dynamic, asking the user about educational questions, showing some information and asking them a question that will be developed in the other pages of the book. When you run the code, an animation will appear, introducing the concept that this playground attempts to work with.
 
 The second page introduces the simple game app that the user will work with along the playground. This game is about Arithmetic Progressions, where the user must complete a sequence of 5 elements in order to complete the game. At this page, the user should just test the app and see how it works.
 
 The third page focus on using the same app that you have used before, with a new random sequence, but now as if you were legally blind. For this, the user must, as explained in the markup, turn on Voice Over and close its eyes or even turn the visor off.
 
 The fourth page brings an explanation about the implementation of Voice Over, and how easy it is to make that. After completing the coding, that can be done without Voice Over activate, the user should activate the Voice Over again and see how easy it's to use the app with 4 lines of code changed.
 
 The fifth and last page only focus on showing how those actions can impact the world that he has changed.
 
 Finally, hope that this playground show people how easy it's to make an accessible world and how their four lines of code can impact the life of those who must need.
 
 This time, we had more knowledge about swift development in order to make something more beautiful and structured in less time then we had before.
 
 For me, I have worked more with the idea, through CBL, something that I did not had so clear in mind in the first year. I think spending more time on the idea elaboration can help me get a chance to WWDC, because it doesn't matter if you create something so beautiful and it has no concepts about what you care and like.
 
 I have not used nothing from by swift playground of the last year, because i think that my programming organization and code is better nowadays, and it would not contribute much for me to use the code and organization of before. But I used my previous knowledge about Markup to develop it faster then before.
 */




//#-hidden-code
import UIKit
import PlaygroundSupport
GameHelper.numbers = 5
GameHelper.background = .white
let controller = GameViewController()
PlaygroundPage.current.liveView = controller
//#-end-hidden-code

