import Foundation
import UIKit

enum Ordinal: Int {
    case first = 0
    case second
    case third
    case forth
    case fifth
    case sixth
    case seventh
}
