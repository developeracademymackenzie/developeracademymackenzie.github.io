import Foundation
import UIKit

class AnswerCollection: UICollectionView {
    
    var controller: AnswerCollectionViewController? {
        didSet {
            self.delegate   = controller!
            self.dataSource = controller!
        }
    }
    
    init(parent: UIView) {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 1, height: 1)
        layout.minimumInteritemSpacing = 5
        layout.minimumLineSpacing = 5
        
        let parentSize = parent.bounds.size
        let pos = CGPoint(x: 0, y: 0)
        let size = CGSize(width: parentSize.width, height: parentSize.height)
        super.init(frame: CGRect(x: pos.x, y: pos.y, width: size.width, height: size.height), collectionViewLayout: layout)
        
        self.backgroundColor = .clear
        self.register(AnswersCell.self, forCellWithReuseIdentifier: "MainCell")
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}

