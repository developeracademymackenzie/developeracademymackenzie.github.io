import Foundation
import UIKit

class CentralView: UIView {
    
    var collection: MainCollection!
    var titleLabel: UILabel!
    
    init() {
        let pos = CGPoint(x: Screen.main.width * 0.05, y: Screen.main.height * 0.075)
        let size = CGSize(width: Screen.main.width * 0.4, height: Screen.main.height * 0.575)
        super.init(frame: CGRect(x: pos.x, y: pos.y, width: size.width, height: size.height))
        self.backgroundColor = GameHelper.background
        
        let collectionController = MainCollectionViewController()
        let main = MainCollection(parent: self)
        main.controller = collectionController
        self.collection = main
        
        self.addSubview(main)
        self.testConstraints()
        
        let label = UILabel(frame: CGRect(x: pos.x, y: pos.y, width: size.width, height: size.height))
        self.addSubview(label)
        label.setConstraints()
        self.titleLabel = label
        self.titleLabel.isAccessibilityElement = GameHelper.Progression_isAccessibilityElement
        self.reloadAccessiblity()
    }
    
    func reloadAccessiblity() {
        let test = GameHelper.main.currentProgression!
        let accessibility = test.createAccessibility()
        titleLabel.accessibilityLabel = "\(accessibility.label)"
        titleLabel.accessibilityHint = "\(accessibility.hint)"
    }
    
    func testConstraints() {
        let view = self.collection!
        view.heightAnchor.constraint(equalToConstant: self.bounds.height).isActive = true
        view.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        view.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        view.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}

