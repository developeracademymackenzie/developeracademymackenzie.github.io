import Foundation
import UIKit

class BottomView: UIView {
    
    var collection: AnswerCollection!
    var backgroundImage: UIImageView!
    
    init() {
        let pos = CGPoint(x: Screen.main.width * 0.05, y: Screen.main.height * 0.6)
        let size = CGSize(width: Screen.main.width * 0.4, height: Screen.main.height * 0.275)
        super.init(frame: CGRect(x: pos.x, y: pos.y, width: size.width, height: size.height))
        let collectionController = AnswerCollectionViewController()
        let answers = AnswerCollection(parent: self)
        answers.controller = collectionController
        self.addSubview(answers)
        collection = answers
        self.setConstraintsFor(answers: answers)
        collection.reloadData()
        self.addBackground()
    }
    
    func setConstraintsFor(answers: AnswerCollection) {
        answers.translatesAutoresizingMaskIntoConstraints = false
        answers.topAnchor.constraint(equalTo: self.topAnchor, constant: 30).isActive = true
        answers.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        answers.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
        answers.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10).isActive = true
    }
    
    func addBackground() {
        let imageView = UIImageView(frame: self.frame)
        imageView.image = UIImage(named: "Game/DownAnchor")
        self.addSubview(imageView)
        self.sendSubview(toBack: imageView)
        imageView.setConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}
