import UIKit

public class GameHelper {
    
    public static var main = GameHelper()
    public static var numbers = 5
    public static var levels = 1
    public static var background: UIColor = .white
    public static var SingleLabel_isAccessibilityElement: Bool = true
    public static var Progression_isAccessibilityElement: Bool = false
    public static var Progression_readMessage: String = ""
    public static var Progression_askMessage: String = ""
    public var currentProgression: Progression!
    public var controller: GameViewController?
    
    public var gameHasEnded: Bool = false
    public var isAnimating: Bool = false
    
    private init() {
        self.currentProgression = ProgressionFactory.shared.generateLevel()
    }
}
