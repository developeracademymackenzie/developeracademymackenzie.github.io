import UIKit

class MainCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    var progression: Progression = GameHelper.main.currentProgression
    var collection: MainCollection!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func getFrameOfCell(at index: Int) -> (bounds: CGRect, frame: CGRect) {
        let indexPath = IndexPath(row: index, section: 0)
        let cell = collection.cellForItem(at: indexPath)!
        let mainView = GameHelper.main.controller!.view
        let mainBounds = cell.convert(cell.bounds, to: mainView)
        let mainFrame = cell.frame
        return (mainBounds, mainFrame)
    }
    
    // MARK: UICollectionViewDataSource
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return progression.numberCount
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MainCell", for: indexPath) as! MainCell
        if progression.pointer >= indexPath.row {
            cell.backgroundView = UIImageView(image: UIImage(named: "Game/Cellbg"))
            cell.configurate(number: progression.numbers[indexPath.row])
        } else {
            cell.disableConfiguration()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.bounds.width / 5) - 5
        let height = (collectionView.bounds.width / 5) - 5
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 2.5, bottom: 0, right: 2.5)
    }
    
}
