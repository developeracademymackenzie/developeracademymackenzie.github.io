import Foundation
import UIKit

class MainCollection: UICollectionView {
    
    var controller: MainCollectionViewController? {
        didSet {
            self.delegate   = controller!
            self.dataSource = controller!
            controller!.collection = self
        }
    }
    
    init(parent: UIView) {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 1, height: 1)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        
        let parentSize = parent.bounds.size
        let size = CGSize(width: parentSize.width, height: parentSize.height)
        super.init(frame: CGRect(x: 0, y: 0, width: size.width, height: size.height / 2), collectionViewLayout: layout)
        self.frame.origin.y = Screen.main.height * 0.275 - ((self.bounds.width / 5) - 10)
        self.backgroundColor = .clear
        self.register(MainCell.self, forCellWithReuseIdentifier: "MainCell")
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
}
