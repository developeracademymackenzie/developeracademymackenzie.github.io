import Foundation
import SpriteKit

public extension Int {
    static func randomInt(min: Int, max: Int) -> Int {
        return Int(arc4random_uniform(UInt32(max - min))) + min
    }
    
    static func randomRange(min: Int, max: Int) -> Int {
        return Int(arc4random_uniform(UInt32(max - 10 - min))) + min
    }
}


// Thanks rickster for the extension code for shuffling the array
extension MutableCollection {
    mutating func shuffle() {
        let c = count
        guard c > 1 else { return }
        
        for (firstUnshuffled, unshuffledCount) in zip(indices, stride(from: c, to: 1, by: -1)) {
            let d: IndexDistance = numericCast(arc4random_uniform(numericCast(unshuffledCount)))
            let i = index(firstUnshuffled, offsetBy: d)
            swapAt(firstUnshuffled, i)
        }
    }
}

// Thanks rickster for the extension code for shuffling the array
extension Sequence {
    func shuffled() -> [Element] {
        var result = Array(self)
        result.shuffle()
        return result
    }
}

extension UIView {
    
    func setConstraints() {
        let upper = self.superview!
        self.translatesAutoresizingMaskIntoConstraints = false
        self.widthAnchor.constraint(equalToConstant: self.bounds.width).isActive = true
        self.heightAnchor.constraint(equalToConstant: self.bounds.height).isActive = true
        self.centerXAnchor.constraint(equalTo: upper.centerXAnchor).isActive = true
        self.centerYAnchor.constraint(equalTo: upper.centerYAnchor).isActive = true
    }
    
    public func anchorFull() {
        let upper = self.superview!
        self.translatesAutoresizingMaskIntoConstraints = false
        self.topAnchor.constraint(equalTo: upper.topAnchor).isActive = true
        self.bottomAnchor.constraint(equalTo: upper.bottomAnchor).isActive = true
        self.trailingAnchor.constraint(equalTo: upper.trailingAnchor).isActive = true
        self.leadingAnchor.constraint(equalTo: upper.leadingAnchor).isActive = true
    }
}

extension UIColor {
    
    convenience init(r: Int, g: Int, b: Int) {
        self.init(red: CGFloat(r)/255, green: CGFloat(g)/255, blue: CGFloat(b)/255, alpha: 1)
    }
    
}

extension String {
    subscript (i: Int) -> Character {
        return self[index(startIndex, offsetBy: i)]
    }
}
