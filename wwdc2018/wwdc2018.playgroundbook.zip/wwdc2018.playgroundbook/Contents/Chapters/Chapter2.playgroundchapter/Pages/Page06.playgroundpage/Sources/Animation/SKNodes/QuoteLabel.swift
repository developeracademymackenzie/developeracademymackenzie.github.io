import SpriteKit
import Foundation

class QuoteLabel: SKLabelNode {
    
    let mainText = "Is your game beauty just seen through eyes?"
    let alterPage = "Let's change this story!!! Move to next page!"
    var pointer = 0
    
    func startAnimation() {
        self.text = ""
        self.pointer = 0
        
        let textAnimation = SKAction.run {
            if self.pointer == self.mainText.count {
                self.removeAllActions()
            } else {
                self.text!.append(self.mainText[self.pointer])
                self.pointer += 1
            }
        }
        
        let wait = SKAction.wait(forDuration: 0.11)
        let sequence = SKAction.sequence([textAnimation, wait])
        self.run(SKAction.repeatForever(sequence))
    }
    
    func endAnimation() {
        self.text = ""
        self.pointer = 0
        
        let textAnimation = SKAction.run {
            if self.pointer == self.alterPage.count {
                self.removeAllActions()
            } else {
                self.text!.append(self.alterPage[self.pointer])
                self.pointer += 1
            }
        }
        
        let wait = SKAction.wait(forDuration: 0.11)
        let sequence = SKAction.sequence([textAnimation, wait])
        self.run(SKAction.repeatForever(sequence))
    }
    
    func finalPosition() {
        let movement = SKAction.moveBy(x: 0, y: -(Screen.main.height * 0.1), duration: 2.0)
        movement.timingMode = .easeIn
        self.run(movement)
    }
}
