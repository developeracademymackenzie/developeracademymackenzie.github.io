import Foundation
import UIKit

class Pallet {
    
    static var white = UIColor(r: 255, g: 255, b: 255)
    static var gray = UIColor(r: 200, g: 200, b: 200)
    static var darkblue = UIColor(r: 70, g: 75, b: 200)
    static var blue = UIColor(r: 87, g: 144, b: 240)
    static var darkerblue = UIColor(r: 29, g: 3, b: 122)
    
}
