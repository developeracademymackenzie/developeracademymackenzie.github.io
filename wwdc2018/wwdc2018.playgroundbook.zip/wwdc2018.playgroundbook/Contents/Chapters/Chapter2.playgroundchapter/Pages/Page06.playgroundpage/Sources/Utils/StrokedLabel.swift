import Foundation
import UIKit

class StrokedLabel: UILabel {
    
    func setText(text: String, align: NSTextAlignment, size: CGFloat) {
        
        let customizedText = NSMutableAttributedString(string: text)
        
        attributedText = customizedText
        self.textAlignment = align
        self.textColor = .white
        self.font = UIFont(name: "Helvetica", size: 30)
    }
}

