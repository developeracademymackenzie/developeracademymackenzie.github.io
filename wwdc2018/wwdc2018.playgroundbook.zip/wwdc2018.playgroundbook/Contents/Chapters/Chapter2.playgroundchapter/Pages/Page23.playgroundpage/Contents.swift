/*: Vinícius Cano Santos
 
 ![Cano](cano.png)
 
 # Vinícius Cano Soares
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Animation
 
 ### Essential Question
 How to do user discover animations with device hardware?
 
 ### Challenge
 Make a character get animated whenever the user does some action.
 
 - - -
 
 Let the user discover some of the device's functions like changing brightness and volume in a fun way. My inspiration is learning more about animation and Playgrounds.
 
 In this year I have more knowledge about the Playgrounds and Swift, I learned how to really use CBL(Challenge Based Learning) and I'm more motivated because I chose an theme that I love.
 
 I've learned that I need to work with something that I enjoy and have great purposes because this engage me.
 
 I didn't use the Playground that I did last year because I know that my new idea is better than the idea of last year. In last year I was afraid because I was on my first challenge at Apple Developer Academy and I now I have more confidence than last year.
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit
import UIKit
import AVFoundation

class GameScene: SKScene {
    
    var personagem = SKSpriteNode(texture: SKTexture(imageNamed: "PiscandoERespirando00.png"))
    let initialScreenBrightness = UIScreen.main.brightness
    let audioSession = AVAudioSession.sharedInstance()
    var initialVolume: Float = 0.0
    var glasses = false
    var firstExecution = true
    var dancing = false
    
    override func didMove(to view: SKView) {
        personagem.position = CGPoint(x: frame.midX, y: frame.midY)
        personagem.scale(to: CGSize(width: personagem.size.width * 2, height: personagem.size.height * 2))
        checkIfInitialBrightnessIsMax()
        firstExecution = false
        self.addChild(personagem)
        
        print(initialVolume)
        
        animacaoDancar()
        
        //Funciona
        NotificationCenter.default.addObserver(self, selector: #selector(checkBrightness), name: .UIScreenBrightnessDidChange, object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(systemVolumeDidChange),
                                               name: NSNotification.Name(rawValue: "AVSystemController_SystemVolumeDidChangeNotification"),
                                               object: nil
        )
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        //checkBrightness()
    }
    
    func animacaoColocarOculos(){
        let putGlasses: SKAction = SKAction(named: "ColocarOculos", duration: 2.0)!
        let colocandoOculos = SKAction.sequence([putGlasses])
        
        personagem.run(colocandoOculos)
        
        //personagem = SKSpriteNode(texture: SKTexture(imageNamed: "ColocandoOculos72.png"))
    }
    
    @objc func animacaoRetirarOculos(){
        let retirarOculos: SKAction = SKAction(named: "ColocarOculos", duration: 2.0)!
        let retirandoOculos = SKAction.sequence([retirarOculos.reversed()])
        
        personagem.run(retirandoOculos)
        
        //        personagem = SKSpriteNode(texture: SKTexture(imageNamed: "ColocandoOculos00.png"))
    }
    
    func animacaoDancar(){
        let preparacaoDanca: SKAction = SKAction(named: "PreparacaoDanca", duration: 1.0)!
        let danca: SKAction = SKAction(named: "Danca", duration: 0.8)!
        let dancando = SKAction.sequence([preparacaoDanca, .repeatForever(danca)])
        
        personagem.run(dancando)
        dancing = true
    }
    
    func animacaoPararDeDancar(){
        let preparacaoDanca: SKAction = SKAction(named: "PreparacaoDanca", duration: 1.0)!
        let parandoDeDancar = SKAction.sequence([preparacaoDanca.reversed()])
        
        personagem.run(parandoDeDancar)
        dancing = false
    }
    
    func animacaoPiscarERespirar(){
        let piscarERespirar: SKAction = SKAction(named: "PiscandoERespirando", duration: 4.0)!
        let piscandoERespirando = SKAction.sequence([.repeatForever(piscarERespirar)])
        
        personagem.run(piscandoERespirando)
        dancing = false
    }
    
    @objc func checkBrightness(){
        let screenBrightness = UIScreen.main.brightness
        
        if firstExecution == false{
            if(screenBrightness >= 0.5 && glasses == false){
                print("Acima do meio")
                print("Colocar oculos")
                glasses = true
                animacaoColocarOculos()
            }else if(screenBrightness < 0.5 && glasses == true){
                print("Abaixo do meio")
                print("Retirar Óculos")
                animacaoRetirarOculos()
                glasses = false
            }
        }
    }
    
    func checkIfInitialBrightnessIsMax(){
        if initialScreenBrightness == 1.0{
            print("Brilho no máximo")
            personagem = SKSpriteNode(texture: SKTexture(imageNamed: "ColocandoOculos72.png"))
            glasses = true
        }
    }
    
    @objc func systemVolumeDidChange(notification: NSNotification) {
        let volume = audioSession.outputVolume
        
        if initialVolume < volume && volume >= 0.5 && dancing == false{
            animacaoDancar()
        }else if initialVolume > volume && volume < 0.5 && dancing == true{
            animacaoPararDeDancar()
        }
    }
    
}

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "GameScene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView


//#-end-hidden-code


