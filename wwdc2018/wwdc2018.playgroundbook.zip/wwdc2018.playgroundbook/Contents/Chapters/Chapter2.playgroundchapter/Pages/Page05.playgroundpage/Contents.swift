/*: Bruno Henrique Monge da Cruz
 
  ![Bruno](bruno.png)
 
 # Bruno Henrique Monge da Cruz
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Hidden object game
 
 ### Essential Question
 How to make an interesting hidden object game and tell my story into it?
 
 ### Challenge
 Create a hidden object game’s playground that pass an immersive and interesting experience.
 
 - - -
 
 My playground is a hidden object game, that you can interact with the scene and find some specific objects. Each object has a tip and a relation with me.
 
 This year the great difference was the Swift background acquired last year, it has become possible to develop all I want in the possible time.
 
 The big learn with the last Playground was the differences between a Xcode Project and a Playground.
 
 The only thing I've used from the past year was to review some methods that I need to use.
 */




//#-hidden-code
import UIKit
import PlaygroundSupport
import SpriteKit


let scene = Scene()
let view = SKView(frame: CGRect(x: 0, y: 0, width: 666.99, height: 359.73))
scene.run(SKAction.repeatForever(SKAction.playSoundFileNamed("ambientSound.m4a", waitForCompletion: true)))
view.presentScene(scene)

PlaygroundPage.current.liveView = view
//#-end-hidden-code

