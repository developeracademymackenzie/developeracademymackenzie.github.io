import Foundation
import SpriteKit


    
public class AnimatedNode:SKSpriteNode{
    public var nodeName: String!
    var initialImage: UIImage!
    var animation : SKAction!
    public var willAnimateForever = false
    public var concluded = SKSpriteNode()
    public init (nodeName: String, initialImage: UIImage){
        super.init(texture: SKTexture(image: initialImage), color: UIColor.clear, size: CGSize(width: 35.0, height: 35.0*1.80))
        self.nodeName = nodeName
        self.initialImage = initialImage
        self.animation = SKAction.init(named: nodeName)
        self.concluded = SKSpriteNode(imageNamed: "check.png")
        self.concluded.isHidden = true
        self.concluded.size = CGSize(width: 10.0, height: 10.0)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func playAnimation(){
        
        self.concluded.isHidden = false
        if !willAnimateForever{
            self.run(SKAction.playSoundFileNamed(self.nodeName + ".m4a", waitForCompletion: true))
            self.run(self.animation)
        }
        
        
    }
    
}
