import Foundation
import SpriteKit

public class IntroScene: SKScene {
    
    var transitionNode: SKSpriteNode?
    
    override public func didMove(to view: SKView) {
        self.transitionNode = childNode(withName: "Transition") as? SKSpriteNode
    }
    
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        if let transition = transitionNode {
            if transition.alpha == 1 {
                if let scene = RedWordsScene(fileNamed: "RedWordScene") {
                    // Set the scale mode to scale to fit the window
                    scene.scaleMode = .aspectFit
                    // Present the scene
                    let defaults = UserDefaults.standard
                    defaults.set(true, forKey: "viewed")
                    self.view?.presentScene(scene)
                }
            }
        }
        
    }
}
