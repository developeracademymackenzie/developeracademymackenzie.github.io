import Foundation
import SpriteKit

public class Redzin: SKSpriteNode{
    private var node: SKSpriteNode!
    private var walkLeftAnimation = SKAction(named: "walk/redzin/left", duration: 0.65)
    private var walkRightAnimation = SKAction(named: "walk/redzin/right", duration: 0.65)
    
    public init(redzin node: SKSpriteNode){
        self.node = node
        super.init(texture: node.texture, color: node.color, size: node.size)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func walkToLeft(){
        if !node.hasActions(){
            let moveAction = SKAction.moveBy(x: -25, y: 0, duration: 1.3)
            let seqMove = SKAction.sequence([walkLeftAnimation!,walkLeftAnimation!])
            let groupAction = SKAction.group([seqMove,moveAction])
            node.run(groupAction)
        }
    }
    
    public func walkToRight(){
        if !node.hasActions(){
            if node.position.x + 25 <= 148{
                let moveAction = SKAction.moveBy(x: 25, y: 0, duration: 1.3)
                let seqMove = SKAction.sequence([walkRightAnimation!,walkRightAnimation!])
                let groupAction = SKAction.group([seqMove,moveAction])
                node.run(groupAction)
            }else{
                let moveAction = SKAction.moveBy(x: 148-node.position.x, y: 0, duration: 1.3)
                let seqMove = SKAction.sequence([walkRightAnimation!,walkRightAnimation!])
                let groupAction = SKAction.group([seqMove,moveAction])
                node.run(groupAction)
            }
        }
    }
    
}
