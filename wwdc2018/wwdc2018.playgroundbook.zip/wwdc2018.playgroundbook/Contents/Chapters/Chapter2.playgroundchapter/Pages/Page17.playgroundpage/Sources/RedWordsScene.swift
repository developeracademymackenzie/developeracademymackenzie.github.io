import Foundation
import SpriteKit

public class RedWordsScene: SKScene {
    
    // Redzin
    var redzinSpriteNode: SKSpriteNode!
    var redzin: Redzin!
    
    // Transition
    var transitionNode: SKSpriteNode!
    
    // Movements Nodes
    var leftButton: SKSpriteNode!
    var rightButton: SKSpriteNode!
    
    // Labels
    var carefulLabel: SKLabelNode!
    
    override public func didMove(to view: SKView) {
        self.leftButton = childNode(withName: "GoLefttButton") as! SKSpriteNode
        self.rightButton = childNode(withName: "GoRightButton") as! SKSpriteNode
        self.transitionNode = childNode(withName: "transitionsNode") as! SKSpriteNode
        self.redzinSpriteNode = childNode(withName: "Redzin") as! SKSpriteNode
        self.redzin = Redzin(redzin: self.redzinSpriteNode)
        self.carefulLabel = childNode(withName: "CarefulLabel") as! SKLabelNode
    }
    
    public func touchDown(atPoint pos : CGPoint) {
        let touchedNodes = self.nodes(at: pos)
        touchedNodes.forEach { (node) in
            if node == leftButton{
                self.redzin.walkToLeft()
                if self.carefulLabel.alpha == 1{
                    self.carefulLabel.alpha = 0
                }
            }
            
            if node == rightButton{
                self.redzin.walkToRight()
                if self.redzinSpriteNode.position.x + 25 >= 148 {
                    self.carefulLabel.alpha = 1
                }
            }
        }
    }
    
    public func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    public func touchUp(atPoint pos : CGPoint) {
        
    }
    
    
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
