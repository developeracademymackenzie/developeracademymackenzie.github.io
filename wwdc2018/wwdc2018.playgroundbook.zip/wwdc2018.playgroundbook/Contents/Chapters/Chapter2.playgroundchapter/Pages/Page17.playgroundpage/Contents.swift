/*: Matheus de Vasconcelos Moura
 
 ![Matheus](matheus.png)
 
 # Matheus de Vasconcelos Moura
 
 - - -
 iPad
 - - -
 
 ### Big Idea
 Raise Awareness
 
 ### Essential Question
  How can we make children aware of prejudice?
 
 ### Challenge
 Create a game that talks about prejudice in ludic way.
 
 - - -
 
 The playground is a game that talks about Redland. Everything was normal, until something started to waste Redland, and to save it, the character has to travel between worlds and have to meet the grins, the people of Greenland, and they can help the main character, but to do this, the character must answer some questions, but if the answers are somehow any form of prejudice the thing that is destroying Redland grows up, but if the answers are kind and not prejudicial, the grins will help the character to save his world.
 
 In this year I start knowing what I want to do and how to do, so it was more easy, and the code is much more organized, which helps a lot in development. In the first year I learned that you must like your ideia, because I started last year with a ideia that I disliked and discarded it one week on it, so this year I started doing  something  that I really liked. I'm using the last year playground just to see the markdowns, but the code won't help me in anything.
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit


public class Redzin: SKSpriteNode{
    private var node: SKSpriteNode!
    private var walkLeftAnimation = SKAction(named: "walk/redzin/left", duration: 0.65)
    private var walkRightAnimation = SKAction(named: "walk/redzin/right", duration: 0.65)
    
    public init(redzin node: SKSpriteNode){
        self.node = node
        super.init(texture: node.texture, color: node.color, size: node.size)
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func walkToLeft(){
        if !node.hasActions(){
            let moveAction = SKAction.moveBy(x: -25, y: 0, duration: 1.3)
            let seqMove = SKAction.sequence([walkLeftAnimation!,walkLeftAnimation!])
            let groupAction = SKAction.group([seqMove,moveAction])
            node.run(groupAction)
        }
    }
    
    public func walkToRight(){
        if !node.hasActions(){
            if node.position.x + 25 <= 148{
                let moveAction = SKAction.moveBy(x: 25, y: 0, duration: 1.3)
                let seqMove = SKAction.sequence([walkRightAnimation!,walkRightAnimation!])
                let groupAction = SKAction.group([seqMove,moveAction])
                node.run(groupAction)
            }else{
                let moveAction = SKAction.moveBy(x: 148-node.position.x, y: 0, duration: 1.3)
                let seqMove = SKAction.sequence([walkRightAnimation!,walkRightAnimation!])
                let groupAction = SKAction.group([seqMove,moveAction])
                node.run(groupAction)
            }
        }
    }
    
}


public class RedWordsScene: SKScene {
    
    // Redzins
    var redzinSpriteNode: SKSpriteNode!
    var redzin: Redzin!
    var masterRedzin: SKSpriteNode!
    
    // Transition
    var transitionNode: SKSpriteNode!
    
    // Interaction Nodes
    var leftButton: SKSpriteNode!
    var rightButton: SKSpriteNode!
    var talkButton: SKSpriteNode!
    
    // Labels
    var carefulLabel: SKLabelNode!
    
    override public func didMove(to view: SKView) {
        self.leftButton = childNode(withName: "GoLefttButton") as! SKSpriteNode
        self.rightButton = childNode(withName: "GoRightButton") as! SKSpriteNode
        self.transitionNode = childNode(withName: "transitionsNode") as! SKSpriteNode
        self.redzinSpriteNode = childNode(withName: "Redzin") as! SKSpriteNode
        self.redzin = Redzin(redzin: self.redzinSpriteNode)
        self.carefulLabel = childNode(withName: "CarefulLabel") as! SKLabelNode
        self.masterRedzin = childNode(withName: "masterRedzin") as! SKSpriteNode
        self.talkButton = childNode(withName: "TalkButton") as! SKSpriteNode
    }
    
    public func touchDown(atPoint pos : CGPoint) {
        let touchedNodes = self.nodes(at: pos)
        touchedNodes.forEach { (node) in
            if node == leftButton{
                self.redzin.walkToLeft()
                if self.carefulLabel.alpha == 1{
                    self.carefulLabel.alpha = 0
                }
                
                if self.masterRedzin.position.x > self.redzinSpriteNode.position.x - 25{
                    let texture = SKTexture(imageNamed: "masterLeft")
                    guard let masterTextureDescription = self.masterRedzin.texture?.description else { return }
                    if !(masterTextureDescription == texture.description){
                        self.masterRedzin.texture = texture
                    }
                }
                
            }
            
            if node == rightButton{
                self.redzin.walkToRight()
                if self.redzinSpriteNode.position.x + 25 >= 148 {
                    self.carefulLabel.alpha = 1
                }
                if self.masterRedzin.position.x < self.redzinSpriteNode.position.x + 25{
                    let texture = SKTexture(imageNamed: "masterRight")
                    guard let masterTextureDescription = self.masterRedzin.texture?.description else { return }
                    if !(masterTextureDescription == texture.description){
                        self.masterRedzin.texture = texture
                    }
                }
                
            }
            
            if node == self.talkButton{
                let texture = SKTexture(imageNamed: "masterLeft")
                guard let masterTextureDescription = self.masterRedzin.texture?.description else { return }
                if masterTextureDescription == texture.description{
                    let speak = childNode(withName: "masterTalkRightSide") as! SKSpriteNode
                    let alphaAct = SKAction.fadeAlpha(by: 1, duration: 0.3)
                    speak.run(alphaAct)
                }else{
                    let speak = childNode(withName: "masterTalkLeftSide") as! SKSpriteNode
                    let alphaAct = SKAction.fadeAlpha(by: 1, duration: 0.3)
                    speak.run(alphaAct)
                }
            }
        }
    }
    
    public func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    public func touchUp(atPoint pos : CGPoint) {
        
    }
    
    
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        if self.talkButton.alpha == 0 && self.redzinSpriteNode.position.x > self.masterRedzin.position.x - 55 && self.redzinSpriteNode.position.x < self.masterRedzin.position.x + 55{
            let alphaAct = SKAction.fadeAlpha(by: 1, duration: 0.3)
            self.talkButton.run(alphaAct)
            
        }
    }
}


public class IntroScene: SKScene {
    
    var transitionNode: SKSpriteNode?
    
    override public func didMove(to view: SKView) {
        self.transitionNode = childNode(withName: "Transition") as? SKSpriteNode
    }
    
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        if let transition = transitionNode {
            if transition.alpha == 1 {
                if let scene = RedWordsScene(fileNamed: "RedWordScene") {
                    // Set the scale mode to scale to fit the window
                    scene.scaleMode = .aspectFit
                    // Present the scene
                    let defaults = UserDefaults.standard
                    defaults.set(true, forKey: "viewed")
                    self.view?.presentScene(scene)
                }
            }
        }
        
    }
}

// Load the SKScene from 'GameScene.sks'
let defaults = UserDefaults.standard
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 642, height: 537))

let stateIntro = defaults.bool(forKey: "viewed")

if stateIntro{
    if let scene = RedWordsScene(fileNamed: "RedWordScene") {
        // Set the scale mode to scale to fit the window
        scene.scaleMode = .aspectFit
        // Present the scene
        sceneView.presentScene(scene)
        PlaygroundPage.current.liveView = sceneView
    }
}else{
    if let scene = IntroScene(fileNamed: "GameScene") {
        // Set the scale mode to scale to fit the window
        scene.scaleMode = .aspectFit
        // Present the scene
        sceneView.presentScene(scene)
    }
    
    PlaygroundPage.current.liveView = sceneView
}

//#-end-hidden-code
