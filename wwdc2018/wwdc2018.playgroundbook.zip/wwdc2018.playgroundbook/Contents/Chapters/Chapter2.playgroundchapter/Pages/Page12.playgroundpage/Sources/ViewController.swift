//
//  ViewController.swift
//  MentalCalculation
//
//  Created by Gustavo Rodrigues on 20/03/18.
//  Copyright © 2018 Gustavo Rodrigues. All rights reserved.
//

import UIKit
import AVFoundation

public class SharedData {
    static let data = SharedData()
    var sum: Int = 0
    var right: Int = 0
    var wrong: Int = 0
    var touched: Int = 0
    var isRight: Bool = true
}

public class ViewController: UIViewController, HolderViewDelegate {
    
    var firstView = HolderView(frame: CGRect.zero)
    var secondView = HolderView(frame: CGRect.zero)
    let label: UILabel = UILabel(frame: CGRect.zero)
    
    var boxWidth: CGFloat = 273.0
    var boxHeight: CGFloat = 273.0
    
    var stage = 1
    
    var cards : [Card] = []
    var views : [UIView] = []
    
    var timer: Timer? = Timer()
    var seconds: Int = 20
    let timeView = UIView()
    
    var isGameStarted = false
    var test : Bool = true
    
    var sharedData = SharedData.data
    
    //SOUND EFFECT
    var audioPlayer = AVAudioPlayer()
    func playSound(file: String , type: String){
        let audioURL = URL(fileURLWithPath: Bundle.main.path(forResource: file, ofType: type)!)
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: audioURL)
            audioPlayer.numberOfLoops = 0
            audioPlayer.play()
        } catch {
            print("Audio error")
        }
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.isUserInteractionEnabled = false
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.view.backgroundColor = Colors.beige
        addHolderView(holderView: firstView)
    }
    // MARK: Setup Cards
    func addHolderView(holderView: HolderView) {
        holderView.frame = CGRect(x: view.bounds.width / 2 - boxWidth / 2,
                                  y: view.bounds.height / 2 - boxHeight / 2,
                                  width: boxWidth,
                                  height: boxHeight)
        holderView.parentFrame = view.frame
        holderView.delegate = self
        view.addSubview(holderView)
        holderView.drawAnimatedRectangle()
    }
    var pop = ""
    var right = ""
    func addCard(number: Int){
        playSound(file: pop, type: "wav")
        let card = Card(frame: CGRect.zero)
        if cards.count == 0 {
            card.backgroundColor = Colors.red
        } else if cards.count == 1 {
            card.backgroundColor = Colors.cyan
        } else {
            card.backgroundColor = Colors.blue
        }
        card.number = number
        card.frame = CGRect(x: -boxWidth,
                            y: view.bounds.height / 2 - boxHeight / 2,
                            width: boxWidth,
                            height: boxHeight)
        
        view.addSubview(card)
        animationIn(cardView: card)
        card.addLabel()
        cards.append(card)
    }
    func animationIn(cardView: UIView){
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.4, options: .curveEaseInOut, animations: {
            cardView.frame = CGRect(x: self.view.bounds.width / 2 - self.boxWidth / 2 ,
                                    y: self.view.bounds.height / 2 - self.boxHeight / 2 ,
                                    width: cardView.frame.width,
                                    height: cardView.frame.height)
        }, completion: nil)
    }
    func removeCards(){
        for i in 0..<cards.count {
            cards[i].removeFromSuperview()
        }
        cards.removeAll()
    }
    // MARK: Setup Labels
    func animateLabel(holderView: HolderView) {
        let label: UILabel = UILabel(frame: holderView.frame)
        label.textColor = Colors.beige
        label.center = CGPoint(x: holderView.frame.width / 2, y: holderView.frame.height / 2)
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 30.0)
        label.textAlignment = .center
        if stage == 1 {
            label.text = "Let's see how is your ability to do calculations mentally?"
        } else {
            if sharedData.isRight {
                label.text = "You answered correctly. Now let's see how many exercises can you solve?"
            }else{
                label.text = "You answered wrong, but now let's see how many exercises can you solve?"
            }
            
        }
        
        label.numberOfLines = 0
        animate(label: label)
        holderView.addSubview(label)
        view.isUserInteractionEnabled = true
    }
    func animateLabel() {
        if stage == 1 {
            animateLabel(holderView: firstView)
        }else{
            animateLabel(holderView: secondView)
        }
        
    }
    func addlabelTutorial(){
        label.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.width / 1.2, height: view.frame.height)
        label.textColor = Colors.blue
        label.center = CGPoint(x: view.frame.width / 2, y: view.frame.maxY)
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 20.0)
        label.textAlignment = .center
        if cards.count == 1{
            label.text = "Touch to pass to the next number"
            label.textColor = Colors.red
        }else if cards.count == 2{
            label.text = "Add this number to the previous one"
            label.textColor = Colors.cyan
        }else if cards.count == 3{
            label.text = "Add this number to the previous ones"
            label.textColor = Colors.blue
        }else {
            label.text = "Now find the result 🤓"
            label.textColor = Colors.blue
        }
        label.numberOfLines = 0
        view.addSubview(label)
        
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.label.center = CGPoint(x: self.view.frame.width / 2, y: self.firstView.frame.maxY + 75.0 )
        }, completion: nil)
    }
    
    // MARK: Setup Time
    func setupTime(){
        timeView.frame = CGRect(x: view.frame.minX,
                                y: view.frame.minY,
                                width: view.frame.width,
                                height: 25.0)
        timeView.backgroundColor = Colors.blue
        view.addSubview(timeView)
        if isGameStarted{
            UIView.animate(withDuration: TimeInterval(seconds), animations: {
                self.timeView.frame = CGRect(x: self.view.bounds.minX,
                                             y: self.view.bounds.minY,
                                             width: 0.0,
                                             height: 25.0)
                self.timeView.backgroundColor = Colors.red
            }, completion: nil)
            runTimer()
        }
    }
    
    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer() {
        if self.seconds <= 0 {
            showResults()
            stage += 1
            timer?.invalidate()
            seconds = 20
        }else{
            seconds -= 1
        }
    }
    
    func removeSubviews(){
        for view in self.view.subviews {
            view.removeFromSuperview()
        }
    }
    
    
    func random (lower: Int , upper: Int) -> Int {
        return lower + Int(arc4random_uniform(UInt32(upper - lower + 1)))
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        switch stage {
        case 1:
            UIView.animate(withDuration: 0.8, delay: 0.4, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.4, options: .curveEaseInOut, animations: {
                self.firstView.frame = CGRect(x: self.view.bounds.width,
                                              y: self.view.bounds.height / 2 - self.boxHeight / 2 ,
                                              width: 273.0,
                                              height: 273.0)
            }, completion: { finished in
                self.firstView.removeFromSuperview()
                let number = self.random(lower: -10, upper: 10)
                self.addCard(number: number)
                self.sharedData.sum += number
                self.addlabelTutorial()
                self.stage += 1
            })
        case 2:
            
            if cards.count < 3 {
                let number = random(lower: -10, upper: 10)
                addCard(number: number)
                sharedData.sum += number
                addlabelTutorial()
                test = true
            } else {
                test = false
                removeCards()
                removeSubviews()
                let cardResult = CardResult(frame: CGRect.zero)
                cardResult.frame = CGRect(x: view.bounds.width / 2 - boxWidth / 2,
                                          y: view.bounds.height / 2 - boxHeight / 2,
                                          width: boxWidth,
                                          height: boxHeight)
                cardResult.callback = addSecondHolder
                view.addSubview(cardResult)
                addlabelTutorial()
                stage += 1
            }
            
        case 3:
            print("entrou no 3")
        case 4:
            print("Entrou no 4")
            isGameStarted = true
            reloadGame()
            UIView.animate(withDuration: 0.8, delay: 0.4, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.4, options: .curveEaseInOut, animations: {
                self.secondView.frame = CGRect(x: self.view.bounds.width,
                                               y: self.view.bounds.height / 2 - self.boxHeight / 2 ,
                                               width: 273.0,
                                               height: 273.0)
            }, completion: { finished in
                self.secondView.removeFromSuperview()
                let number = self.random(lower: -50, upper: 50)
                self.addCard(number: number)
                self.sharedData.sum += number
                self.stage += 1
                //print("SOMA ====== ", self.sharedData.sum)
            })
        case 5:
            if cards.count < 3 {
                game()
                test = true
            }else if test {
                test = false
                let cardResult = CardResult(frame: CGRect.zero)
                cardResult.frame = CGRect(x: view.bounds.width / 2 - boxWidth / 2,
                                          y: view.bounds.height / 2 - boxHeight / 2,
                                          width: boxWidth,
                                          height: boxHeight)
                cardResult.callback = game
                view.addSubview(cardResult)
            }
        case 6:
            stage = 5
            reloadGame()
            game()
        default:
            break
        }
    }
    func addSecondHolder(){
        removeSubviews()
        setupTime()
        addHolderView(holderView: secondView)
        stage += 1
    }
    func reloadGame(){
        sharedData.sum = 0
        sharedData.right = 0
        sharedData.wrong = 0
        views.removeAll()
        removeSubviews()
        cards.removeAll()
        setupTime()
    }
    func message(){
        if cards.count == 0  && seconds != 20{
            label.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.width / 1.2, height: view.frame.height)
            
            label.center = CGPoint(x: view.frame.width / 2, y: view.frame.maxY)
            label.font = UIFont(name: "HelveticaNeue-Bold", size: 20.0)
            label.textAlignment = .center
            if sharedData.isRight {
                playSound(file: right, type: "mp3")
                label.text = "Right"
                label.textColor = Colors.cyan
            }else{
                label.text = "Wrong"
                label.textColor = Colors.red
            }
            view.addSubview(label)
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.label.center = CGPoint(x: self.view.frame.width / 2, y: self.firstView.frame.maxY + 75.0 )
            }, completion: nil)
            Timer.scheduledTimer(timeInterval:2.0, target: self,
                                 selector: #selector(self.removeLabel),
                                 userInfo: nil, repeats: false)
        }
    }
    @objc func removeLabel(){
        label.removeFromSuperview()
    }
    func game(){
        if cards.count == 3 {
            removeCards()
        }
        if cards.count < 3 {
            message()
            let number = self.random(lower: -50, upper: 50)
            addCard(number: number)
            sharedData.sum = sharedData.sum + number
        } else {
            removeCards()
            removeSubviews()
        }
    }
    
    func showResults(){
        view.isUserInteractionEnabled = false
        removeSubviews()
        
        Timer.scheduledTimer(timeInterval:0.45, target: self,
                             selector: #selector(self.addViewsResults),
                             userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:0.95, target: self,
                             selector: #selector(self.addViewsResults),
                             userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:1.45, target: self,
                             selector: #selector(self.addViewsResults),
                             userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:1.95, target: self,
                             selector: #selector(self.addAverage),
                             userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:2.45, target: self,
                             selector: #selector(self.addQuestion),
                             userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval:2.95, target: self,
                             selector: #selector(self.tryAgain),
                             userInfo: nil, repeats: false)
    }
    // MARK: Setup Results Screen
    @objc func addAverage(){
        let total = sharedData.right + sharedData.wrong
        let label: UILabel = UILabel(frame: CGRect(x: view.bounds.width * 0.5 - 200.0,
                                                   y: view.bounds.height * 0.5,
                                                   width: 400.0,
                                                   height: 140.0))
        label.textColor = Colors.blue
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 40.0)
        label.textAlignment = .center
        if total == 0 {
            label.text = "You got 0% of \(total) answers."
        }else{
            let average = 100 * sharedData.right / total
            label.text = "You got \(average)% of \(total) answers."
        }
        view.addSubview(label)
        label.numberOfLines = 0
        animate(label: label)
        
    }
    func animate(label: UILabel){
        label.transform = CGAffineTransform(scaleX: 0.4, y: 0.4)
        UIView.animate(withDuration: 0.9, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.4, options: UIViewAnimationOptions.curveEaseInOut,
                       animations: ({
                        label.transform = CGAffineTransform(scaleX: 1, y: 1)
                       }), completion: { finished in
                        self.view.isUserInteractionEnabled = true
        })
    }
    @objc func tryAgain(){
        let label: UILabel = UILabel(frame: CGRect(x: view.bounds.width * 0.5 - 200.0,
                                                   y: view.bounds.height * 0.8,
                                                   width: 400.0,
                                                   height: 140.0))
        label.textColor = Colors.red
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 25.0)
        label.textAlignment = .center
        label.text = "Touch the screen to try again 😉"
        view.addSubview(label)
        label.numberOfLines = 0
        animate(label: label)
    }
    @objc func addQuestion(){
        let label: UILabel = UILabel(frame: CGRect(x: view.bounds.width * 0.5 - 200.0,
                                                   y: view.bounds.height * 0.65,
                                                   width: 400.0,
                                                   height: 140.0))
        label.textColor = Colors.blue
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 25.0)
        label.textAlignment = .center
        label.text = "Do you want to improve your results?"
        view.addSubview(label)
        label.numberOfLines = 0
        animate(label: label)
    }
    
    
    @objc func addViewsResults(){
        let viewResult = UIView()
        var resultY : CGFloat = view.bounds.height * 0.15
        
        let label: UILabel = UILabel(frame: CGRect(x: 15.0,
                                                   y: 0.0,
                                                   width: 400.0,
                                                   height: 70.0))
        label.textColor = Colors.beige
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 35.0)
        label.textAlignment = .left
        
        let result: UILabel = UILabel(frame: CGRect(x: -15.0,
                                                    y: 0.0,
                                                    width: 400.0,
                                                    height: 70.0))
        result.textColor = Colors.beige
        result.font = UIFont(name: "HelveticaNeue-Bold", size: 35.0)
        result.textAlignment = .right
        
        viewResult.addSubview(label)
        viewResult.addSubview(result)
        switch views.count {
        case 0:
            resultY = view.bounds.height * 0.05
            viewResult.backgroundColor = Colors.blue
            label.text = "Total"
            result.text = "\(sharedData.right + sharedData.wrong)"
        case 1:
            resultY = view.bounds.height * 0.2
            viewResult.backgroundColor = Colors.cyan
            label.text = "Right"
            result.text = "\(sharedData.right)"
        case 2:
            resultY = view.bounds.height * 0.35
            viewResult.backgroundColor = Colors.red
            label.text = "Wrong"
            result.text = "\(sharedData.wrong)"
        default:
            break
        }
        viewResult.frame = CGRect(x: -self.view.bounds.width * 0.9,
                                  y: resultY,
                                  width: 400.0,
                                  height: 70.0)
        view.addSubview(viewResult)
        
        views.append(viewResult)
        
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.4, options: .curveEaseInOut, animations: {
            viewResult.frame = CGRect(x: self.view.bounds.width / 2 - 400 / 2,
                                      y: resultY,
                                      width: 400.0,
                                      height: 70.0)
        }, completion: nil)
    }
}
