//
//  Colors.swift
//  MentalCalculation
//
//  Created by Gustavo Rodrigues on 20/03/18.
//  Copyright © 2018 Gustavo Rodrigues. All rights reserved.
//

import UIKit

public struct Colors {
    static let blue = UIColor(red: 78.0 / 255.0, green: 80.0 / 255.0, blue: 89.0 / 255.0, alpha: 1.0)
    static let red = UIColor(red: 252.0 / 255.0, green: 96.0 / 255.0, blue: 83.0 / 255.0, alpha: 1.0)
    static let beige = UIColor(red: 253.0 / 255.0, green: 250.0 / 255.0, blue: 245.0 / 255.0, alpha: 1.0)
    static let cyan = UIColor(red: 53.0 / 255.0, green: 195.0 / 255.0, blue: 186.0 / 255.0, alpha: 1.0)
    static let clear = UIColor.clear
}
